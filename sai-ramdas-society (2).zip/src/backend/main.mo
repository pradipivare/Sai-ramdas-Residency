import Map "mo:core/Map";
import List "mo:core/List";
import AccessControl "mo:caffeineai-authorization/access-control";

import MixinAuthorization "mo:caffeineai-authorization/MixinAuthorization";
import MixinObjectStorage "mo:caffeineai-object-storage/Mixin";
import ResidentTypes "types/residents";
import BillingTypes "types/billing";
import ComplaintTypes "types/complaints";
import VisitorTypes "types/visitors";
import NoticeTypes "types/notices";
import CommonTypes "types/common";
import SocietyRulesTypes "types/society-rules";
import SocietyBodyTypes "types/society-body";
import AdminSettingsTypes "types/admin-settings";
import ResidentsMixin "mixins/residents-api";
import BillingMixin "mixins/billing-api";
import ComplaintsMixin "mixins/complaints-api";
import VisitorsMixin "mixins/visitors-api";
import NoticesMixin "mixins/notices-api";
import SocietyRulesMixin "mixins/society-rules-api";
import SocietyBodyMixin "mixins/society-body-api";
import AdminSettingsMixin "mixins/admin-settings-api";


actor {
  // Authorization
  let accessControlState = AccessControl.initState();
  include MixinAuthorization(accessControlState);

  // Object Storage
  include MixinObjectStorage();

  // Residents & Flats state
  let flats = Map.empty<CommonTypes.FlatNumber, ResidentTypes.Flat>();
  let residents = List.empty<ResidentTypes.Resident>();
  let residentCounter = { var nextId : Nat = 0 };

  // Billing state
  let bills = List.empty<BillingTypes.Bill>();
  let billCounter = { var nextId : Nat = 0 };

  // Complaints state
  let complaints = List.empty<ComplaintTypes.Complaint>();
  let complaintCounter = { var nextId : Nat = 0 };

  // Visitors state
  let visitors = List.empty<VisitorTypes.Visitor>();
  let preApprovedGuests = List.empty<VisitorTypes.PreApprovedGuest>();
  let visitorCounter = { var nextId : Nat = 0 };
  let guestCounter = { var nextId : Nat = 0 };

  // Notices state
  let notices = List.empty<NoticeTypes.Notice>();
  let noticeCounter = { var nextId : Nat = 0 };

  // Society Rules state
  let societyRules = List.empty<SocietyRulesTypes.SocietyRule>();
  let ruleCounter = { var nextId : Nat = 0 };

  // Society Body (Committee) state
  let societyMembers = List.empty<SocietyBodyTypes.SocietyMember>();
  let memberCounter = { var nextId : Nat = 0 };

  // Admin Settings state
  let adminSettings = Map.empty<Text, AdminSettingsTypes.AdminSetting>();
  let adminActionLog = List.empty<AdminSettingsTypes.AdminActionLog>();
  let actionLogCounter = { var nextId : Nat = 0 };

  // Admin Users state (username/password auth, max 3)
  let adminUsers = Map.empty<Text, AdminSettingsTypes.AdminUser>();
  let adminUserCounter = { var nextId : Nat = 0 };

  // Include domain mixins
  include ResidentsMixin(accessControlState, flats, residents, residentCounter);
  include BillingMixin(accessControlState, bills, flats, billCounter, residents);
  include ComplaintsMixin(accessControlState, complaints, complaintCounter);
  include VisitorsMixin(accessControlState, visitors, preApprovedGuests, residents, visitorCounter, guestCounter);
  include NoticesMixin(accessControlState, notices, noticeCounter);
  include SocietyRulesMixin(accessControlState, societyRules, ruleCounter);
  include SocietyBodyMixin(accessControlState, societyMembers, memberCounter);
  include AdminSettingsMixin(accessControlState, adminSettings, adminActionLog, actionLogCounter, adminUsers, adminUserCounter);
};
