import List "mo:core/List";
import Runtime "mo:core/Runtime";
import Time "mo:core/Time";
import AccessControl "mo:caffeineai-authorization/access-control";
import SocietyRulesLib "../lib/society-rules";
import SocietyRulesTypes "../types/society-rules";

mixin (
  accessControlState : AccessControl.AccessControlState,
  rules : List.List<SocietyRulesTypes.SocietyRule>,
  ruleCounter : { var nextId : Nat },
) {
  // Pre-populate sample society rules (runs at canister init via first call pattern)
  do {
    if (ruleCounter.nextId == 0) {
      let now = Time.now();
      let sampleRules : [(Text, Text, Text, Text, Text, [Text], Nat)] = [
        (
          "मासिक देखभाल शुल्क",
          "Monthly Maintenance Charges",
          "प्रत्येक सदस्याने महिन्याच्या ५ तारखेपर्यंत मासिक देखभाल शुल्क भरणे बंधनकारक आहे. उशीर झाल्यास दरमहा २% व्याज आकारले जाईल.",
          "Every member must pay the monthly maintenance charges by the 5th of each month. A penalty of 2% per month will be charged for late payment.",
          "financial",
          ["maintenance", "payment", "penalty"],
          1,
        ),
        (
          "विशेष निधी वर्गणी",
          "Special Fund Contribution",
          "सोसायटीच्या मोठ्या दुरुस्तीसाठी किंवा सुधारणेसाठी विशेष निधी गोळा केला जाऊ शकतो. सर्व सदस्यांना समान वाटा द्यावा लागेल.",
          "A special fund may be collected for major repairs or improvements to the society. All members must contribute an equal share.",
          "financial",
          ["fund", "repair", "improvement"],
          2,
        ),
        (
          "सुरक्षा नियम",
          "Security Rules",
          "रात्री १० नंतर कोणत्याही पाहुण्याला प्रवेश देण्यापूर्वी सुरक्षा रक्षकाने संबंधित सदस्याची परवानगी घेणे आवश्यक आहे. सर्व अभ्यागतांची नोंद ठेवणे अनिवार्य आहे.",
          "After 10 PM, the security guard must obtain permission from the concerned member before allowing any visitor entry. Maintaining a record of all visitors is mandatory.",
          "security",
          ["visitor", "night", "guard"],
          3,
        ),
        (
          "वाहन पार्किंग नियम",
          "Vehicle Parking Rules",
          "प्रत्येक सदस्याने आपले वाहन नियुक्त जागीच पार्क करावे. इतरांच्या जागी वाहन पार्क केल्यास दंड आकारला जाईल. अभ्यागतांच्या वाहनांसाठी विशेष जागा निर्धारित आहे.",
          "Every member must park their vehicle only in the designated space. Parking in others' spaces will result in a fine. A special area is designated for visitor vehicles.",
          "security",
          ["parking", "vehicle", "fine"],
          4,
        ),
        (
          "इमारत देखभाल जबाबदारी",
          "Building Maintenance Responsibility",
          "स्वतःच्या फ्लॅटमधील कोणत्याही दुरुस्तीची जबाबदारी संबंधित सदस्याची आहे. इमारतीच्या सामाईक भागातील दुरुस्ती सोसायटीच्या निधीतून केली जाईल.",
          "The responsibility for any repairs within one's own flat lies with the concerned member. Repairs to the common areas of the building will be carried out from the society fund.",
          "maintenance",
          ["repair", "flat", "common-area"],
          5,
        ),
        (
          "स्वच्छता नियम",
          "Cleanliness Rules",
          "सामाईक परिसर, जिना, गॅलरी इत्यादी नेहमी स्वच्छ ठेवणे सर्व सदस्यांची जबाबदारी आहे. कचरा नियुक्त ठिकाणीच टाकावा. कोरडा व ओला कचरा वेगळा करणे अनिवार्य आहे.",
          "It is the responsibility of all members to keep common areas, stairways, galleries, etc. clean at all times. Garbage must be disposed of only at the designated location. Dry and wet waste segregation is mandatory.",
          "maintenance",
          ["cleanliness", "garbage", "segregation"],
          6,
        ),
        (
          "आचरण नियम",
          "Conduct Rules",
          "सोसायटी परिसरात कोणत्याही प्रकारचा त्रास किंवा गोंगाट करणे निषिद्ध आहे. रात्री १० नंतर आणि सकाळी ७ पूर्वी मोठा आवाज करण्यास मनाई आहे.",
          "Creating any nuisance or noise in the society premises is prohibited. Making loud noise after 10 PM and before 7 AM is strictly prohibited.",
          "conduct",
          ["noise", "nuisance", "quiet-hours"],
          7,
        ),
        (
          "पाळीव प्राणी नियम",
          "Pet Rules",
          "पाळीव प्राण्यांना लिफ्टमध्ये घेण्यास मनाई आहे. सामाईक परिसरात पाळीव प्राण्यांना नेताना पट्टा वापरणे अनिवार्य आहे. पाळीव प्राण्यांमुळे झालेल्या नुकसानाची भरपाई मालकाने द्यावी.",
          "Pets are not allowed in the lift. It is mandatory to use a leash when taking pets to common areas. The owner must compensate for any damage caused by their pets.",
          "conduct",
          ["pets", "leash", "lift"],
          8,
        ),
        (
          "सभा आणि निर्णय प्रक्रिया",
          "Meeting and Decision-Making Process",
          "सोसायटीच्या सर्वसाधारण सभा वर्षातून किमान दोन वेळा घेतल्या जातील. महत्त्वाचे निर्णय बहुमताने घेतले जातील. सर्व सदस्यांना सभेची किमान ७ दिवस आधी नोटीस दिली जाईल.",
          "General meetings of the society will be held at least twice a year. Important decisions will be taken by majority vote. All members will be given at least 7 days notice before the meeting.",
          "conduct",
          ["meeting", "voting", "notice"],
          9,
        ),
        (
          "भाडेकरू नोंदणी",
          "Tenant Registration",
          "कोणत्याही सदस्याने आपला फ्लॅट भाड्याने देण्यापूर्वी सोसायटीला लेखी कळवणे अनिवार्य आहे. भाडेकरूची पूर्ण माहिती सोसायटी कार्यालयात जमा करणे बंधनकारक आहे. पोलीस व्हेरिफिकेशन करणे आवश्यक आहे.",
          "Before renting out their flat, any member must inform the society in writing. Submitting the complete details of the tenant to the society office is mandatory. Police verification is required.",
          "security",
          ["tenant", "registration", "police-verification"],
          10,
        ),
      ];
      for ((titleM, titleE, descM, descE, cat, tags, order) in sampleRules.values()) {
        ignore SocietyRulesLib.addSocietyRule(rules, ruleCounter, titleM, titleE, descM, descE, cat, tags, order);
      };
    };
  };

  // Any authenticated user can view society rules
  public query ({ caller }) func getSocietyRules() : async [SocietyRulesTypes.SocietyRule] {
    if (not AccessControl.hasPermission(accessControlState, caller, #user)) {
      Runtime.trap("Unauthorized: Login required");
    };
    SocietyRulesLib.getSocietyRules(rules);
  };

  // Any authenticated user can filter rules by category
  public query ({ caller }) func getSocietyRulesByCategory(category : Text) : async [SocietyRulesTypes.SocietyRule] {
    if (not AccessControl.hasPermission(accessControlState, caller, #user)) {
      Runtime.trap("Unauthorized: Login required");
    };
    SocietyRulesLib.getSocietyRulesByCategory(rules, category);
  };

  // Admin-only: add a new society rule
  public shared ({ caller }) func addSocietyRule(
    titleMarathi : Text,
    titleEnglish : Text,
    descriptionMarathi : Text,
    descriptionEnglish : Text,
    category : Text,
    tags : [Text],
    orderNumber : Nat,
  ) : async Nat {
    if (not AccessControl.isAdmin(accessControlState, caller)) {
      Runtime.trap("Unauthorized: Only admins can add society rules");
    };
    SocietyRulesLib.addSocietyRule(rules, ruleCounter, titleMarathi, titleEnglish, descriptionMarathi, descriptionEnglish, category, tags, orderNumber);
  };

  // Admin-only: update an existing society rule
  public shared ({ caller }) func updateSocietyRule(rule : SocietyRulesTypes.SocietyRule) : async () {
    if (not AccessControl.isAdmin(accessControlState, caller)) {
      Runtime.trap("Unauthorized: Only admins can update society rules");
    };
    SocietyRulesLib.updateSocietyRule(rules, rule);
  };

  // Admin-only: delete a society rule (soft delete)
  public shared ({ caller }) func deleteSocietyRule(id : Nat) : async () {
    if (not AccessControl.isAdmin(accessControlState, caller)) {
      Runtime.trap("Unauthorized: Only admins can delete society rules");
    };
    SocietyRulesLib.deleteSocietyRule(rules, id);
  };
};
