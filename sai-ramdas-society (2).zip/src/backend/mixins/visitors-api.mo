import List "mo:core/List";
import Time "mo:core/Time";
import Runtime "mo:core/Runtime";
import AccessControl "mo:caffeineai-authorization/access-control";
import VisitorTypes "../types/visitors";
import ResidentTypes "../types/residents";
import CommonTypes "../types/common";
import VisitorLib "../lib/visitors";

mixin (
  accessControlState : AccessControl.AccessControlState,
  visitors : List.List<VisitorTypes.Visitor>,
  preApprovedGuests : List.List<VisitorTypes.PreApprovedGuest>,
  residents : List.List<ResidentTypes.Resident>,
  visitorCounter : { var nextId : Nat },
  guestCounter : { var nextId : Nat },
) {
  // SecurityGuard or Admin can see all visitors today
  public query ({ caller }) func getTodayVisitors() : async [VisitorTypes.Visitor] {
    if (not AccessControl.hasPermission(accessControlState, caller, #user)) {
      Runtime.trap("Unauthorized");
    };
    VisitorLib.getTodayVisitors(visitors, Time.now());
  };

  // Resident can see visitors for their flat; Admin/SecurityGuard can query any flat
  public query ({ caller }) func getVisitorsByFlat(flatNumber : CommonTypes.FlatNumber) : async [VisitorTypes.Visitor] {
    if (not AccessControl.hasPermission(accessControlState, caller, #user)) {
      Runtime.trap("Unauthorized");
    };
    VisitorLib.getVisitorsByFlat(visitors, flatNumber);
  };

  // SecurityGuard logs a new visitor entry — generates OTP
  public shared ({ caller }) func logVisitorEntry(
    name : Text,
    mobile : Text,
    flatVisiting : CommonTypes.FlatNumber,
    purpose : Text,
  ) : async (Nat, Text) {
    if (not AccessControl.hasPermission(accessControlState, caller, #user)) {
      Runtime.trap("Unauthorized");
    };
    let now = Time.now();
    let result = VisitorLib.logVisitorEntry(visitors, visitorCounter.nextId, name, mobile, flatVisiting, purpose, caller, now);
    visitorCounter.nextId += 1;
    result;
  };

  // Resident approves visitor by providing the OTP — only resident of that flat may approve
  public shared ({ caller }) func approveVisitor(visitorId : Nat, otpCode : Text) : async () {
    if (not AccessControl.hasPermission(accessControlState, caller, #user)) {
      Runtime.trap("Unauthorized");
    };
    VisitorLib.approveVisitor(visitors, residents, caller, visitorId, otpCode);
  };

  // Resident rejects visitor — only resident of that flat may reject
  public shared ({ caller }) func rejectVisitor(visitorId : Nat) : async () {
    if (not AccessControl.hasPermission(accessControlState, caller, #user)) {
      Runtime.trap("Unauthorized");
    };
    VisitorLib.rejectVisitor(visitors, residents, caller, visitorId);
  };

  // SecurityGuard logs exit time
  public shared ({ caller }) func logVisitorExit(visitorId : Nat) : async () {
    if (not AccessControl.hasPermission(accessControlState, caller, #user)) {
      Runtime.trap("Unauthorized");
    };
    VisitorLib.logVisitorExit(visitors, visitorId, Time.now());
  };

  // Anyone can view pre-approved guests for a flat (authenticated users)
  public query ({ caller }) func getPreApprovedGuests(flatNumber : CommonTypes.FlatNumber) : async [VisitorTypes.PreApprovedGuest] {
    if (not AccessControl.hasPermission(accessControlState, caller, #user)) {
      Runtime.trap("Unauthorized");
    };
    VisitorLib.getPreApprovedGuests(preApprovedGuests, flatNumber);
  };

  // Admin or Committee member adds a pre-approved guest
  public shared ({ caller }) func addPreApprovedGuest(
    flatNumber : CommonTypes.FlatNumber,
    name : Text,
    mobile : Text,
    relationship : Text,
  ) : async Nat {
    if (not AccessControl.hasPermission(accessControlState, caller, #user)) {
      Runtime.trap("Unauthorized");
    };
    let id = VisitorLib.addPreApprovedGuest(preApprovedGuests, guestCounter.nextId, flatNumber, name, mobile, relationship);
    guestCounter.nextId += 1;
    id;
  };

  // Admin or Committee member removes a pre-approved guest
  public shared ({ caller }) func removePreApprovedGuest(guestId : Nat) : async () {
    if (not AccessControl.isAdmin(accessControlState, caller)) {
      Runtime.trap("Unauthorized: Only admins can remove pre-approved guests");
    };
    VisitorLib.removePreApprovedGuest(preApprovedGuests, guestId);
  };
};
