import List "mo:core/List";
import Runtime "mo:core/Runtime";
import AccessControl "mo:caffeineai-authorization/access-control";
import SocietyBodyLib "../lib/society-body";
import SocietyBodyTypes "../types/society-body";

mixin (
  accessControlState : AccessControl.AccessControlState,
  members : List.List<SocietyBodyTypes.SocietyMember>,
  memberCounter : { var nextId : Nat },
) {
  // Pre-populate sample committee members
  do {
    if (memberCounter.nextId == 0) {
      let sampleMembers : [(Text, Text, SocietyBodyTypes.SocietyMemberRole, ?Text, ?Text, Nat)] = [
        ("श्री. रमेश पाटील", "Shri. Ramesh Patil", #chairman, null, ?"9876543210", 1),
        ("श्री. सुरेश देसाई", "Shri. Suresh Desai", #viceChairman, null, ?"9876543211", 2),
        ("श्रीमती. सुनीता शर्मा", "Smt. Sunita Sharma", #secretary, null, ?"9876543212", 3),
        ("श्री. विजय कुलकर्णी", "Shri. Vijay Kulkarni", #treasurer, null, ?"9876543213", 4),
        ("श्री. अनिल जोशी", "Shri. Anil Joshi", #member, null, ?"9876543214", 5),
        ("श्रीमती. प्रिया नाईक", "Smt. Priya Naik", #member, null, ?"9876543215", 6),
      ];
      for ((nameM, nameE, role, photoId, phone, order) in sampleMembers.values()) {
        ignore SocietyBodyLib.addSocietyMember(members, memberCounter, nameM, nameE, role, photoId, phone, null, order);
      };
    };
  };

  // Any authenticated user can view all society body members
  public query ({ caller }) func getSocietyMembers() : async [SocietyBodyTypes.SocietyMember] {
    if (not AccessControl.hasPermission(accessControlState, caller, #user)) {
      Runtime.trap("Unauthorized: Login required");
    };
    SocietyBodyLib.getSocietyMembers(members);
  };

  // Any authenticated user can view active society body members
  public query ({ caller }) func getActiveSocietyMembers() : async [SocietyBodyTypes.SocietyMember] {
    if (not AccessControl.hasPermission(accessControlState, caller, #user)) {
      Runtime.trap("Unauthorized: Login required");
    };
    SocietyBodyLib.getActiveSocietyMembers(members);
  };

  // Admin-only: add a new society body member
  public shared ({ caller }) func addSocietyMember(
    nameMarathi : Text,
    nameEnglish : Text,
    role : SocietyBodyTypes.SocietyMemberRole,
    photoId : ?Text,
    contactPhone : ?Text,
    contactEmail : ?Text,
    orderNumber : Nat,
  ) : async Nat {
    if (not AccessControl.isAdmin(accessControlState, caller)) {
      Runtime.trap("Unauthorized: Only admins can add society members");
    };
    SocietyBodyLib.addSocietyMember(members, memberCounter, nameMarathi, nameEnglish, role, photoId, contactPhone, contactEmail, orderNumber);
  };

  // Admin-only: update a society body member's details
  public shared ({ caller }) func updateSocietyMember(member : SocietyBodyTypes.SocietyMember) : async () {
    if (not AccessControl.isAdmin(accessControlState, caller)) {
      Runtime.trap("Unauthorized: Only admins can update society members");
    };
    SocietyBodyLib.updateSocietyMember(members, member);
  };

  // Admin-only: remove a society body member (soft delete)
  public shared ({ caller }) func deleteSocietyMember(id : Nat) : async () {
    if (not AccessControl.isAdmin(accessControlState, caller)) {
      Runtime.trap("Unauthorized: Only admins can delete society members");
    };
    SocietyBodyLib.deleteSocietyMember(members, id);
  };

  // Admin-only: set or update the photo for a society body member
  public shared ({ caller }) func setSocietyMemberPhoto(id : Nat, photoId : ?Text) : async () {
    if (not AccessControl.isAdmin(accessControlState, caller)) {
      Runtime.trap("Unauthorized: Only admins can set member photos");
    };
    SocietyBodyLib.setSocietyMemberPhoto(members, id, photoId);
  };
};
