import List "mo:core/List";
import Time "mo:core/Time";
import Runtime "mo:core/Runtime";
import AccessControl "mo:caffeineai-authorization/access-control";
import Storage "mo:caffeineai-object-storage/Storage";
import ComplaintTypes "../types/complaints";
import CommonTypes "../types/common";
import ComplaintsLib "../lib/complaints";

mixin (
  accessControlState : AccessControl.AccessControlState,
  complaints : List.List<ComplaintTypes.Complaint>,
  complaintCounter : { var nextId : Nat },
) {
  public query ({ caller }) func getAllComplaints() : async [ComplaintTypes.Complaint] {
    if (not AccessControl.isAdmin(accessControlState, caller)) {
      Runtime.trap("Unauthorized: Only admins or committee members can view all complaints");
    };
    ComplaintsLib.getAllComplaints(complaints);
  };

  public query ({ caller }) func getComplaintsByFlat(flatNumber : CommonTypes.FlatNumber) : async [ComplaintTypes.Complaint] {
    if (not AccessControl.hasPermission(accessControlState, caller, #user)) {
      Runtime.trap("Unauthorized: Must be logged in");
    };
    ComplaintsLib.getComplaintsByFlat(complaints, flatNumber);
  };

  public query ({ caller }) func getComplaintById(complaintId : Nat) : async ?ComplaintTypes.Complaint {
    if (not AccessControl.hasPermission(accessControlState, caller, #user)) {
      Runtime.trap("Unauthorized: Must be logged in");
    };
    ComplaintsLib.getComplaintById(complaints, complaintId);
  };

  public query ({ caller }) func getMyComplaints() : async [ComplaintTypes.Complaint] {
    if (not AccessControl.hasPermission(accessControlState, caller, #user)) {
      Runtime.trap("Unauthorized: Must be logged in");
    };
    ComplaintsLib.getComplaintsByPrincipal(complaints, caller);
  };

  public shared ({ caller }) func createComplaint(
    flatNumber : CommonTypes.FlatNumber,
    category : CommonTypes.ComplaintCategory,
    description : Text,
    photoId : ?Storage.ExternalBlob,
  ) : async Nat {
    if (not AccessControl.hasPermission(accessControlState, caller, #user)) {
      Runtime.trap("Unauthorized: Must be a resident to file a complaint");
    };
    let id = complaintCounter.nextId;
    complaintCounter.nextId += 1;
    ComplaintsLib.createComplaint(
      complaints,
      id,
      flatNumber,
      caller,
      category,
      description,
      photoId,
      Time.now(),
    );
  };

  public shared ({ caller }) func updateComplaintStatus(complaintId : Nat, status : CommonTypes.ComplaintStatus) : async () {
    if (not AccessControl.isAdmin(accessControlState, caller)) {
      Runtime.trap("Unauthorized: Only admins or committee members can update complaint status");
    };
    ComplaintsLib.updateComplaintStatus(complaints, complaintId, status, Time.now());
  };
};
