import Debug "mo:core/Debug";
import Map "mo:core/Map";
import List "mo:core/List";
import Runtime "mo:core/Runtime";
import Time "mo:core/Time";
import AccessControl "mo:caffeineai-authorization/access-control";
import BillingLib "../lib/billing";
import BillingTypes "../types/billing";
import ResidentTypes "../types/residents";
import CommonTypes "../types/common";

mixin (
  accessControlState : AccessControl.AccessControlState,
  bills : List.List<BillingTypes.Bill>,
  flats : Map.Map<CommonTypes.FlatNumber, ResidentTypes.Flat>,
  billCounter : { var nextId : Nat },
  residents : List.List<ResidentTypes.Resident>,
) {
  // Residents can view their own flat bills; admins can view any flat
  public query ({ caller }) func getBillsByFlat(flatNumber : CommonTypes.FlatNumber) : async [BillingTypes.Bill] {
    if (not AccessControl.hasPermission(accessControlState, caller, #user)) {
      Runtime.trap("Unauthorized");
    };
    BillingLib.getBillsByFlat(bills, flatNumber);
  };

  // Any authenticated user can look up a specific bill by ID
  public query ({ caller }) func getBillById(billId : Nat) : async ?BillingTypes.Bill {
    if (not AccessControl.hasPermission(accessControlState, caller, #user)) {
      Runtime.trap("Unauthorized");
    };
    BillingLib.getBillById(bills, billId);
  };

  // Admin-only: view all unpaid bills across the society
  public query ({ caller }) func getAllUnpaidBills() : async [BillingTypes.Bill] {
    if (not AccessControl.hasPermission(accessControlState, caller, #admin)) {
      Runtime.trap("Unauthorized: Only admins can view all unpaid bills");
    };
    BillingLib.getAllUnpaidBills(bills);
  };

  // Public query: returns overdue member report for admin Overdue Summary and BillingPage
  public query ({ caller }) func getOverdueBillsWithResidents() : async [BillingTypes.OverdueMemberReport] {
    if (not AccessControl.hasPermission(accessControlState, caller, #user)) {
      Runtime.trap("Unauthorized");
    };
    BillingLib.getOverdueBillsWithResidents(bills, residents);
  };

  // Admin-only: generate monthly maintenance bills for all registered flats
  public shared ({ caller }) func generateMonthlyBills(amount : Nat, dueDate : CommonTypes.Timestamp) : async () {
    if (not AccessControl.hasPermission(accessControlState, caller, #admin)) {
      Runtime.trap("Unauthorized: Only admins can generate bills");
    };
    // Project flats map to bare key map for billing lib
    let flatKeys = Map.empty<CommonTypes.FlatNumber, {}>();
    for ((flatNumber, _) in flats.entries()) {
      flatKeys.add(flatNumber, {});
    };
    billCounter.nextId := BillingLib.generateMonthlyBills(bills, flatKeys, billCounter.nextId, amount, dueDate);
  };

  // Any authenticated resident can record payment for a bill
  public shared ({ caller }) func recordPayment(billId : Nat, paymentMethod : Text, transactionId : Text) : async () {
    if (not AccessControl.hasPermission(accessControlState, caller, #user)) {
      Runtime.trap("Unauthorized");
    };
    BillingLib.recordPayment(bills, billId, paymentMethod, transactionId);
  };

  // Admin-only: apply overdue penalties to all unpaid/overdue bills
  public shared ({ caller }) func applyPenalties() : async () {
    if (not AccessControl.hasPermission(accessControlState, caller, #admin)) {
      Runtime.trap("Unauthorized: Only admins can apply penalties");
    };
    BillingLib.applyPenalties(bills, Time.now());
  };
};
