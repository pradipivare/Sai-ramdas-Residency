import List "mo:core/List";
import Time "mo:core/Time";
import Runtime "mo:core/Runtime";
import AccessControl "mo:caffeineai-authorization/access-control";
import NoticeTypes "../types/notices";
import CommonTypes "../types/common";
import NoticeLib "../lib/notices";

mixin (
  accessControlState : AccessControl.AccessControlState,
  notices : List.List<NoticeTypes.Notice>,
  noticeCounter : { var nextId : Nat },
) {
  public query ({ caller }) func getAllNotices() : async [NoticeTypes.Notice] {
    if (not AccessControl.hasPermission(accessControlState, caller, #user)) {
      Runtime.trap("Unauthorized: Login required");
    };
    NoticeLib.getAllNotices(notices);
  };

  public query ({ caller }) func getPinnedNotices() : async [NoticeTypes.Notice] {
    if (not AccessControl.hasPermission(accessControlState, caller, #user)) {
      Runtime.trap("Unauthorized: Login required");
    };
    NoticeLib.getPinnedNotices(notices);
  };

  public shared ({ caller }) func createNotice(
    title : Text,
    content : Text,
    noticeType : CommonTypes.NoticeType,
    isPinned : Bool,
  ) : async Nat {
    if (
      not AccessControl.isAdmin(accessControlState, caller) and
      not AccessControl.hasPermission(accessControlState, caller, #admin)
    ) {
      Runtime.trap("Unauthorized: Only admins or committee members can create notices");
    };
    let newId = noticeCounter.nextId;
    noticeCounter.nextId := NoticeLib.createNotice(notices, noticeCounter.nextId, title, content, noticeType, caller, isPinned, Time.now());
    newId;
  };

  public shared ({ caller }) func updateNotice(
    noticeId : Nat,
    title : Text,
    content : Text,
    noticeType : CommonTypes.NoticeType,
    isPinned : Bool,
  ) : async () {
    if (not AccessControl.isAdmin(accessControlState, caller)) {
      Runtime.trap("Unauthorized: Only admins or committee members can update notices");
    };
    NoticeLib.updateNotice(notices, noticeId, title, content, noticeType, isPinned);
  };

  public shared ({ caller }) func deleteNotice(noticeId : Nat) : async () {
    if (not AccessControl.isAdmin(accessControlState, caller)) {
      Runtime.trap("Unauthorized: Only admins or committee members can delete notices");
    };
    NoticeLib.deleteNotice(notices, noticeId);
  };
};
