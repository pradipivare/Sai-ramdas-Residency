import Map "mo:core/Map";
import List "mo:core/List";
import Runtime "mo:core/Runtime";
import Principal "mo:core/Principal";
import AccessControl "mo:caffeineai-authorization/access-control";
import Storage "mo:caffeineai-object-storage/Storage";
import ResidentTypes "../types/residents";
import CommonTypes "../types/common";
import ResidentLib "../lib/residents";

mixin (
  accessControlState : AccessControl.AccessControlState,
  flats : Map.Map<CommonTypes.FlatNumber, ResidentTypes.Flat>,
  residents : List.List<ResidentTypes.Resident>,
  residentCounter : { var nextId : Nat },
) {
  public query ({ caller }) func getAllFlats() : async [ResidentTypes.Flat] {
    if (not AccessControl.hasPermission(accessControlState, caller, #user)) {
      Runtime.trap("Unauthorized: Login required");
    };
    ResidentLib.getAllFlats(flats);
  };

  public query ({ caller }) func getFlatDetails(flatNumber : CommonTypes.FlatNumber) : async ?ResidentTypes.Flat {
    if (not AccessControl.hasPermission(accessControlState, caller, #user)) {
      Runtime.trap("Unauthorized: Login required");
    };
    ResidentLib.getFlatDetails(flats, flatNumber);
  };

  public shared ({ caller }) func addFlat(flat : ResidentTypes.Flat) : async () {
    if (not AccessControl.isAdmin(accessControlState, caller)) {
      Runtime.trap("Unauthorized: Only admins can add flats");
    };
    ResidentLib.addFlat(flats, flat);
  };

  public shared ({ caller }) func updateFlat(flat : ResidentTypes.Flat) : async () {
    if (not AccessControl.isAdmin(accessControlState, caller)) {
      Runtime.trap("Unauthorized: Only admins can update flats");
    };
    ResidentLib.updateFlat(flats, flat);
  };

  public shared ({ caller }) func deleteFlat(flatNumber : CommonTypes.FlatNumber) : async () {
    if (not AccessControl.isAdmin(accessControlState, caller)) {
      Runtime.trap("Unauthorized: Only admins can delete flats");
    };
    ResidentLib.deleteFlat(flats, flatNumber);
  };

  public query ({ caller }) func getAllResidents() : async [ResidentTypes.Resident] {
    if (not AccessControl.hasPermission(accessControlState, caller, #user)) {
      Runtime.trap("Unauthorized: Login required");
    };
    ResidentLib.getAllResidents(residents);
  };

  public query ({ caller }) func getResidentByFlat(flatNumber : CommonTypes.FlatNumber) : async ?ResidentTypes.Resident {
    if (not AccessControl.hasPermission(accessControlState, caller, #user)) {
      Runtime.trap("Unauthorized: Login required");
    };
    ResidentLib.getResidentByFlat(residents, flatNumber);
  };

  public shared ({ caller }) func addResident(
    flatNumber : CommonTypes.FlatNumber,
    name : Text,
    mobile : Text,
    email : Text,
    residencyType : CommonTypes.ResidencyType,
    familyMembersCount : Nat,
    kycDocumentId : ?Storage.ExternalBlob,
    photoId : ?Text,
  ) : async Nat {
    if (not AccessControl.isAdmin(accessControlState, caller)) {
      Runtime.trap("Unauthorized: Only admins can add residents");
    };
    let stub : ResidentTypes.Resident = {
      residentId = 0;
      principal = caller;
      flatNumber;
      name;
      mobile;
      email;
      residencyType;
      familyMembersCount;
      kycDocumentId;
      photoId;
    };
    residentCounter.nextId := ResidentLib.addResident(residents, residentCounter.nextId, stub);
    residentCounter.nextId - 1;
  };

  public shared ({ caller }) func updateResident(resident : ResidentTypes.Resident) : async () {
    if (not AccessControl.isAdmin(accessControlState, caller)) {
      Runtime.trap("Unauthorized: Only admins can update residents");
    };
    ResidentLib.updateResident(residents, resident);
  };

  public query ({ caller }) func getResidentPhoto(residentId : Nat) : async ?Text {
    let isAdmin = AccessControl.isAdmin(accessControlState, caller);
    let isSelf = switch (residents.find(func(r) { r.residentId == residentId })) {
      case (?r) Principal.equal(r.principal, caller);
      case null false;
    };
    if (not isAdmin and not isSelf) {
      Runtime.trap("Unauthorized: Only admins or the resident themselves can view this photo");
    };
    ResidentLib.getResidentPhoto(residents, residentId);
  };

  public shared ({ caller }) func deleteResident(residentId : Nat) : async () {
    if (not AccessControl.isAdmin(accessControlState, caller)) {
      Runtime.trap("Unauthorized: Only admins can delete residents");
    };
    ResidentLib.deleteResident(residents, residentId);
  };
};
