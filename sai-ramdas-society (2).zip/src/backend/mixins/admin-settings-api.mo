import List "mo:core/List";
import Map "mo:core/Map";
import Nat "mo:core/Nat";
import Runtime "mo:core/Runtime";
import Time "mo:core/Time";
import AccessControl "mo:caffeineai-authorization/access-control";
import AdminSettingsLib "../lib/admin-settings";
import AdminSettingsTypes "../types/admin-settings";

mixin (
  accessControlState : AccessControl.AccessControlState,
  settings : Map.Map<Text, AdminSettingsTypes.AdminSetting>,
  actionLog : List.List<AdminSettingsTypes.AdminActionLog>,
  actionLogCounter : { var nextId : Nat },
  adminUsers : Map.Map<Text, AdminSettingsTypes.AdminUser>,
  adminUserCounter : { var nextId : Nat },
) {
  // Initialize default settings
  do {
    if (settings.isEmpty()) {
      let anonymousPrincipal = Principal.anonymous();
      let now = Time.now();
      settings.add("requireAdminApproval", {
        key = "requireAdminApproval";
        value = "false";
        updatedBy = anonymousPrincipal;
        updatedAt = now;
      });
    };
  };

  // Admin-only: retrieve a single setting by key
  public query ({ caller }) func getAdminSetting(key : Text) : async ?AdminSettingsTypes.AdminSetting {
    if (not AccessControl.isAdmin(accessControlState, caller)) {
      Runtime.trap("Unauthorized: Only admins can view settings");
    };
    AdminSettingsLib.getAdminSetting(settings, key);
  };

  // Admin-only: create or update a setting key/value pair
  public shared ({ caller }) func setAdminSetting(key : Text, value : Text) : async () {
    if (not AccessControl.isAdmin(accessControlState, caller)) {
      Runtime.trap("Unauthorized: Only admins can change settings");
    };
    let now = Time.now();
    AdminSettingsLib.setAdminSetting(settings, key, value, caller, now);
    ignore AdminSettingsLib.logAdminAction(
      actionLog,
      actionLogCounter,
      "SET_SETTING",
      caller,
      null,
      "Key: " # key # " Value: " # value,
      now,
    );
  };

  // Admin-only: verify the admin PIN against the stored hash (kept for backward compatibility)
  public shared ({ caller }) func verifyAdminPin(pinHash : Text) : async Bool {
    if (not AccessControl.isAdmin(accessControlState, caller)) {
      Runtime.trap("Unauthorized: Only admins can verify PIN");
    };
    AdminSettingsLib.verifyAdminPin(settings, pinHash);
  };

  // Admin-only: set a new admin PIN (kept for backward compatibility)
  public shared ({ caller }) func setAdminPin(newPinHash : Text) : async () {
    if (not AccessControl.isAdmin(accessControlState, caller)) {
      Runtime.trap("Unauthorized: Only admins can set PIN");
    };
    let now = Time.now();
    AdminSettingsLib.setAdminPin(settings, newPinHash, caller, now);
    ignore AdminSettingsLib.logAdminAction(
      actionLog,
      actionLogCounter,
      "SET_ADMIN_PIN",
      caller,
      null,
      "Admin PIN updated",
      now,
    );
  };

  // Admin-only: retrieve the full admin action audit log
  public query ({ caller }) func getAdminActionLog() : async [AdminSettingsTypes.AdminActionLog] {
    if (not AccessControl.isAdmin(accessControlState, caller)) {
      Runtime.trap("Unauthorized: Only admins can view the action log");
    };
    AdminSettingsLib.getAdminActionLog(actionLog);
  };

  // Admin-only: set the total number of flats override
  public shared ({ caller }) func setTotalFlatsOverride(count : ?Nat) : async () {
    if (not AccessControl.isAdmin(accessControlState, caller)) {
      Runtime.trap("Unauthorized: Only admins can set total flats override");
    };
    let now = Time.now();
    let value = switch (count) {
      case (?n) n.toText();
      case null "";
    };
    AdminSettingsLib.setAdminSetting(settings, "totalFlatsOverride", value, caller, now);
    ignore AdminSettingsLib.logAdminAction(
      actionLog,
      actionLogCounter,
      "SET_TOTAL_FLATS_OVERRIDE",
      caller,
      null,
      "Total flats override set to: " # value,
      now,
    );
  };

  // Public: get the total flats override (readable by all roles)
  public query func getTotalFlatsOverride() : async ?Nat {
    switch (AdminSettingsLib.getAdminSetting(settings, "totalFlatsOverride")) {
      case (?setting) {
        if (setting.value == "") null
        else Nat.fromText(setting.value);
      };
      case null null;
    };
  };

  // Admin-only: set the total number of shops override
  public shared ({ caller }) func setTotalShopsOverride(count : ?Nat) : async () {
    if (not AccessControl.isAdmin(accessControlState, caller)) {
      Runtime.trap("Unauthorized: Only admins can set total shops override");
    };
    let now = Time.now();
    let value = switch (count) {
      case (?n) n.toText();
      case null "";
    };
    AdminSettingsLib.setAdminSetting(settings, "totalShopsOverride", value, caller, now);
    ignore AdminSettingsLib.logAdminAction(
      actionLog,
      actionLogCounter,
      "SET_TOTAL_SHOPS_OVERRIDE",
      caller,
      null,
      "Total shops override set to: " # value,
      now,
    );
  };

  // Public: get the total shops override (readable by all roles); defaults to 0 when not set
  public query func getTotalShopsOverride() : async Nat {
    switch (AdminSettingsLib.getAdminSetting(settings, "totalShopsOverride")) {
      case (?setting) {
        if (setting.value == "") 0
        else switch (Nat.fromText(setting.value)) {
          case (?n) n;
          case null 0;
        };
      };
      case null 0;
    };
  };

  // ── Admin User Management API ─────────────────────────────────────────────

  /// Add a new admin user (username + password hash).
  /// Only an already-authenticated admin can call this.
  /// Maximum 3 active admin users allowed at any time.
  public shared ({ caller }) func addAdminUser(username : Text, passwordHash : Text) : async { #ok : Text; #err : Text } {
    if (not AccessControl.isAdmin(accessControlState, caller)) {
      Runtime.trap("Unauthorized: Only admins can add admin users");
    };
    let now = Time.now();
    let result = AdminSettingsLib.addAdminUser(adminUsers, adminUserCounter, username, passwordHash, now);
    switch (result) {
      case (#ok(id)) {
        ignore AdminSettingsLib.logAdminAction(
          actionLog,
          actionLogCounter,
          "ADD_ADMIN_USER",
          caller,
          null,
          "Added admin user: " # username # " (id: " # id # ")",
          now,
        );
      };
      case (#err(_)) {};
    };
    result;
  };

  /// Remove (deactivate) an admin user by id.
  /// Only an already-authenticated admin can call this.
  /// At least one admin must remain — cannot remove the last active admin.
  public shared ({ caller }) func removeAdminUser(id : Text) : async { #ok; #err : Text } {
    if (not AccessControl.isAdmin(accessControlState, caller)) {
      Runtime.trap("Unauthorized: Only admins can remove admin users");
    };
    // Guard: prevent removing the last active admin
    if (AdminSettingsLib.countActiveAdmins(adminUsers) <= 1) {
      return #err("Cannot remove the last active admin user");
    };
    let now = Time.now();
    let result = AdminSettingsLib.removeAdminUser(adminUsers, id);
    switch (result) {
      case (#ok) {
        ignore AdminSettingsLib.logAdminAction(
          actionLog,
          actionLogCounter,
          "REMOVE_ADMIN_USER",
          caller,
          null,
          "Removed admin user id: " # id,
          now,
        );
      };
      case (#err(_)) {};
    };
    result;
  };

  /// Verify admin credentials (username + password hash).
  /// Public — used during login flow (no existing session required).
  public shared func verifyAdminCredentials(username : Text, passwordHash : Text) : async Bool {
    AdminSettingsLib.verifyAdminCredentials(adminUsers, username, passwordHash);
  };

  /// List all active admin users (no passwords returned).
  /// Only an already-authenticated admin can call this.
  public query ({ caller }) func listAdminUsers() : async [AdminSettingsTypes.AdminUserView] {
    if (not AccessControl.isAdmin(accessControlState, caller)) {
      Runtime.trap("Unauthorized: Only admins can list admin users");
    };
    AdminSettingsLib.listAdminUsers(adminUsers);
  };

  /// Get the count of active admin users.
  public query func getAdminUserCount() : async Nat {
    AdminSettingsLib.countActiveAdmins(adminUsers);
  };
};
