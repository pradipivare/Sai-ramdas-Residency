import CommonTypes "common";
import Storage "mo:caffeineai-object-storage/Storage";

module {
  public type Complaint = {
    complaintId : Nat;
    flatNumber : CommonTypes.FlatNumber;
    residentPrincipal : Principal;
    category : CommonTypes.ComplaintCategory;
    description : Text;
    photoId : ?Storage.ExternalBlob;
    status : CommonTypes.ComplaintStatus;
    createdAt : CommonTypes.Timestamp;
    updatedAt : CommonTypes.Timestamp;
  };
};
