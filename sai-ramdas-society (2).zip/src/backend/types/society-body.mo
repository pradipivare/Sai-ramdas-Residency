module {
  public type SocietyMemberRole = {
    #chairman;
    #viceChairman;
    #secretary;
    #treasurer;
    #member;
  };

  public type SocietyMember = {
    id : Nat;
    nameMarathi : Text;
    nameEnglish : Text;
    role : SocietyMemberRole;
    photoId : ?Text;
    contactPhone : ?Text;
    contactEmail : ?Text;
    orderNumber : Nat;
    isActive : Bool;
  };
};
