module {
  public type SocietyRule = {
    id : Nat;
    titleMarathi : Text;
    titleEnglish : Text;
    descriptionMarathi : Text;
    descriptionEnglish : Text;
    category : Text;
    tags : [Text];
    orderNumber : Nat;
    isActive : Bool;
    createdAt : Int;
    updatedAt : Int;
  };
};
