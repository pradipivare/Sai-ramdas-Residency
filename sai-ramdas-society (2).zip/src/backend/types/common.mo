module {
  public type Timestamp = Int;
  public type FlatNumber = Text;

  public type ResidencyType = {
    #owner;
    #tenant;
  };

  public type BillStatus = {
    #unpaid;
    #paid;
    #overdue;
  };

  public type ComplaintCategory = {
    #water;
    #lift;
    #power;
    #other;
  };

  public type ComplaintStatus = {
    #pending;
    #inProgress;
    #resolved;
  };

  public type ApprovalStatus = {
    #pending;
    #approved;
    #rejected;
  };

  public type NoticeType = {
    #regular;
    #emergency;
    #event;
  };

  public type UserRole = {
    #admin;
    #committeeMember;
    #resident;
    #securityGuard;
  };
};
