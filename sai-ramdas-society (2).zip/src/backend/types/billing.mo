import CommonTypes "common";

module {
  public type Bill = {
    billId : Nat;
    flatNumber : CommonTypes.FlatNumber;
    amount : Nat;
    dueDate : CommonTypes.Timestamp;
    issuedDate : CommonTypes.Timestamp;
    status : CommonTypes.BillStatus;
    paidDate : ?CommonTypes.Timestamp;
    penaltyAmount : Nat;
  };

  public type PaymentRecord = {
    billId : Nat;
    paymentMethod : Text;
    transactionId : Text;
    paidAt : CommonTypes.Timestamp;
  };

  public type OverdueMemberReport = {
    billId : Nat;
    flatNumber : CommonTypes.FlatNumber;
    residentName : Text;
    mobile : Text;
    amount : Nat;
    dueDate : CommonTypes.Timestamp;
    penaltyAmount : Nat;
  };
};
