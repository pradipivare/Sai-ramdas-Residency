module {
  public type AdminSetting = {
    key : Text;
    value : Text;
    updatedBy : Principal;
    updatedAt : Int;
  };

  public type AdminActionLog = {
    id : Nat;
    action : Text;
    performedBy : Principal;
    targetPrincipal : ?Principal;
    details : Text;
    timestamp : Int;
  };

  // Admin user record — stored in stable Map keyed by id (Text UUID)
  public type AdminUser = {
    id : Text;
    var username : Text;
    var passwordHash : Text;
    createdAt : Int;
    var isActive : Bool;
  };

  // Public-safe view of an admin user (no password hash)
  public type AdminUserView = {
    id : Text;
    username : Text;
    createdAt : Int;
  };
};
