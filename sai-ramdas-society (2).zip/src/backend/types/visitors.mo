import CommonTypes "common";

module {
  public type Visitor = {
    visitorId : Nat;
    name : Text;
    mobile : Text;
    flatVisiting : CommonTypes.FlatNumber;
    purpose : Text;
    entryTime : CommonTypes.Timestamp;
    exitTime : ?CommonTypes.Timestamp;
    approvalStatus : CommonTypes.ApprovalStatus;
    otpCode : Text;
    loggedBy : Principal;
  };

  public type PreApprovedGuest = {
    guestId : Nat;
    flatNumber : CommonTypes.FlatNumber;
    name : Text;
    mobile : Text;
    relationship : Text;
  };
};
