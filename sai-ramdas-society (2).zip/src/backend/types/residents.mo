import CommonTypes "common";
import Storage "mo:caffeineai-object-storage/Storage";

module {
  public type Flat = {
    flatNumber : CommonTypes.FlatNumber;
    wing : Text;
    floor : Nat;
    ownerName : Text;
  };

  public type Resident = {
    residentId : Nat;
    principal : Principal;
    flatNumber : CommonTypes.FlatNumber;
    name : Text;
    mobile : Text;
    email : Text;
    residencyType : CommonTypes.ResidencyType;
    familyMembersCount : Nat;
    kycDocumentId : ?Storage.ExternalBlob;
    photoId : ?Text;
  };
};
