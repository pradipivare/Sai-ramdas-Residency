import CommonTypes "common";

module {
  public type Notice = {
    noticeId : Nat;
    title : Text;
    content : Text;
    noticeType : CommonTypes.NoticeType;
    postedBy : Principal;
    postedAt : CommonTypes.Timestamp;
    isPinned : Bool;
  };
};
