import List "mo:core/List";
import Time "mo:core/Time";
import SocietyRulesTypes "../types/society-rules";

module {
  public func getSocietyRules(
    rules : List.List<SocietyRulesTypes.SocietyRule>,
  ) : [SocietyRulesTypes.SocietyRule] {
    rules.toArray();
  };

  public func getSocietyRulesByCategory(
    rules : List.List<SocietyRulesTypes.SocietyRule>,
    category : Text,
  ) : [SocietyRulesTypes.SocietyRule] {
    rules.filter(func(r) { r.category == category }).toArray();
  };

  public func addSocietyRule(
    rules : List.List<SocietyRulesTypes.SocietyRule>,
    counter : { var nextId : Nat },
    titleMarathi : Text,
    titleEnglish : Text,
    descriptionMarathi : Text,
    descriptionEnglish : Text,
    category : Text,
    tags : [Text],
    orderNumber : Nat,
  ) : Nat {
    let id = counter.nextId;
    counter.nextId += 1;
    let now = Time.now();
    rules.add({
      id;
      titleMarathi;
      titleEnglish;
      descriptionMarathi;
      descriptionEnglish;
      category;
      tags;
      orderNumber;
      isActive = true;
      createdAt = now;
      updatedAt = now;
    });
    id;
  };

  public func updateSocietyRule(
    rules : List.List<SocietyRulesTypes.SocietyRule>,
    rule : SocietyRulesTypes.SocietyRule,
  ) : () {
    rules.mapInPlace(func(r) {
      if (r.id == rule.id) { { rule with updatedAt = Time.now() } } else { r }
    });
  };

  public func deleteSocietyRule(
    rules : List.List<SocietyRulesTypes.SocietyRule>,
    id : Nat,
  ) : () {
    rules.mapInPlace(func(r) {
      if (r.id == id) { { r with isActive = false; updatedAt = Time.now() } } else { r }
    });
  };
};
