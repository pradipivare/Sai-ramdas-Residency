import List "mo:core/List";
import SocietyBodyTypes "../types/society-body";

module {
  public func getSocietyMembers(
    members : List.List<SocietyBodyTypes.SocietyMember>,
  ) : [SocietyBodyTypes.SocietyMember] {
    members.toArray();
  };

  public func getActiveSocietyMembers(
    members : List.List<SocietyBodyTypes.SocietyMember>,
  ) : [SocietyBodyTypes.SocietyMember] {
    members.filter(func(m) { m.isActive }).toArray();
  };

  public func addSocietyMember(
    members : List.List<SocietyBodyTypes.SocietyMember>,
    counter : { var nextId : Nat },
    nameMarathi : Text,
    nameEnglish : Text,
    role : SocietyBodyTypes.SocietyMemberRole,
    photoId : ?Text,
    contactPhone : ?Text,
    contactEmail : ?Text,
    orderNumber : Nat,
  ) : Nat {
    let id = counter.nextId;
    counter.nextId += 1;
    members.add({
      id;
      nameMarathi;
      nameEnglish;
      role;
      photoId;
      contactPhone;
      contactEmail;
      orderNumber;
      isActive = true;
    });
    id;
  };

  public func updateSocietyMember(
    members : List.List<SocietyBodyTypes.SocietyMember>,
    member : SocietyBodyTypes.SocietyMember,
  ) : () {
    members.mapInPlace(func(m) {
      if (m.id == member.id) { member } else { m }
    });
  };

  public func deleteSocietyMember(
    members : List.List<SocietyBodyTypes.SocietyMember>,
    id : Nat,
  ) : () {
    members.mapInPlace(func(m) {
      if (m.id == id) { { m with isActive = false } } else { m }
    });
  };

  public func setSocietyMemberPhoto(
    members : List.List<SocietyBodyTypes.SocietyMember>,
    id : Nat,
    photoId : ?Text,
  ) : () {
    members.mapInPlace(func(m) {
      if (m.id == id) { { m with photoId } } else { m }
    });
  };
};
