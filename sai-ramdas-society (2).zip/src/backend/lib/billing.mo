import Map "mo:core/Map";
import List "mo:core/List";
import Int "mo:core/Int";
import Time "mo:core/Time";
import Types "../types/billing";
import CommonTypes "../types/common";
import ResidentTypes "../types/residents";

module {
  public func getAllBills(bills : List.List<Types.Bill>) : [Types.Bill] {
    bills.toArray();
  };

  public func getBillsByFlat(bills : List.List<Types.Bill>, flatNumber : CommonTypes.FlatNumber) : [Types.Bill] {
    bills.filter(func(b) { b.flatNumber == flatNumber }).toArray();
  };

  public func getBillById(bills : List.List<Types.Bill>, billId : Nat) : ?Types.Bill {
    bills.find(func(b) { b.billId == billId });
  };

  public func getAllUnpaidBills(bills : List.List<Types.Bill>) : [Types.Bill] {
    bills.filter(func(b) { b.status == #unpaid or b.status == #overdue }).toArray();
  };

  // Returns all overdue bills joined with resident data for admin Overdue Summary report
  public func getOverdueBillsWithResidents(
    bills : List.List<Types.Bill>,
    residents : List.List<ResidentTypes.Resident>,
  ) : [Types.OverdueMemberReport] {
    let now = Time.now();
    let overdueBills = bills.filter(func(b) {
      (b.status == #unpaid or b.status == #overdue) and now > b.dueDate
    });
    overdueBills.map<Types.Bill, Types.OverdueMemberReport>(func(bill) {
      let resident = residents.find(func(r) { r.flatNumber == bill.flatNumber });
      let (residentName, mobile) = switch (resident) {
        case (?r) (r.name, r.mobile);
        case null ("Unknown", "");
      };
      {
        billId = bill.billId;
        flatNumber = bill.flatNumber;
        residentName;
        mobile;
        amount = bill.amount;
        dueDate = bill.dueDate;
        penaltyAmount = bill.penaltyAmount;
      };
    }).toArray();
  };

  // Generates one bill per flat; returns the next available bill ID after generation
  public func generateMonthlyBills(
    bills : List.List<Types.Bill>,
    flats : Map.Map<CommonTypes.FlatNumber, {}>,
    nextId : Nat,
    amount : Nat,
    dueDate : CommonTypes.Timestamp,
  ) : Nat {
    let now = Time.now();
    var id = nextId;
    for ((flatNumber, _) in flats.entries()) {
      let bill : Types.Bill = {
        billId = id;
        flatNumber;
        amount;
        dueDate;
        issuedDate = now;
        status = #unpaid;
        paidDate = null;
        penaltyAmount = 0;
      };
      bills.add(bill);
      id += 1;
    };
    id;
  };

  public func recordPayment(bills : List.List<Types.Bill>, billId : Nat, _paymentMethod : Text, _transactionId : Text) : () {
    let now = Time.now();
    bills.mapInPlace(func(bill) {
      if (bill.billId == billId) {
        { bill with status = #paid; paidDate = ?now };
      } else {
        bill;
      };
    });
  };

  // Applies 5% penalty per month overdue to all unpaid/overdue bills past their dueDate
  public func applyPenalties(bills : List.List<Types.Bill>, now : CommonTypes.Timestamp) : () {
    let nanosPerMonth : Int = 30 * 24 * 60 * 60 * 1_000_000_000;
    bills.mapInPlace(func(bill) {
      if (bill.status == #unpaid or bill.status == #overdue) {
        let overdue : Int = now - bill.dueDate;
        if (overdue > 0) {
          // Number of full months overdue (at least 1)
          let months : Nat = Int.abs(overdue / nanosPerMonth) + 1;
          // 5% per month, computed on original amount
          let penalty : Nat = bill.amount * 5 * months / 100;
          { bill with status = #overdue; penaltyAmount = penalty };
        } else {
          bill;
        };
      } else {
        bill;
      };
    });
  };
};
