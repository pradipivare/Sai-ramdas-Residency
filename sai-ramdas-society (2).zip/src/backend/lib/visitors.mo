import List "mo:core/List";
import Int "mo:core/Int";
import Principal "mo:core/Principal";
import Runtime "mo:core/Runtime";
import Types "../types/visitors";
import CommonTypes "../types/common";
import ResidentTypes "../types/residents";

module {
  // Returns all visitors whose entry time falls within the same UTC day as `now` (nanoseconds)
  public func getTodayVisitors(visitors : List.List<Types.Visitor>, now : CommonTypes.Timestamp) : [Types.Visitor] {
    let oneDayNanos : Int = 86_400_000_000_000;
    let dayStart : Int = (now / oneDayNanos) * oneDayNanos;
    let dayEnd : Int = dayStart + oneDayNanos;
    visitors.filter(func(v) { v.entryTime >= dayStart and v.entryTime < dayEnd }).toArray();
  };

  public func getVisitorsByFlat(visitors : List.List<Types.Visitor>, flatNumber : CommonTypes.FlatNumber) : [Types.Visitor] {
    visitors.filter(func(v) { v.flatVisiting == flatNumber }).toArray();
  };

  // Derives a pseudo-random 4-digit OTP from the entry timestamp
  func generateOtp(now : CommonTypes.Timestamp) : Text {
    let seed : Nat = Int.abs(now) % 9000 + 1000;
    seed.toText();
  };

  public func logVisitorEntry(
    visitors : List.List<Types.Visitor>,
    nextId : Nat,
    name : Text,
    mobile : Text,
    flatVisiting : CommonTypes.FlatNumber,
    purpose : Text,
    loggedBy : Principal,
    now : CommonTypes.Timestamp,
  ) : (Nat, Text) {
    let otp = generateOtp(now);
    let visitor : Types.Visitor = {
      visitorId = nextId;
      name;
      mobile;
      flatVisiting;
      purpose;
      entryTime = now;
      exitTime = null;
      approvalStatus = #pending;
      otpCode = otp;
      loggedBy;
    };
    visitors.add(visitor);
    (nextId, otp);
  };

  // Validates OTP and that the caller is a resident of the flat being visited, then approves
  public func approveVisitor(
    visitors : List.List<Types.Visitor>,
    residents : List.List<ResidentTypes.Resident>,
    caller : Principal,
    visitorId : Nat,
    otpCode : Text,
  ) : () {
    let visitor = switch (visitors.find(func(v) { v.visitorId == visitorId })) {
      case (?v) v;
      case null Runtime.trap("Visitor not found");
    };
    if (visitor.approvalStatus != #pending) {
      Runtime.trap("Visitor is not in pending status");
    };
    let isResident = residents.find(func(r) {
      Principal.equal(r.principal, caller) and r.flatNumber == visitor.flatVisiting
    });
    switch (isResident) {
      case null Runtime.trap("Unauthorized: Only residents of the flat can approve visitors");
      case (?_) {};
    };
    if (visitor.otpCode != otpCode) {
      Runtime.trap("Invalid OTP code");
    };
    visitors.mapInPlace(func(v) {
      if (v.visitorId == visitorId) { { v with approvalStatus = #approved } } else { v }
    });
  };

  // Checks caller is a resident of the flat, then rejects the pending visitor
  public func rejectVisitor(
    visitors : List.List<Types.Visitor>,
    residents : List.List<ResidentTypes.Resident>,
    caller : Principal,
    visitorId : Nat,
  ) : () {
    let visitor = switch (visitors.find(func(v) { v.visitorId == visitorId })) {
      case (?v) v;
      case null Runtime.trap("Visitor not found");
    };
    if (visitor.approvalStatus != #pending) {
      Runtime.trap("Visitor is not in pending status");
    };
    let isResident = residents.find(func(r) {
      Principal.equal(r.principal, caller) and r.flatNumber == visitor.flatVisiting
    });
    switch (isResident) {
      case null Runtime.trap("Unauthorized: Only residents of the flat can reject visitors");
      case (?_) {};
    };
    visitors.mapInPlace(func(v) {
      if (v.visitorId == visitorId) { { v with approvalStatus = #rejected } } else { v }
    });
  };

  public func logVisitorExit(visitors : List.List<Types.Visitor>, visitorId : Nat, now : CommonTypes.Timestamp) : () {
    switch (visitors.find(func(v) { v.visitorId == visitorId })) {
      case null Runtime.trap("Visitor not found");
      case (?visitor) {
        if (visitor.exitTime != null) {
          Runtime.trap("Visitor has already exited");
        };
      };
    };
    visitors.mapInPlace(func(v) {
      if (v.visitorId == visitorId) { { v with exitTime = ?now } } else { v }
    });
  };

  public func getPreApprovedGuests(guests : List.List<Types.PreApprovedGuest>, flatNumber : CommonTypes.FlatNumber) : [Types.PreApprovedGuest] {
    guests.filter(func(g) { g.flatNumber == flatNumber }).toArray();
  };

  public func addPreApprovedGuest(
    guests : List.List<Types.PreApprovedGuest>,
    nextId : Nat,
    flatNumber : CommonTypes.FlatNumber,
    name : Text,
    mobile : Text,
    relationship : Text,
  ) : Nat {
    let guest : Types.PreApprovedGuest = {
      guestId = nextId;
      flatNumber;
      name;
      mobile;
      relationship;
    };
    guests.add(guest);
    nextId;
  };

  // Removes a pre-approved guest by clearing and re-adding all others
  public func removePreApprovedGuest(guests : List.List<Types.PreApprovedGuest>, guestId : Nat) : () {
    switch (guests.find(func(g) { g.guestId == guestId })) {
      case null Runtime.trap("Pre-approved guest not found");
      case (?_) {};
    };
    let kept = guests.filter(func(g) { g.guestId != guestId });
    guests.clear();
    guests.append(kept);
  };
};
