import Map "mo:core/Map";
import List "mo:core/List";
import Iter "mo:core/Iter";
import Types "../types/residents";
import CommonTypes "../types/common";

module {
  public func getAllFlats(flats : Map.Map<CommonTypes.FlatNumber, Types.Flat>) : [Types.Flat] {
    flats.values().toArray();
  };

  public func getFlatDetails(flats : Map.Map<CommonTypes.FlatNumber, Types.Flat>, flatNumber : CommonTypes.FlatNumber) : ?Types.Flat {
    flats.get(flatNumber);
  };

  public func addFlat(flats : Map.Map<CommonTypes.FlatNumber, Types.Flat>, flat : Types.Flat) : () {
    flats.add(flat.flatNumber, flat);
  };

  public func updateFlat(flats : Map.Map<CommonTypes.FlatNumber, Types.Flat>, flat : Types.Flat) : () {
    flats.add(flat.flatNumber, flat);
  };

  public func deleteFlat(flats : Map.Map<CommonTypes.FlatNumber, Types.Flat>, flatNumber : CommonTypes.FlatNumber) : () {
    flats.remove(flatNumber);
  };

  public func getAllResidents(residents : List.List<Types.Resident>) : [Types.Resident] {
    residents.toArray();
  };

  public func getResidentByFlat(residents : List.List<Types.Resident>, flatNumber : CommonTypes.FlatNumber) : ?Types.Resident {
    residents.find(func(r) { r.flatNumber == flatNumber });
  };

  public func addResident(residents : List.List<Types.Resident>, nextId : Nat, resident : Types.Resident) : Nat {
    let newResident = { resident with residentId = nextId };
    residents.add(newResident);
    nextId + 1;
  };

  public func getResidentPhoto(residents : List.List<Types.Resident>, residentId : Nat) : ?Text {
    switch (residents.find(func(r) { r.residentId == residentId })) {
      case (?r) r.photoId;
      case null null;
    };
  };

  public func updateResident(residents : List.List<Types.Resident>, resident : Types.Resident) : () {
    residents.mapInPlace(
      func(r) {
        if (r.residentId == resident.residentId) { resident } else { r };
      }
    );
  };

  public func deleteResident(residents : List.List<Types.Resident>, residentId : Nat) : () {
    let filtered = residents.filter(func(r) { r.residentId != residentId });
    residents.clear();
    residents.append(filtered);
  };
};
