import List "mo:core/List";
import Map "mo:core/Map";
import Time "mo:core/Time";
import AdminSettingsTypes "../types/admin-settings";

module {
  public func getAdminSetting(
    settings : Map.Map<Text, AdminSettingsTypes.AdminSetting>,
    key : Text,
  ) : ?AdminSettingsTypes.AdminSetting {
    settings.get(key);
  };

  public func setAdminSetting(
    settings : Map.Map<Text, AdminSettingsTypes.AdminSetting>,
    key : Text,
    value : Text,
    updatedBy : Principal,
    now : Int,
  ) : () {
    settings.add(key, { key; value; updatedBy; updatedAt = now });
  };

  public func verifyAdminPin(
    settings : Map.Map<Text, AdminSettingsTypes.AdminSetting>,
    pinHash : Text,
  ) : Bool {
    switch (settings.get("adminPinHash")) {
      case (?setting) { setting.value == pinHash };
      case null { false };
    };
  };

  public func setAdminPin(
    settings : Map.Map<Text, AdminSettingsTypes.AdminSetting>,
    newPinHash : Text,
    updatedBy : Principal,
    now : Int,
  ) : () {
    settings.add("adminPinHash", { key = "adminPinHash"; value = newPinHash; updatedBy; updatedAt = now });
  };

  public func logAdminAction(
    actionLog : List.List<AdminSettingsTypes.AdminActionLog>,
    counter : { var nextId : Nat },
    action : Text,
    performedBy : Principal,
    targetPrincipal : ?Principal,
    details : Text,
    now : Int,
  ) : Nat {
    let id = counter.nextId;
    counter.nextId += 1;
    actionLog.add({
      id;
      action;
      performedBy;
      targetPrincipal;
      details;
      timestamp = now;
    });
    id;
  };

  public func getAdminActionLog(
    actionLog : List.List<AdminSettingsTypes.AdminActionLog>,
  ) : [AdminSettingsTypes.AdminActionLog] {
    actionLog.toArray();
  };

  // ── Admin User Management ────────────────────────────────────────────────

  let MAX_ADMIN_USERS : Nat = 3;

  /// Count active admin users
  public func countActiveAdmins(
    adminUsers : Map.Map<Text, AdminSettingsTypes.AdminUser>
  ) : Nat {
    var count = 0;
    for ((_, user) in adminUsers.entries()) {
      if (user.isActive) count += 1;
    };
    count;
  };

  /// Add a new admin user. Returns #ok(id) or #err(reason).
  public func addAdminUser(
    adminUsers : Map.Map<Text, AdminSettingsTypes.AdminUser>,
    counter : { var nextId : Nat },
    username : Text,
    passwordHash : Text,
    now : Int,
  ) : { #ok : Text; #err : Text } {
    if (countActiveAdmins(adminUsers) >= MAX_ADMIN_USERS) {
      return #err("Maximum of " # MAX_ADMIN_USERS.toText() # " admin users already exist");
    };
    // Check for duplicate username
    for ((_, user) in adminUsers.entries()) {
      if (user.isActive and user.username == username) {
        return #err("Username already exists");
      };
    };
    let id = "admin-" # counter.nextId.toText();
    counter.nextId += 1;
    adminUsers.add(id, {
      id;
      var username;
      var passwordHash;
      createdAt = now;
      var isActive = true;
    });
    #ok(id);
  };

  /// Remove (deactivate) an admin user by id. Returns #ok or #err.
  public func removeAdminUser(
    adminUsers : Map.Map<Text, AdminSettingsTypes.AdminUser>,
    id : Text,
  ) : { #ok; #err : Text } {
    switch (adminUsers.get(id)) {
      case (?user) {
        user.isActive := false;
        #ok;
      };
      case null {
        #err("Admin user not found");
      };
    };
  };

  /// Verify username + password hash against stored admin users.
  public func verifyAdminCredentials(
    adminUsers : Map.Map<Text, AdminSettingsTypes.AdminUser>,
    username : Text,
    passwordHash : Text,
  ) : Bool {
    for ((_, user) in adminUsers.entries()) {
      if (user.isActive and user.username == username and user.passwordHash == passwordHash) {
        return true;
      };
    };
    false;
  };

  /// Return public views of all active admin users (no password hash).
  public func listAdminUsers(
    adminUsers : Map.Map<Text, AdminSettingsTypes.AdminUser>
  ) : [AdminSettingsTypes.AdminUserView] {
    var result : [AdminSettingsTypes.AdminUserView] = [];
    for ((_, user) in adminUsers.entries()) {
      if (user.isActive) {
        result := result.concat([{ id = user.id; username = user.username; createdAt = user.createdAt }]);
      };
    };
    result;
  };
};
