import List "mo:core/List";
import Int "mo:core/Int";
import Types "../types/notices";
import CommonTypes "../types/common";

module {
  public func getAllNotices(notices : List.List<Types.Notice>) : [Types.Notice] {
    let sorted = notices.sort(func(a, b) { Int.compare(b.postedAt, a.postedAt) });
    sorted.toArray();
  };

  public func getPinnedNotices(notices : List.List<Types.Notice>) : [Types.Notice] {
    let pinned = notices.filter(func(n) { n.isPinned });
    let sorted = pinned.sort(func(a, b) { Int.compare(b.postedAt, a.postedAt) });
    sorted.toArray();
  };

  public func createNotice(
    notices : List.List<Types.Notice>,
    nextId : Nat,
    title : Text,
    content : Text,
    noticeType : CommonTypes.NoticeType,
    postedBy : Principal,
    isPinned : Bool,
    now : CommonTypes.Timestamp,
  ) : Nat {
    let notice : Types.Notice = {
      noticeId = nextId;
      title;
      content;
      noticeType;
      postedBy;
      postedAt = now;
      isPinned;
    };
    notices.add(notice);
    nextId + 1;
  };

  public func updateNotice(
    notices : List.List<Types.Notice>,
    noticeId : Nat,
    title : Text,
    content : Text,
    noticeType : CommonTypes.NoticeType,
    isPinned : Bool,
  ) : () {
    notices.mapInPlace(
      func(n) {
        if (n.noticeId == noticeId) {
          { n with title; content; noticeType; isPinned }
        } else { n };
      }
    );
  };

  public func deleteNotice(notices : List.List<Types.Notice>, noticeId : Nat) : () {
    let filtered = notices.filter(func(n) { n.noticeId != noticeId });
    notices.clear();
    notices.append(filtered);
  };
};
