import List "mo:core/List";
import Types "../types/complaints";
import CommonTypes "../types/common";
import Storage "mo:caffeineai-object-storage/Storage";

module {
  public func getAllComplaints(complaints : List.List<Types.Complaint>) : [Types.Complaint] {
    complaints.toArray();
  };

  public func getComplaintsByFlat(complaints : List.List<Types.Complaint>, flatNumber : CommonTypes.FlatNumber) : [Types.Complaint] {
    complaints.filter(func(c) { c.flatNumber == flatNumber }).toArray();
  };

  public func getComplaintById(complaints : List.List<Types.Complaint>, complaintId : Nat) : ?Types.Complaint {
    complaints.find(func(c) { c.complaintId == complaintId });
  };

  public func getComplaintsByPrincipal(complaints : List.List<Types.Complaint>, residentPrincipal : Principal) : [Types.Complaint] {
    complaints.filter(func(c) { c.residentPrincipal == residentPrincipal }).toArray();
  };

  public func createComplaint(
    complaints : List.List<Types.Complaint>,
    nextId : Nat,
    flatNumber : CommonTypes.FlatNumber,
    residentPrincipal : Principal,
    category : CommonTypes.ComplaintCategory,
    description : Text,
    photoId : ?Storage.ExternalBlob,
    now : CommonTypes.Timestamp,
  ) : Nat {
    let complaint : Types.Complaint = {
      complaintId = nextId;
      flatNumber;
      residentPrincipal;
      category;
      description;
      photoId;
      status = #pending;
      createdAt = now;
      updatedAt = now;
    };
    complaints.add(complaint);
    nextId;
  };

  public func updateComplaintStatus(
    complaints : List.List<Types.Complaint>,
    complaintId : Nat,
    status : CommonTypes.ComplaintStatus,
    now : CommonTypes.Timestamp,
  ) : () {
    complaints.mapInPlace(
      func(c) {
        if (c.complaintId == complaintId) {
          { c with status; updatedAt = now }
        } else {
          c
        }
      }
    );
  };
};
