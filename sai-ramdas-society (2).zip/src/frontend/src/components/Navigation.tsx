import { cn } from "@/lib/utils";
import { useLocation, useNavigate } from "@tanstack/react-router";
import { NAV_ITEMS } from "../types";
import type { AppRole, NavItem } from "../types";

interface NavigationProps {
  role: AppRole;
}

export function Navigation({ role }: NavigationProps) {
  const navigate = useNavigate();
  const location = useLocation();

  const visibleItems: NavItem[] = NAV_ITEMS.filter((item) =>
    item.roles.includes(role),
  );
  const isActive = (path: string) =>
    location.pathname === path || location.pathname.startsWith(`${path}/`);

  return (
    <nav className="flex gap-1" aria-label="Site navigation">
      {visibleItems.map((item) => (
        <button
          type="button"
          key={item.path}
          onClick={() => void navigate({ to: item.path })}
          data-ocid={`nav.${item.label.toLowerCase().replace(/\s+/g, "_")}_link`}
          className={cn(
            "flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-smooth min-h-[44px]",
            isActive(item.path)
              ? "bg-primary-foreground/20 text-primary-foreground"
              : "text-primary-foreground/80 hover:bg-primary-foreground/10",
          )}
        >
          <span>{item.icon}</span>
          {item.label}
        </button>
      ))}
    </nav>
  );
}
