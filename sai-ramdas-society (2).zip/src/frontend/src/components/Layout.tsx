import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { useLocation, useNavigate } from "@tanstack/react-router";
import {
  Bell,
  BookOpen,
  Building2,
  DollarSign,
  Home,
  LogOut,
  Menu,
  MessageSquare,
  ShieldCheck,
  Users,
  X,
} from "lucide-react";
import type { ReactNode } from "react";
import { useState } from "react";
import { useAuth } from "../hooks/use-auth";
import { useRole } from "../hooks/use-role";
import type { AppRole, NavItem } from "../types";
import { NAV_ITEMS } from "../types";

const ICON_MAP: Record<string, ReactNode> = {
  "🏠": <Home className="w-5 h-5" />,
  "👥": <Users className="w-5 h-5" />,
  "💰": <DollarSign className="w-5 h-5" />,
  "📢": <MessageSquare className="w-5 h-5" />,
  "🚪": <Building2 className="w-5 h-5" />,
  "📌": <Bell className="w-5 h-5" />,
  "🏢": <Building2 className="w-5 h-5" />,
  "🔔": <ShieldCheck className="w-5 h-5" />,
  "📜": <BookOpen className="w-5 h-5" />,
};

interface LayoutProps {
  children: ReactNode;
  role: AppRole;
}

export function Layout({ children, role }: LayoutProps) {
  const navigate = useNavigate();
  const location = useLocation();
  const { logout } = useAuth();
  const { clearRole } = useRole();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const visibleItems = NAV_ITEMS.filter((item) => item.roles.includes(role));

  // Show Home button on every page except the home page itself
  const isHomePage = location.pathname === "/";

  const handleLogout = () => {
    clearRole();
    logout();
    void navigate({ to: "/role-select" });
  };

  const roleLabel =
    role === "admin"
      ? "Admin"
      : role === "committee"
        ? "Committee"
        : role === "resident"
          ? "Resident"
          : "Security Guard";

  const isActive = (path: string) =>
    location.pathname === path || location.pathname.startsWith(`${path}/`);

  return (
    <div className="min-h-screen flex flex-col bg-background">
      {/* Top Header */}
      <header
        className="bg-primary text-primary-foreground shadow-header sticky top-0 z-50"
        style={{
          background:
            "linear-gradient(135deg, oklch(0.35 0.18 264) 0%, oklch(0.28 0.22 264) 50%, oklch(0.22 0.20 268) 100%)",
          boxShadow: "0 4px 16px rgba(0,0,0,0.25), 0 2px 6px rgba(0,0,0,0.15)",
        }}
      >
        <div className="flex items-center justify-between px-4 h-16">
          <div className="flex items-center gap-2">
            <button
              type="button"
              className="md:hidden touch-target flex items-center justify-center rounded-lg hover:bg-primary/80 transition-smooth"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              aria-label="Toggle navigation menu"
              data-ocid="nav.mobile_menu_toggle"
            >
              {mobileMenuOpen ? (
                <X className="w-6 h-6" />
              ) : (
                <Menu className="w-6 h-6" />
              )}
            </button>

            {/* Home button — visible on all pages except "/" */}
            {!isHomePage && (
              <button
                type="button"
                onClick={() => void navigate({ to: "/" })}
                data-ocid="nav.home_button"
                aria-label="Go to Home"
                className="flex items-center gap-1.5 px-3 py-2 rounded-lg bg-primary-foreground/15 hover:bg-primary-foreground/25 transition-smooth min-h-[44px] min-w-[44px] flex-shrink-0"
              >
                <Home className="w-5 h-5" />
                <span className="text-sm font-semibold hidden xs:inline">
                  Home
                </span>
              </button>
            )}

            <div className="flex items-center gap-2">
              <div className="w-9 h-9 rounded-full bg-primary-foreground/20 flex items-center justify-center text-lg font-bold flex-shrink-0">
                🏢
              </div>
              <div className="flex flex-col">
                <span className="font-display font-bold text-base leading-tight">
                  Sai Ramdas Society
                </span>
                <span className="text-xs opacity-80 leading-tight">
                  {roleLabel}
                </span>
              </div>
            </div>
          </div>

          {/* Desktop nav */}
          <nav
            className="hidden md:flex items-center gap-1"
            aria-label="Main navigation"
          >
            {visibleItems.map((item) => (
              <button
                type="button"
                key={item.path}
                onClick={() => void navigate({ to: item.path })}
                data-ocid={`nav.${item.label.toLowerCase().replace(/\s+/g, "_")}_link`}
                className={cn(
                  "flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-smooth min-h-[44px]",
                  isActive(item.path)
                    ? "bg-primary-foreground/20 text-primary-foreground"
                    : "text-primary-foreground/80 hover:bg-primary-foreground/10 hover:text-primary-foreground",
                )}
              >
                {ICON_MAP[item.icon]}
                {item.label}
              </button>
            ))}
          </nav>

          <Button
            variant="ghost"
            size="sm"
            onClick={handleLogout}
            data-ocid="nav.logout_button"
            className="text-primary-foreground hover:bg-primary-foreground/10 btn-accessible gap-2"
          >
            <LogOut className="w-4 h-4" />
            <span className="hidden sm:inline">Logout</span>
          </Button>
        </div>

        {/* Mobile dropdown menu */}
        {mobileMenuOpen && (
          <nav
            className="md:hidden bg-primary border-t border-primary-foreground/20 px-4 pb-4"
            aria-label="Mobile navigation"
          >
            {/* Home shortcut in mobile menu */}
            {!isHomePage && (
              <button
                type="button"
                onClick={() => {
                  void navigate({ to: "/" });
                  setMobileMenuOpen(false);
                }}
                data-ocid="nav.mobile_home_button"
                className="flex items-center gap-3 w-full px-3 py-3 rounded-lg text-base font-medium transition-smooth touch-target mt-1 bg-primary-foreground/15 hover:bg-primary-foreground/25 text-primary-foreground"
              >
                <Home className="w-5 h-5" />
                Home
              </button>
            )}
            {visibleItems.map((item) => (
              <button
                type="button"
                key={item.path}
                onClick={() => {
                  void navigate({ to: item.path });
                  setMobileMenuOpen(false);
                }}
                data-ocid={`nav.mobile_${item.label.toLowerCase().replace(/\s+/g, "_")}_link`}
                className={cn(
                  "flex items-center gap-3 w-full px-3 py-3 rounded-lg text-base font-medium transition-smooth touch-target mt-1",
                  isActive(item.path)
                    ? "bg-primary-foreground/20 text-primary-foreground"
                    : "text-primary-foreground/80 hover:bg-primary-foreground/10 hover:text-primary-foreground",
                )}
              >
                {ICON_MAP[item.icon]}
                {item.label}
              </button>
            ))}
          </nav>
        )}
      </header>

      {/* Main content */}
      <main className="flex-1 bg-background pb-16 md:pb-0" id="main-content">
        {children}
      </main>

      {/* Bottom tab nav for mobile */}
      <BottomNav
        items={visibleItems}
        navigate={navigate}
        isActive={isActive}
        showHome={!isHomePage}
        onHomeClick={() => void navigate({ to: "/" })}
      />

      {/* Footer */}
      <footer className="hidden md:block bg-card border-t border-border py-3 text-center text-sm text-muted-foreground">
        © 2026 Sai Ramdas Society. Built with using ai by Pradip Ivare
      </footer>
    </div>
  );
}

function BottomNav({
  items,
  navigate,
  isActive,
  showHome,
  onHomeClick,
}: {
  items: NavItem[];
  navigate: ReturnType<typeof useNavigate>;
  isActive: (path: string) => boolean;
  showHome: boolean;
  onHomeClick: () => void;
}) {
  // Reserve one slot for Home button if needed; show up to 4 nav items + home
  const maxNavItems = showHome ? 4 : 5;
  const bottomItems = items.slice(0, maxNavItems);

  return (
    <nav
      className="md:hidden fixed bottom-0 left-0 right-0 bg-card border-t border-border z-40 flex"
      aria-label="Bottom navigation"
    >
      {/* Home tab — always first when not on home page */}
      {showHome && (
        <button
          type="button"
          onClick={onHomeClick}
          data-ocid="bottom_nav.home_tab"
          className="flex-1 flex flex-col items-center justify-center py-2 min-h-[56px] text-xs font-semibold transition-smooth text-primary bg-primary/5"
        >
          <Home className="w-5 h-5 mb-0.5" />
          <span>Home</span>
        </button>
      )}

      {bottomItems.map((item) => (
        <button
          type="button"
          key={item.path}
          onClick={() => void navigate({ to: item.path })}
          data-ocid={`bottom_nav.${item.label.toLowerCase().replace(/\s+/g, "_")}_tab`}
          className={cn(
            "flex-1 flex flex-col items-center justify-center py-2 min-h-[56px] text-xs font-medium transition-smooth",
            isActive(item.path)
              ? "text-primary"
              : "text-muted-foreground hover:text-foreground",
          )}
        >
          <span className="text-xl mb-0.5">{item.icon}</span>
          <span className="truncate max-w-[56px]">{item.label}</span>
        </button>
      ))}
    </nav>
  );
}
