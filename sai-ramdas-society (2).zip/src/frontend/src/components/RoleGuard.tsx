import { useNavigate } from "@tanstack/react-router";
import type { ReactNode } from "react";
import type { AppRole } from "../types";

interface RoleGuardProps {
  role: AppRole | null;
  allowedRoles: AppRole[];
  children: ReactNode;
  fallback?: ReactNode;
}

/**
 * Renders children only if the current role is in allowedRoles.
 * Otherwise renders fallback or redirects to /login.
 */
export function RoleGuard({
  role,
  allowedRoles,
  children,
  fallback,
}: RoleGuardProps) {
  const navigate = useNavigate();

  if (!role || !allowedRoles.includes(role)) {
    if (fallback) return <>{fallback}</>;
    void navigate({ to: "/login" });
    return null;
  }

  return <>{children}</>;
}
