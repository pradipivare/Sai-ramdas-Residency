import { Button } from "@/components/ui/button";
import type { ReactNode } from "react";

interface EmptyStateProps {
  icon?: string;
  title: string;
  description?: string;
  action?: {
    label: string;
    onClick: () => void;
  };
  children?: ReactNode;
}

export function EmptyState({
  icon,
  title,
  description,
  action,
  children,
}: EmptyStateProps) {
  return (
    <div
      className="flex flex-col items-center justify-center gap-4 py-16 px-6 text-center"
      data-ocid="empty_state"
    >
      {icon && (
        <div className="w-16 h-16 rounded-full bg-muted flex items-center justify-center text-4xl">
          {icon}
        </div>
      )}
      <div className="flex flex-col gap-2 max-w-sm">
        <h3 className="text-xl font-semibold font-display text-foreground">
          {title}
        </h3>
        {description && (
          <p className="text-muted-foreground text-accessible">{description}</p>
        )}
      </div>
      {children}
      {action && (
        <Button
          onClick={action.onClick}
          className="btn-accessible mt-2"
          data-ocid="empty_state.primary_button"
        >
          {action.label}
        </Button>
      )}
    </div>
  );
}
