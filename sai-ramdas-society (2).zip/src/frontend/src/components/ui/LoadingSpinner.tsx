import { cn } from "@/lib/utils";

interface LoadingSpinnerProps {
  size?: "sm" | "md" | "lg";
  label?: string;
  className?: string;
}

export function LoadingSpinner({
  size = "md",
  label = "Loading...",
  className,
}: LoadingSpinnerProps) {
  const sizeClass =
    size === "sm" ? "w-5 h-5" : size === "lg" ? "w-12 h-12" : "w-8 h-8";
  return (
    <output
      className={cn(
        "flex flex-col items-center justify-center gap-3 p-8",
        className,
      )}
      aria-live="polite"
      data-ocid="loading_state"
    >
      <div
        className={cn(
          "rounded-full border-4 border-muted border-t-primary animate-spin",
          sizeClass,
        )}
        aria-hidden="true"
      />
      <p className="text-muted-foreground text-accessible font-medium">
        {label}
      </p>
    </output>
  );
}
