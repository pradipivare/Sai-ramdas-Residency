import type { Principal } from "@icp-sdk/core/principal";
export interface Some<T> {
    __kind__: "Some";
    value: T;
}
export interface None {
    __kind__: "None";
}
export type Option<T> = Some<T> | None;
export class ExternalBlob {
    getBytes(): Promise<Uint8Array<ArrayBuffer>>;
    getDirectURL(): string;
    static fromURL(url: string): ExternalBlob;
    static fromBytes(blob: Uint8Array<ArrayBuffer>): ExternalBlob;
    withUploadProgress(onProgress: (percentage: number) => void): ExternalBlob;
}
export interface SocietyMember {
    id: bigint;
    role: SocietyMemberRole;
    nameEnglish: string;
    isActive: boolean;
    contactEmail?: string;
    nameMarathi: string;
    orderNumber: bigint;
    contactPhone?: string;
    photoId?: string;
}
export type Timestamp = bigint;
export interface Flat {
    floor: bigint;
    ownerName: string;
    wing: string;
    flatNumber: FlatNumber;
}
export interface Resident {
    residentId: bigint;
    residencyType: ResidencyType;
    principal: Principal;
    familyMembersCount: bigint;
    name: string;
    email: string;
    mobile: string;
    kycDocumentId?: ExternalBlob;
    flatNumber: FlatNumber;
    photoId?: string;
}
export type FlatNumber = string;
export interface PreApprovedGuest {
    relationship: string;
    name: string;
    mobile: string;
    flatNumber: FlatNumber;
    guestId: bigint;
}
export interface AdminUserView {
    id: string;
    username: string;
    createdAt: bigint;
}
export interface SocietyRule {
    id: bigint;
    descriptionEnglish: string;
    titleEnglish: string;
    createdAt: bigint;
    tags: Array<string>;
    isActive: boolean;
    descriptionMarathi: string;
    updatedAt: bigint;
    titleMarathi: string;
    category: string;
    orderNumber: bigint;
}
export interface AdminActionLog {
    id: bigint;
    action: string;
    targetPrincipal?: Principal;
    performedBy: Principal;
    timestamp: bigint;
    details: string;
}
export interface Complaint {
    status: ComplaintStatus;
    residentPrincipal: Principal;
    complaintId: bigint;
    createdAt: Timestamp;
    description: string;
    updatedAt: Timestamp;
    category: ComplaintCategory;
    flatNumber: FlatNumber;
    photoId?: ExternalBlob;
}
export interface Bill {
    status: BillStatus;
    penaltyAmount: bigint;
    dueDate: Timestamp;
    issuedDate: Timestamp;
    paidDate?: Timestamp;
    amount: bigint;
    billId: bigint;
    flatNumber: FlatNumber;
}
export interface Notice {
    noticeType: NoticeType;
    title: string;
    postedAt: Timestamp;
    postedBy: Principal;
    content: string;
    noticeId: bigint;
    isPinned: boolean;
}
export interface Visitor {
    flatVisiting: FlatNumber;
    exitTime?: Timestamp;
    otpCode: string;
    entryTime: Timestamp;
    name: string;
    visitorId: bigint;
    approvalStatus: ApprovalStatus;
    mobile: string;
    purpose: string;
    loggedBy: Principal;
}
export interface OverdueMemberReport {
    penaltyAmount: bigint;
    dueDate: Timestamp;
    residentName: string;
    mobile: string;
    amount: bigint;
    billId: bigint;
    flatNumber: FlatNumber;
}
export interface AdminSetting {
    key: string;
    value: string;
    updatedAt: bigint;
    updatedBy: Principal;
}
export enum ApprovalStatus {
    pending = "pending",
    approved = "approved",
    rejected = "rejected"
}
export enum BillStatus {
    paid = "paid",
    unpaid = "unpaid",
    overdue = "overdue"
}
export enum ComplaintCategory {
    other = "other",
    lift = "lift",
    water = "water",
    power = "power"
}
export enum ComplaintStatus {
    resolved = "resolved",
    pending = "pending",
    inProgress = "inProgress"
}
export enum NoticeType {
    emergency = "emergency",
    event = "event",
    regular = "regular"
}
export enum ResidencyType {
    owner = "owner",
    tenant = "tenant"
}
export enum SocietyMemberRole {
    member = "member",
    viceChairman = "viceChairman",
    secretary = "secretary",
    chairman = "chairman",
    treasurer = "treasurer"
}
export enum UserRole {
    admin = "admin",
    user = "user",
    guest = "guest"
}
export interface backendInterface {
    addAdminUser(username: string, passwordHash: string): Promise<{
        __kind__: "ok";
        ok: string;
    } | {
        __kind__: "err";
        err: string;
    }>;
    addFlat(flat: Flat): Promise<void>;
    addPreApprovedGuest(flatNumber: FlatNumber, name: string, mobile: string, relationship: string): Promise<bigint>;
    addResident(flatNumber: FlatNumber, name: string, mobile: string, email: string, residencyType: ResidencyType, familyMembersCount: bigint, kycDocumentId: ExternalBlob | null, photoId: string | null): Promise<bigint>;
    addSocietyMember(nameMarathi: string, nameEnglish: string, role: SocietyMemberRole, photoId: string | null, contactPhone: string | null, contactEmail: string | null, orderNumber: bigint): Promise<bigint>;
    addSocietyRule(titleMarathi: string, titleEnglish: string, descriptionMarathi: string, descriptionEnglish: string, category: string, tags: Array<string>, orderNumber: bigint): Promise<bigint>;
    applyPenalties(): Promise<void>;
    approveVisitor(visitorId: bigint, otpCode: string): Promise<void>;
    assignCallerUserRole(user: Principal, role: UserRole): Promise<void>;
    createComplaint(flatNumber: FlatNumber, category: ComplaintCategory, description: string, photoId: ExternalBlob | null): Promise<bigint>;
    createNotice(title: string, content: string, noticeType: NoticeType, isPinned: boolean): Promise<bigint>;
    deleteFlat(flatNumber: FlatNumber): Promise<void>;
    deleteNotice(noticeId: bigint): Promise<void>;
    deleteResident(residentId: bigint): Promise<void>;
    deleteSocietyMember(id: bigint): Promise<void>;
    deleteSocietyRule(id: bigint): Promise<void>;
    generateMonthlyBills(amount: bigint, dueDate: Timestamp): Promise<void>;
    getActiveSocietyMembers(): Promise<Array<SocietyMember>>;
    getAdminActionLog(): Promise<Array<AdminActionLog>>;
    getAdminSetting(key: string): Promise<AdminSetting | null>;
    getAdminUserCount(): Promise<bigint>;
    getAllComplaints(): Promise<Array<Complaint>>;
    getAllFlats(): Promise<Array<Flat>>;
    getAllNotices(): Promise<Array<Notice>>;
    getAllResidents(): Promise<Array<Resident>>;
    getAllUnpaidBills(): Promise<Array<Bill>>;
    getBillById(billId: bigint): Promise<Bill | null>;
    getBillsByFlat(flatNumber: FlatNumber): Promise<Array<Bill>>;
    getCallerUserRole(): Promise<UserRole>;
    getComplaintById(complaintId: bigint): Promise<Complaint | null>;
    getComplaintsByFlat(flatNumber: FlatNumber): Promise<Array<Complaint>>;
    getFlatDetails(flatNumber: FlatNumber): Promise<Flat | null>;
    getMyComplaints(): Promise<Array<Complaint>>;
    getOverdueBillsWithResidents(): Promise<Array<OverdueMemberReport>>;
    getPinnedNotices(): Promise<Array<Notice>>;
    getPreApprovedGuests(flatNumber: FlatNumber): Promise<Array<PreApprovedGuest>>;
    getResidentByFlat(flatNumber: FlatNumber): Promise<Resident | null>;
    getResidentPhoto(residentId: bigint): Promise<string | null>;
    getSocietyMembers(): Promise<Array<SocietyMember>>;
    getSocietyRules(): Promise<Array<SocietyRule>>;
    getSocietyRulesByCategory(category: string): Promise<Array<SocietyRule>>;
    getTodayVisitors(): Promise<Array<Visitor>>;
    getTotalFlatsOverride(): Promise<bigint | null>;
    getTotalShopsOverride(): Promise<bigint>;
    getVisitorsByFlat(flatNumber: FlatNumber): Promise<Array<Visitor>>;
    isCallerAdmin(): Promise<boolean>;
    listAdminUsers(): Promise<Array<AdminUserView>>;
    logVisitorEntry(name: string, mobile: string, flatVisiting: FlatNumber, purpose: string): Promise<[bigint, string]>;
    logVisitorExit(visitorId: bigint): Promise<void>;
    recordPayment(billId: bigint, paymentMethod: string, transactionId: string): Promise<void>;
    rejectVisitor(visitorId: bigint): Promise<void>;
    removeAdminUser(id: string): Promise<{
        __kind__: "ok";
        ok: null;
    } | {
        __kind__: "err";
        err: string;
    }>;
    removePreApprovedGuest(guestId: bigint): Promise<void>;
    setAdminPin(newPinHash: string): Promise<void>;
    setAdminSetting(key: string, value: string): Promise<void>;
    setSocietyMemberPhoto(id: bigint, photoId: string | null): Promise<void>;
    setTotalFlatsOverride(count: bigint | null): Promise<void>;
    setTotalShopsOverride(count: bigint | null): Promise<void>;
    updateComplaintStatus(complaintId: bigint, status: ComplaintStatus): Promise<void>;
    updateFlat(flat: Flat): Promise<void>;
    updateNotice(noticeId: bigint, title: string, content: string, noticeType: NoticeType, isPinned: boolean): Promise<void>;
    updateResident(resident: Resident): Promise<void>;
    updateSocietyMember(member: SocietyMember): Promise<void>;
    updateSocietyRule(rule: SocietyRule): Promise<void>;
    verifyAdminCredentials(username: string, passwordHash: string): Promise<boolean>;
    verifyAdminPin(pinHash: string): Promise<boolean>;
}
