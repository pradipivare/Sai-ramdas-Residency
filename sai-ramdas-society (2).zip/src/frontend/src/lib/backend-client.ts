/**
 * Provides a pre-bound useActor hook that wires to the backend canister.
 * All files should import useActor from this module.
 */
import { useActor as _useActor } from "@caffeineai/core-infrastructure";
import { createActor } from "../backend";
import type { backendInterface } from "../backend";

/**
 * A zero-argument hook that returns the backend actor already bound to
 * the project's canister. Use this everywhere in the app.
 */
export function useActor() {
  return _useActor<backendInterface>(createActor);
}
