export type {
  Flat,
  FlatNumber,
  Resident,
  Bill,
  Complaint,
  Notice,
  Visitor,
  PreApprovedGuest,
  Timestamp,
} from "../backend";

export {
  ApprovalStatus,
  BillStatus,
  ComplaintCategory,
  ComplaintStatus,
  NoticeType,
  ResidencyType,
  UserRole,
} from "../backend";

/** App-level roles that map to backend UserRole */
export type AppRole = "admin" | "committee" | "resident" | "security";

export interface RoleConfig {
  label: string;
  description: string;
  icon: string;
  color: string;
}

export const ROLE_CONFIGS: Record<AppRole, RoleConfig> = {
  admin: {
    label: "Admin",
    description: "Full access — manage society, members, billing",
    icon: "🛡️",
    color: "bg-primary text-primary-foreground",
  },
  committee: {
    label: "Committee Member",
    description: "Manage notices, complaints, and approvals",
    icon: "📋",
    color: "bg-secondary text-secondary-foreground",
  },
  resident: {
    label: "Resident",
    description: "View bills, raise complaints, track visitors",
    icon: "🏠",
    color: "bg-muted text-foreground",
  },
  security: {
    label: "Security Guard",
    description: "Manage gate entries and visitor approvals",
    icon: "🔐",
    color: "bg-accent text-accent-foreground",
  },
};

export interface NavItem {
  label: string;
  path: string;
  icon: string;
  roles: AppRole[];
}

export const NAV_ITEMS: NavItem[] = [
  {
    label: "Dashboard",
    path: "/dashboard",
    icon: "🏠",
    roles: ["admin", "committee", "resident", "security"],
  },
  {
    label: "Residents",
    path: "/residents",
    icon: "👥",
    roles: ["admin", "committee"],
  },
  {
    label: "Bills",
    path: "/bills",
    icon: "💰",
    roles: ["admin", "committee", "resident"],
  },
  {
    label: "Complaints",
    path: "/complaints",
    icon: "📢",
    roles: ["admin", "committee", "resident"],
  },
  {
    label: "Visitors",
    path: "/visitors",
    icon: "🚪",
    roles: ["admin", "committee", "security"],
  },
  {
    label: "Approvals",
    path: "/visitors/approval",
    icon: "🔔",
    roles: ["resident"],
  },
  {
    label: "Notices",
    path: "/notices",
    icon: "📌",
    roles: ["admin", "committee", "resident"],
  },
  { label: "Members", path: "/members", icon: "🏢", roles: ["admin"] },
  {
    label: "Society Rules",
    path: "/rules",
    icon: "📜",
    roles: ["admin", "committee", "resident", "security"],
  },
];

// ─── Society Committee Members ────────────────────────────────────────────────

export type SocietyMemberRole =
  | "chairman"
  | "viceChairman"
  | "secretary"
  | "treasurer"
  | "member";

export interface SocietyMember {
  id: bigint;
  nameMarathi: string;
  nameEnglish: string;
  role: SocietyMemberRole;
  photoId: string | null;
  contactPhone: string | null;
  contactEmail: string | null;
  orderNumber: bigint;
  isActive: boolean;
}

export const SOCIETY_MEMBER_ROLE_LABELS: Record<SocietyMemberRole, string> = {
  chairman: "Chairman",
  viceChairman: "Vice Chairman",
  secretary: "Secretary",
  treasurer: "Treasurer",
  member: "Member",
};

// Keep for backward compatibility — same English labels
export const SOCIETY_MEMBER_ROLE_LABELS_EN: Record<SocietyMemberRole, string> =
  SOCIETY_MEMBER_ROLE_LABELS;

// ─── Society Rules ────────────────────────────────────────────────────────────

export interface SocietyRule {
  id: bigint;
  titleMarathi: string;
  titleEnglish: string;
  descriptionMarathi: string;
  descriptionEnglish: string;
  category: string;
  tags: string[];
  orderNumber: bigint;
  isActive: boolean;
  createdAt: bigint;
  updatedAt: bigint;
}

// ─── Overdue Member Report ────────────────────────────────────────────────────

export interface OverdueMemberReport {
  billId: bigint;
  flatNumber: string;
  residentName: string;
  mobile: string;
  amount: bigint;
  dueDate: bigint;
  penaltyAmount: bigint;
}

// ─── Admin Settings ───────────────────────────────────────────────────────────

export interface AdminSetting {
  key: string;
  value: string;
  updatedAt: bigint;
  updatedBy: string;
}

export interface AdminActionLog {
  logId: bigint;
  action: string;
  performedBy: string;
  performedAt: bigint;
  details: string;
}
