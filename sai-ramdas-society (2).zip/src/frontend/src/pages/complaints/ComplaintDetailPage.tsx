import { LoadingSpinner } from "@/components/ui/LoadingSpinner";
import { PageHeader } from "@/components/ui/PageHeader";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { useActor } from "@/lib/backend-client";
import { cn } from "@/lib/utils";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useNavigate, useParams } from "@tanstack/react-router";
import {
  ArrowLeft,
  CalendarDays,
  CheckCircle,
  Clock,
  Loader2,
} from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { Layout } from "../../components/Layout";
import { useRole } from "../../hooks/use-role";
import { formatDate } from "../../hooks/useQueries";
import type { AppRole, Complaint } from "../../types";
import { ComplaintCategory, ComplaintStatus } from "../../types";

const STATUS_CONFIG: Record<
  ComplaintStatus,
  { label: string; badgeClass: string; timelineClass: string; icon: string }
> = {
  [ComplaintStatus.pending]: {
    label: "Pending",
    badgeClass: "bg-destructive/15 text-destructive border-destructive/30",
    timelineClass: "bg-destructive",
    icon: "🔴",
  },
  [ComplaintStatus.inProgress]: {
    label: "In Progress",
    badgeClass: "bg-amber-100 text-amber-800 border-amber-300",
    timelineClass: "bg-amber-500",
    icon: "🟡",
  },
  [ComplaintStatus.resolved]: {
    label: "Resolved",
    badgeClass: "bg-emerald-100 text-emerald-800 border-emerald-300",
    timelineClass: "bg-emerald-500",
    icon: "🟢",
  },
};

const CATEGORY_LABELS: Record<ComplaintCategory, string> = {
  [ComplaintCategory.water]: "💧 Water",
  [ComplaintCategory.lift]: "🛗 Lift",
  [ComplaintCategory.power]: "⚡ Power",
  [ComplaintCategory.other]: "📋 Other",
};

const TIMELINE_STEPS: ComplaintStatus[] = [
  ComplaintStatus.pending,
  ComplaintStatus.inProgress,
  ComplaintStatus.resolved,
];

function StatusTimeline({ status }: { status: ComplaintStatus }) {
  const stepIndex = TIMELINE_STEPS.indexOf(status);
  return (
    <div
      className="flex items-center gap-0"
      data-ocid="complaint_detail.status_timeline"
    >
      {TIMELINE_STEPS.map((step, i) => {
        const cfg = STATUS_CONFIG[step];
        const done = TIMELINE_STEPS.indexOf(status) >= i;
        const active = status === step;
        return (
          <div key={step} className="flex items-center flex-1 last:flex-none">
            <div className="flex flex-col items-center gap-1.5 flex-shrink-0">
              <div
                className={cn(
                  "w-9 h-9 rounded-full flex items-center justify-center border-2 transition-smooth",
                  done
                    ? cn("border-transparent", cfg.timelineClass, "text-white")
                    : "border-border bg-background text-muted-foreground",
                  active && "ring-2 ring-offset-2 ring-primary",
                )}
              >
                {done ? (
                  <CheckCircle className="w-5 h-5" />
                ) : (
                  <Clock className="w-4 h-4" />
                )}
              </div>
              <span
                className={cn(
                  "text-xs font-medium whitespace-nowrap",
                  done ? "text-foreground" : "text-muted-foreground",
                )}
              >
                {cfg.label}
              </span>
            </div>
            {i < TIMELINE_STEPS.length - 1 && (
              <div
                className={cn(
                  "flex-1 h-1 mx-1 rounded-full mb-4 transition-smooth",
                  stepIndex > i ? cfg.timelineClass : "bg-border",
                )}
              />
            )}
          </div>
        );
      })}
    </div>
  );
}

export default function ComplaintDetailPage() {
  const { getRole } = useRole();
  const role = getRole() as AppRole | null;
  const navigate = useNavigate();
  const { complaintId } = useParams({ strict: false }) as {
    complaintId: string;
  };
  const { actor, isFetching } = useActor();
  const queryClient = useQueryClient();
  const [updatingStatus, setUpdatingStatus] = useState(false);
  const [newStatus, setNewStatus] = useState<ComplaintStatus | "">("");

  const isAdminOrCommittee = role === "admin" || role === "committee";

  const {
    data: complaint,
    isLoading,
    error,
  } = useQuery<Complaint | null>({
    queryKey: ["complaint", complaintId],
    queryFn: async () => {
      if (!actor) return null;
      return actor.getComplaintById(BigInt(complaintId));
    },
    enabled: !!actor && !isFetching && !!complaintId,
  });

  const handleStatusUpdate = async () => {
    if (!actor || !newStatus || !complaint) return;
    setUpdatingStatus(true);
    try {
      await actor.updateComplaintStatus(
        complaint.complaintId,
        newStatus as ComplaintStatus,
      );
      await queryClient.invalidateQueries({ queryKey: ["complaints"] });
      await queryClient.invalidateQueries({
        queryKey: ["complaint", complaintId],
      });
      toast.success("Status updated successfully!");
      setNewStatus("");
    } catch (err) {
      console.error(err);
      toast.error("Failed to update status. Please try again.");
    } finally {
      setUpdatingStatus(false);
    }
  };

  if (!role) return null;

  return (
    <Layout role={role}>
      <PageHeader
        title="Complaint Details"
        icon="📋"
        actions={
          <Button
            variant="ghost"
            className="btn-accessible gap-2"
            onClick={() => void navigate({ to: "/complaints" })}
            data-ocid="complaint_detail.back_button"
          >
            <ArrowLeft className="w-5 h-5" />
            Back
          </Button>
        }
      />

      <div className="p-4 max-w-2xl mx-auto space-y-5">
        {isLoading && <LoadingSpinner label="Loading complaint..." />}

        {error && (
          <div
            className="p-4 rounded-xl bg-destructive/10 text-destructive text-base"
            data-ocid="complaint_detail.error_state"
          >
            Failed to load complaint. Please try again.
          </div>
        )}

        {!isLoading && !error && !complaint && (
          <div className="p-6 text-center text-muted-foreground text-base">
            Complaint not found.
          </div>
        )}

        {complaint && (
          <>
            {/* Status + Category */}
            <Card className="p-4 space-y-3 border border-border bg-card">
              <div className="flex items-center justify-between flex-wrap gap-3">
                <div className="flex items-center gap-3">
                  <span className="text-2xl">
                    {CATEGORY_LABELS[complaint.category].split(" ")[0]}
                  </span>
                  <div>
                    <p className="text-lg font-semibold text-foreground">
                      {CATEGORY_LABELS[complaint.category].replace(
                        /^\S+\s/,
                        "",
                      )}{" "}
                      Issue
                    </p>
                    <p className="text-sm text-muted-foreground font-mono">
                      Flat {complaint.flatNumber}
                    </p>
                  </div>
                </div>
                <Badge
                  className={cn(
                    "text-base font-semibold px-4 py-1.5 border",
                    STATUS_CONFIG[complaint.status].badgeClass,
                  )}
                  data-ocid="complaint_detail.status_badge"
                >
                  {STATUS_CONFIG[complaint.status].label}
                </Badge>
              </div>

              <Separator />

              {/* Status Timeline */}
              <StatusTimeline status={complaint.status} />
            </Card>

            {/* Description */}
            <Card className="p-4 space-y-2 border border-border bg-card">
              <h3 className="text-lg font-semibold text-foreground">
                Description
              </h3>
              <p className="text-base text-foreground leading-relaxed">
                {complaint.description}
              </p>
            </Card>

            {/* Photo */}
            {complaint.photoId && (
              <Card className="overflow-hidden border border-border">
                <div className="px-4 pt-4 pb-2">
                  <h3 className="text-lg font-semibold text-foreground">
                    Photo
                  </h3>
                </div>
                <img
                  src={complaint.photoId.getDirectURL()}
                  alt="Attached evidence for this complaint"
                  className="w-full max-h-72 object-cover"
                  data-ocid="complaint_detail.photo"
                />
              </Card>
            )}

            {/* Dates */}
            <Card className="p-4 space-y-3 border border-border bg-card">
              <h3 className="text-lg font-semibold text-foreground">
                Timeline
              </h3>
              <div className="flex flex-col gap-2">
                <div className="flex items-center gap-2 text-base text-foreground">
                  <CalendarDays className="w-5 h-5 text-muted-foreground flex-shrink-0" />
                  <span className="font-medium">Filed:</span>
                  <span className="text-muted-foreground">
                    {formatDate(complaint.createdAt)}
                  </span>
                </div>
                {complaint.updatedAt !== complaint.createdAt && (
                  <div className="flex items-center gap-2 text-base text-foreground">
                    <Clock className="w-5 h-5 text-muted-foreground flex-shrink-0" />
                    <span className="font-medium">Last Updated:</span>
                    <span className="text-muted-foreground">
                      {formatDate(complaint.updatedAt)}
                    </span>
                  </div>
                )}
              </div>
            </Card>

            {/* Admin/Committee Status Update */}
            {isAdminOrCommittee &&
              complaint.status !== ComplaintStatus.resolved && (
                <Card
                  className="p-4 space-y-4 border border-border bg-card"
                  data-ocid="complaint_detail.status_update_panel"
                >
                  <h3 className="text-lg font-semibold text-foreground">
                    Update Status
                  </h3>
                  <div className="space-y-3">
                    <Label className="text-base font-medium text-foreground">
                      Change status to:
                    </Label>
                    <Select
                      value={newStatus}
                      onValueChange={(v) => setNewStatus(v as ComplaintStatus)}
                      data-ocid="complaint_detail.status_select"
                    >
                      <SelectTrigger
                        className="h-12 text-base"
                        data-ocid="complaint_detail.status_select_trigger"
                      >
                        <SelectValue placeholder="Select new status..." />
                      </SelectTrigger>
                      <SelectContent>
                        {complaint.status === ComplaintStatus.pending && (
                          <SelectItem
                            value={ComplaintStatus.inProgress}
                            className="text-base py-3"
                          >
                            🟡 In Progress
                          </SelectItem>
                        )}
                        {(complaint.status === ComplaintStatus.pending ||
                          complaint.status === ComplaintStatus.inProgress) && (
                          <SelectItem
                            value={ComplaintStatus.resolved}
                            className="text-base py-3"
                          >
                            🟢 Resolved
                          </SelectItem>
                        )}
                      </SelectContent>
                    </Select>

                    <Button
                      className="w-full h-14 text-lg font-semibold gap-2"
                      disabled={!newStatus || updatingStatus}
                      onClick={() => void handleStatusUpdate()}
                      data-ocid="complaint_detail.update_status_button"
                    >
                      {updatingStatus ? (
                        <>
                          <Loader2 className="w-5 h-5 animate-spin" />
                          Updating...
                        </>
                      ) : (
                        <>
                          <CheckCircle className="w-5 h-5" />
                          Update Status
                        </>
                      )}
                    </Button>
                  </div>
                </Card>
              )}

            {/* Resolved banner */}
            {complaint.status === ComplaintStatus.resolved && (
              <Card
                className="p-4 flex items-center gap-3 border border-emerald-300 bg-emerald-50"
                data-ocid="complaint_detail.resolved_banner"
              >
                <CheckCircle className="w-7 h-7 text-emerald-600 flex-shrink-0" />
                <div>
                  <p className="text-base font-semibold text-emerald-800">
                    Complaint Resolved
                  </p>
                  <p className="text-sm text-emerald-700">
                    This complaint has been successfully resolved.
                  </p>
                </div>
              </Card>
            )}
          </>
        )}
      </div>
    </Layout>
  );
}
