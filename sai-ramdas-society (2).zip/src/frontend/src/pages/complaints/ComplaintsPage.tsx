import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { cn } from "@/lib/utils";
import { useNavigate } from "@tanstack/react-router";
import { MessageSquarePlus, Search } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { Layout } from "../../components/Layout";
import { EmptyState } from "../../components/ui/EmptyState";
import { LoadingSpinner } from "../../components/ui/LoadingSpinner";
import { PageHeader } from "../../components/ui/PageHeader";
import { useRole } from "../../hooks/use-role";
import {
  formatDate,
  useAllComplaints,
  useMyComplaints,
} from "../../hooks/useQueries";
import type { AppRole, Complaint } from "../../types";
import { ComplaintCategory, ComplaintStatus } from "../../types";

const STATUS_CONFIG: Record<
  ComplaintStatus,
  { label: string; className: string }
> = {
  [ComplaintStatus.pending]: {
    label: "Pending",
    className: "bg-destructive/15 text-destructive border-destructive/30",
  },
  [ComplaintStatus.inProgress]: {
    label: "In Progress",
    className: "bg-yellow-700/20 text-yellow-300 border-yellow-700/30",
  },
  [ComplaintStatus.resolved]: {
    label: "Resolved",
    className: "bg-green-700/20 text-green-300 border-green-700/30",
  },
};

const CATEGORY_LABELS: Record<ComplaintCategory, string> = {
  [ComplaintCategory.water]: "💧 Water",
  [ComplaintCategory.lift]: "🛗 Lift",
  [ComplaintCategory.power]: "⚡ Power",
  [ComplaintCategory.other]: "📋 Other",
};

type FilterTab = "all" | ComplaintStatus;

// ─── Compact Complaint Row ────────────────────────────────────────────────────

function ComplaintRow({
  complaint,
  index,
  onClick,
}: {
  complaint: Complaint;
  index: number;
  onClick: () => void;
}) {
  const cfg = STATUS_CONFIG[complaint.status];
  return (
    <button
      type="button"
      className="flex items-center gap-3 px-3 py-2.5 w-full text-left border-b border-border last:border-0 hover:bg-muted/30 transition-colors"
      onClick={onClick}
      data-ocid={`complaints.item.${index}`}
    >
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2 flex-wrap">
          <span className="text-base font-semibold text-foreground">
            {CATEGORY_LABELS[complaint.category]}
          </span>
          <span className="text-sm text-muted-foreground">
            Flat {complaint.flatNumber}
          </span>
        </div>
        <p className="text-sm text-muted-foreground truncate mt-0.5">
          {complaint.description}
        </p>
      </div>
      <div className="flex flex-col items-end gap-1 flex-shrink-0">
        <Badge
          className={cn(
            "text-xs font-semibold px-2 py-0.5 border",
            cfg.className,
          )}
        >
          {cfg.label}
        </Badge>
        <span className="text-xs text-muted-foreground">
          {formatDate(complaint.createdAt)}
        </span>
      </div>
    </button>
  );
}

// ─── Main Page ────────────────────────────────────────────────────────────────

export default function ComplaintsPage() {
  const { getRole } = useRole();
  const role = getRole() as AppRole | null;
  const navigate = useNavigate();
  const [filter, setFilter] = useState<FilterTab>("all");
  const [search, setSearch] = useState("");

  const isAdmin = role === "admin";
  const isAdminOrCommittee = role === "admin" || role === "committee";

  const {
    data: allComplaints,
    isLoading: allLoading,
    error: allError,
  } = useAllComplaints();
  const {
    data: myComplaints,
    isLoading: myLoading,
    error: myError,
  } = useMyComplaints();

  const rawList = isAdminOrCommittee
    ? (allComplaints ?? [])
    : (myComplaints ?? []);
  const isLoading = isAdminOrCommittee ? allLoading : myLoading;
  const error = isAdminOrCommittee ? allError : myError;

  const filtered = rawList
    .filter((c) => filter === "all" || c.status === filter)
    .filter((c) => {
      const q = search.toLowerCase();
      return (
        !q ||
        c.description.toLowerCase().includes(q) ||
        c.flatNumber.toLowerCase().includes(q) ||
        CATEGORY_LABELS[c.category].toLowerCase().includes(q)
      );
    })
    .sort((a, b) => Number(b.createdAt - a.createdAt));

  const handleComplaintClick = (complaint: Complaint) => {
    void navigate({
      to: "/complaints/$complaintId",
      params: { complaintId: String(complaint.complaintId) },
    });
  };

  if (!role) return null;

  return (
    <Layout role={role}>
      <PageHeader
        title="Complaints"
        icon="📢"
        subtitle={
          isAdminOrCommittee ? "All society complaints" : "Your complaints"
        }
        actions={
          isAdmin ? (
            <Button
              className="btn-accessible gap-2"
              onClick={() => void navigate({ to: "/complaints/new" })}
              data-ocid="complaints.new_complaint_button"
            >
              <MessageSquarePlus className="w-5 h-5" />
              New
            </Button>
          ) : undefined
        }
      />

      <div className="px-4 pt-3 pb-1 space-y-3">
        {/* Search */}
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            className="pl-9 h-10 text-base"
            placeholder="Search complaints..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            data-ocid="complaints.search_input"
          />
        </div>

        {/* Status Tabs */}
        <Tabs value={filter} onValueChange={(v) => setFilter(v as FilterTab)}>
          <TabsList className="w-full h-10 bg-muted/60">
            <TabsTrigger
              value="all"
              className="flex-1 text-sm"
              data-ocid="complaints.filter.tab.all"
            >
              All
            </TabsTrigger>
            <TabsTrigger
              value={ComplaintStatus.pending}
              className="flex-1 text-sm"
              data-ocid="complaints.filter.tab.pending"
            >
              Pending
            </TabsTrigger>
            <TabsTrigger
              value={ComplaintStatus.inProgress}
              className="flex-1 text-sm"
              data-ocid="complaints.filter.tab.in_progress"
            >
              In Progress
            </TabsTrigger>
            <TabsTrigger
              value={ComplaintStatus.resolved}
              className="flex-1 text-sm"
              data-ocid="complaints.filter.tab.resolved"
            >
              Resolved
            </TabsTrigger>
          </TabsList>
        </Tabs>
      </div>

      <div className="px-4 pb-4">
        {isLoading && <LoadingSpinner label="Loading complaints..." />}

        {error && (
          <div
            className="p-4 rounded-xl bg-destructive/10 text-destructive text-base mt-2"
            data-ocid="complaints.error_state"
          >
            Failed to load complaints. Please try again.
          </div>
        )}

        {!isLoading && !error && filtered.length === 0 && (
          <div className="mt-2">
            <EmptyState
              icon="📭"
              title="No complaints found"
              description={
                filter !== "all"
                  ? `No ${STATUS_CONFIG[filter as ComplaintStatus]?.label} complaints.`
                  : "No complaints yet."
              }
              action={
                isAdmin
                  ? {
                      label: "New Complaint",
                      onClick: () => {
                        toast.info("Opening new complaint form");
                        void navigate({ to: "/complaints/new" });
                      },
                    }
                  : undefined
              }
            />
          </div>
        )}

        {!isLoading && !error && filtered.length > 0 && (
          <div className="border border-border rounded-xl overflow-hidden bg-card mt-2">
            {filtered.map((complaint, i) => (
              <ComplaintRow
                key={String(complaint.complaintId)}
                complaint={complaint}
                index={i + 1}
                onClick={() => handleComplaintClick(complaint)}
              />
            ))}
          </div>
        )}
      </div>
    </Layout>
  );
}
