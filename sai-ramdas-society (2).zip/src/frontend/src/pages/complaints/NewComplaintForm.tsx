import { LoadingSpinner } from "@/components/ui/LoadingSpinner";
import { PageHeader } from "@/components/ui/PageHeader";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { cn } from "@/lib/utils";
import { useQueryClient } from "@tanstack/react-query";
import { useNavigate } from "@tanstack/react-router";
import { Camera, CheckCircle, ImagePlus, X } from "lucide-react";
import { useRef, useState } from "react";
import { toast } from "sonner";
import { ExternalBlob } from "../../backend";
import { Layout } from "../../components/Layout";
import { useRole } from "../../hooks/use-role";
import { useActor } from "../../lib/backend-client";
import type { AppRole } from "../../types";
import { ComplaintCategory } from "../../types";

const CATEGORIES: {
  value: ComplaintCategory;
  label: string;
  icon: string;
  desc: string;
}[] = [
  {
    value: ComplaintCategory.water,
    label: "Water",
    icon: "💧",
    desc: "Leakage, supply issues",
  },
  {
    value: ComplaintCategory.lift,
    label: "Lift",
    icon: "🛗",
    desc: "Lift not working",
  },
  {
    value: ComplaintCategory.power,
    label: "Power",
    icon: "⚡",
    desc: "Electricity issues",
  },
  {
    value: ComplaintCategory.other,
    label: "Other",
    icon: "📋",
    desc: "Other problems",
  },
];

export default function NewComplaintForm() {
  const { getRole } = useRole();
  const role = getRole() as AppRole | null;
  const navigate = useNavigate();
  const { actor } = useActor();
  const queryClient = useQueryClient();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const cameraInputRef = useRef<HTMLInputElement>(null);

  const [category, setCategory] = useState<ComplaintCategory | null>(null);
  const [flatNumber, setFlatNumber] = useState("");
  const [description, setDescription] = useState("");
  const [photoFile, setPhotoFile] = useState<File | null>(null);
  const [photoPreview, setPhotoPreview] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  if (!role) return null;

  const handlePhotoSelected = (file: File) => {
    setPhotoFile(file);
    const url = URL.createObjectURL(file);
    setPhotoPreview(url);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) handlePhotoSelected(file);
  };

  const removePhoto = () => {
    setPhotoFile(null);
    if (photoPreview) URL.revokeObjectURL(photoPreview);
    setPhotoPreview(null);
  };

  const canSubmit =
    category !== null && flatNumber.trim() && description.trim().length >= 10;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!canSubmit || !actor || !category) return;

    setSubmitting(true);
    try {
      let photoBlob: ExternalBlob | null = null;
      if (photoFile) {
        const arrayBuffer = await photoFile.arrayBuffer();
        photoBlob = ExternalBlob.fromBytes(new Uint8Array(arrayBuffer));
      }

      await actor.createComplaint(
        flatNumber.trim(),
        category,
        description.trim(),
        photoBlob,
      );

      await queryClient.invalidateQueries({ queryKey: ["complaints"] });
      setSubmitted(true);
      toast.success("Complaint submitted successfully!", { duration: 4000 });

      setTimeout(() => {
        void navigate({ to: "/complaints" });
      }, 1500);
    } catch (err) {
      console.error(err);
      toast.error("Failed to submit complaint. Please try again.", {
        duration: 4000,
      });
    } finally {
      setSubmitting(false);
    }
  };

  if (submitted) {
    return (
      <Layout role={role}>
        <div
          className="flex flex-col items-center justify-center min-h-[60vh] gap-4 p-6"
          data-ocid="new_complaint.success_state"
        >
          <div className="w-20 h-20 rounded-full bg-emerald-100 flex items-center justify-center">
            <CheckCircle className="w-10 h-10 text-emerald-600" />
          </div>
          <h2 className="text-2xl font-bold font-display text-foreground text-center">
            Complaint Submitted!
          </h2>
          <p className="text-base text-muted-foreground text-center">
            Your complaint has been registered. We'll update you on the status.
          </p>
        </div>
      </Layout>
    );
  }

  return (
    <Layout role={role}>
      <PageHeader
        title="New Complaint"
        icon="📝"
        subtitle="Describe your issue and we'll look into it"
      />

      <form
        onSubmit={(e) => void handleSubmit(e)}
        className="p-4 space-y-6 max-w-2xl mx-auto"
      >
        {/* Category Selection */}
        <div className="space-y-3">
          <Label className="text-lg font-semibold text-foreground">
            Category <span className="text-destructive">*</span>
          </Label>
          <div className="grid grid-cols-2 gap-3">
            {CATEGORIES.map((cat) => (
              <button
                type="button"
                key={cat.value}
                onClick={() => setCategory(cat.value)}
                data-ocid={`new_complaint.category.${cat.value}`}
                className={cn(
                  "flex flex-col items-center gap-2 p-4 rounded-xl border-2 transition-smooth min-h-[88px] text-center",
                  category === cat.value
                    ? "border-primary bg-primary/10 text-primary"
                    : "border-border bg-card text-foreground hover:border-primary/50 hover:bg-muted/40",
                )}
              >
                <span className="text-3xl" aria-hidden="true">
                  {cat.icon}
                </span>
                <span className="text-base font-semibold">{cat.label}</span>
                <span className="text-xs text-muted-foreground leading-tight">
                  {cat.desc}
                </span>
              </button>
            ))}
          </div>
          {!category && (
            <p
              className="text-sm text-muted-foreground"
              data-ocid="new_complaint.category.field_error"
            >
              Please select a category
            </p>
          )}
        </div>

        {/* Flat Number */}
        <div className="space-y-2">
          <Label
            htmlFor="flatNumber"
            className="text-lg font-semibold text-foreground"
          >
            Flat Number <span className="text-destructive">*</span>
          </Label>
          <input
            id="flatNumber"
            type="text"
            value={flatNumber}
            onChange={(e) => setFlatNumber(e.target.value)}
            placeholder="e.g. A-101"
            className="w-full h-12 px-4 text-base rounded-xl border border-input bg-background text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring focus:border-transparent"
            data-ocid="new_complaint.flat_number_input"
            required
          />
        </div>

        {/* Description */}
        <div className="space-y-2">
          <Label
            htmlFor="description"
            className="text-lg font-semibold text-foreground"
          >
            Description <span className="text-destructive">*</span>
          </Label>
          <Textarea
            id="description"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            placeholder="Please describe the problem in detail..."
            className="min-h-[120px] text-base resize-none"
            data-ocid="new_complaint.description_textarea"
            required
          />
          <p
            className={cn(
              "text-sm",
              description.length < 10
                ? "text-muted-foreground"
                : "text-emerald-600",
            )}
          >
            {description.length} characters{" "}
            {description.length < 10 && "(minimum 10)"}
          </p>
        </div>

        {/* Photo Upload */}
        <div className="space-y-3">
          <Label className="text-lg font-semibold text-foreground">
            Photo{" "}
            <span className="text-muted-foreground font-normal text-base">
              (Optional)
            </span>
          </Label>

          {photoPreview ? (
            <Card className="relative overflow-hidden border border-border">
              <img
                src={photoPreview}
                alt="Preview of the selected complaint attachment"
                className="w-full max-h-64 object-cover"
              />
              <button
                type="button"
                onClick={removePhoto}
                className="absolute top-2 right-2 w-10 h-10 rounded-full bg-destructive text-destructive-foreground flex items-center justify-center shadow-md hover:bg-destructive/80 transition-smooth"
                aria-label="Remove photo"
                data-ocid="new_complaint.remove_photo_button"
              >
                <X className="w-5 h-5" />
              </button>
            </Card>
          ) : (
            <div className="grid grid-cols-2 gap-3">
              <button
                type="button"
                onClick={() => cameraInputRef.current?.click()}
                className="flex flex-col items-center gap-2 p-4 rounded-xl border-2 border-dashed border-border bg-muted/30 hover:bg-muted/60 transition-smooth min-h-[88px] text-center"
                data-ocid="new_complaint.camera_button"
              >
                <Camera className="w-8 h-8 text-primary" />
                <span className="text-base font-medium text-foreground">
                  Take Photo
                </span>
              </button>
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="flex flex-col items-center gap-2 p-4 rounded-xl border-2 border-dashed border-border bg-muted/30 hover:bg-muted/60 transition-smooth min-h-[88px] text-center"
                data-ocid="new_complaint.upload_button"
              >
                <ImagePlus className="w-8 h-8 text-primary" />
                <span className="text-base font-medium text-foreground">
                  Choose File
                </span>
              </button>
            </div>
          )}

          <input
            ref={cameraInputRef}
            type="file"
            accept="image/*"
            capture="environment"
            className="hidden"
            onChange={handleFileChange}
            data-ocid="new_complaint.camera_input"
          />
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            className="hidden"
            onChange={handleFileChange}
            data-ocid="new_complaint.file_input"
          />
        </div>

        {/* Submit */}
        <div className="flex flex-col gap-3 pt-2 pb-6">
          <Button
            type="submit"
            className="w-full h-14 text-lg font-semibold"
            disabled={!canSubmit || submitting}
            data-ocid="new_complaint.submit_button"
          >
            {submitting ? (
              <span className="flex items-center gap-2">
                <LoadingSpinner size="sm" />
                Submitting...
              </span>
            ) : (
              "Submit Complaint"
            )}
          </Button>
          <Button
            type="button"
            variant="ghost"
            className="w-full h-12 text-base"
            onClick={() => void navigate({ to: "/complaints" })}
            data-ocid="new_complaint.cancel_button"
          >
            Cancel
          </Button>
        </div>
      </form>
    </Layout>
  );
}
