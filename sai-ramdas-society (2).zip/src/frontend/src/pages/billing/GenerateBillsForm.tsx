import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { CalendarDays, IndianRupee } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { useActor } from "../../lib/backend-client";

interface GenerateBillsFormProps {
  onSuccess: () => void;
}

export default function GenerateBillsForm({
  onSuccess,
}: GenerateBillsFormProps) {
  const { actor } = useActor();
  const queryClient = useQueryClient();
  const [amount, setAmount] = useState("");
  const [dueDate, setDueDate] = useState("");
  const [errors, setErrors] = useState<{ amount?: string; dueDate?: string }>(
    {},
  );

  const mutation = useMutation({
    mutationFn: async () => {
      if (!actor) throw new Error("Not connected");
      const amountNum = Number(amount);
      const dueDateMs = new Date(dueDate).getTime();
      const dueDateNano = BigInt(dueDateMs) * 1_000_000n;
      await actor.generateMonthlyBills(BigInt(amountNum), dueDateNano);
    },
    onSuccess: () => {
      toast.success("Bills generated for all flats!", { duration: 4000 });
      void queryClient.invalidateQueries({ queryKey: ["bills"] });
      onSuccess();
    },
    onError: () => {
      toast.error("Failed to generate bills. Please try again.", {
        duration: 4000,
      });
    },
  });

  function validate(): boolean {
    const errs: { amount?: string; dueDate?: string } = {};
    const amountNum = Number(amount);
    if (!amount || Number.isNaN(amountNum) || amountNum <= 0) {
      errs.amount = "Please enter a valid amount greater than ₹0.";
    }
    if (!dueDate) {
      errs.dueDate = "Please select a due date.";
    } else if (new Date(dueDate) < new Date()) {
      errs.dueDate = "Due date must be in the future.";
    }
    setErrors(errs);
    return Object.keys(errs).length === 0;
  }

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (validate()) mutation.mutate();
  }

  // Default due date: end of next month
  const defaultDueDate = (() => {
    const now = new Date();
    const next = new Date(now.getFullYear(), now.getMonth() + 2, 0);
    return next.toISOString().split("T")[0];
  })();

  return (
    <form onSubmit={handleSubmit} className="space-y-5 pt-2">
      <div className="bg-muted/40 rounded-xl p-4 text-base text-muted-foreground">
        This will generate one maintenance bill for <strong>every flat</strong>{" "}
        in the society. Each bill will use the amount and due date you set
        below.
      </div>

      <div className="space-y-1.5">
        <Label htmlFor="bill-amount" className="text-base font-semibold">
          Maintenance Amount
        </Label>
        <div className="relative">
          <IndianRupee className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            id="bill-amount"
            type="number"
            min="1"
            placeholder="e.g. 2500"
            value={amount}
            onChange={(e) => {
              setAmount(e.target.value);
              if (errors.amount)
                setErrors((p) => ({ ...p, amount: undefined }));
            }}
            className="pl-9 h-12 text-lg"
            data-ocid="billing.generate_amount_input"
            aria-describedby={errors.amount ? "amount-error" : undefined}
          />
        </div>
        {errors.amount && (
          <p
            id="amount-error"
            className="text-sm text-destructive flex items-center gap-1"
            data-ocid="billing.generate_amount_field_error"
          >
            {errors.amount}
          </p>
        )}
      </div>

      <div className="space-y-1.5">
        <Label htmlFor="bill-due-date" className="text-base font-semibold">
          Due Date
        </Label>
        <div className="relative">
          <CalendarDays className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            id="bill-due-date"
            type="date"
            value={dueDate || defaultDueDate}
            onChange={(e) => {
              setDueDate(e.target.value);
              if (errors.dueDate)
                setErrors((p) => ({ ...p, dueDate: undefined }));
            }}
            className="pl-9 h-12 text-base"
            data-ocid="billing.generate_due_date_input"
            aria-describedby={errors.dueDate ? "due-date-error" : undefined}
          />
        </div>
        {errors.dueDate && (
          <p
            id="due-date-error"
            className="text-sm text-destructive flex items-center gap-1"
            data-ocid="billing.generate_due_date_field_error"
          >
            {errors.dueDate}
          </p>
        )}
      </div>

      <div className="flex gap-3 pt-2">
        <Button
          type="button"
          variant="outline"
          className="flex-1 btn-accessible"
          onClick={onSuccess}
          disabled={mutation.isPending}
          data-ocid="billing.generate_cancel_button"
        >
          Cancel
        </Button>
        <Button
          type="submit"
          className="flex-1 btn-accessible"
          disabled={mutation.isPending}
          data-ocid="billing.generate_submit_button"
        >
          {mutation.isPending ? "Generating…" : "Generate Bills"}
        </Button>
      </div>
    </form>
  );
}
