import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Skeleton } from "@/components/ui/skeleton";
import { cn } from "@/lib/utils";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { AlertTriangle, CheckCircle, Wallet } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { Layout } from "../../components/Layout";
import { EmptyState } from "../../components/ui/EmptyState";
import { PageHeader } from "../../components/ui/PageHeader";
import { useRole } from "../../hooks/use-role";
import { useActor } from "../../lib/backend-client";
import { BillStatus } from "../../types";
import type { Bill } from "../../types";
import type { AppRole } from "../../types";

function formatCurrency(amount: bigint): string {
  return `₹${Number(amount).toLocaleString("en-IN")}`;
}

function formatDate(ts: bigint): string {
  return new Date(Number(ts) / 1_000_000).toLocaleDateString("en-IN", {
    day: "numeric",
    month: "short",
    year: "numeric",
  });
}

function BillStatusBadge({ status }: { status: BillStatus }) {
  const config = {
    [BillStatus.paid]: {
      label: "Paid",
      className: "bg-green-100 text-green-800 border-green-200",
      icon: <CheckCircle className="w-3.5 h-3.5" />,
    },
    [BillStatus.unpaid]: {
      label: "Unpaid",
      className: "bg-yellow-100 text-yellow-800 border-yellow-200",
      icon: null,
    },
    [BillStatus.overdue]: {
      label: "Overdue",
      className: "bg-red-100 text-red-800 border-red-200",
      icon: <AlertTriangle className="w-3.5 h-3.5" />,
    },
  };
  const c = config[status];
  return (
    <Badge
      variant="outline"
      className={cn(
        "flex items-center gap-1 text-sm font-semibold px-3 py-1",
        c.className,
      )}
    >
      {c.icon}
      {c.label}
    </Badge>
  );
}

interface PayDialogProps {
  bill: Bill;
  open: boolean;
  onClose: () => void;
}

function PayDialog({ bill, open, onClose }: PayDialogProps) {
  const { actor } = useActor();
  const queryClient = useQueryClient();
  const [method, setMethod] = useState("UPI");
  const [txnId, setTxnId] = useState("");

  const mutation = useMutation({
    mutationFn: async () => {
      if (!actor) throw new Error("Not connected");
      await actor.recordPayment(bill.billId, method, txnId || "CASH");
    },
    onSuccess: () => {
      toast.success("Payment recorded! Your bill is now marked as Paid.");
      void queryClient.invalidateQueries({ queryKey: ["bills", "flat"] });
      onClose();
    },
    onError: () => {
      toast.error("Payment could not be recorded. Please try again.");
    },
  });

  const total = bill.amount + bill.penaltyAmount;

  return (
    <Dialog open={open} onOpenChange={(v) => !v && onClose()}>
      <DialogContent
        className="max-w-sm mx-auto"
        data-ocid="resident_billing.pay_dialog"
      >
        <DialogHeader>
          <DialogTitle className="text-xl font-bold font-display">
            Pay Bill
          </DialogTitle>
        </DialogHeader>
        <div className="space-y-4 pt-2">
          <div className="bg-muted/40 rounded-xl p-4 text-base space-y-2">
            <div className="flex justify-between">
              <span className="text-muted-foreground">Maintenance</span>
              <span className="font-semibold">
                {formatCurrency(bill.amount)}
              </span>
            </div>
            {bill.penaltyAmount > 0n && (
              <div className="flex justify-between text-red-700">
                <span className="flex items-center gap-1">
                  <AlertTriangle className="w-4 h-4" /> Late Penalty
                </span>
                <span className="font-semibold">
                  +{formatCurrency(bill.penaltyAmount)}
                </span>
              </div>
            )}
            <div className="border-t border-border pt-2 flex justify-between font-bold text-lg">
              <span>Total</span>
              <span className="text-primary">{formatCurrency(total)}</span>
            </div>
          </div>

          <div className="space-y-1.5">
            <label
              className="block text-base font-medium"
              htmlFor="res-pay-method"
            >
              Payment Method
            </label>
            <select
              id="res-pay-method"
              value={method}
              onChange={(e) => setMethod(e.target.value)}
              className="w-full border border-input rounded-lg px-3 h-12 text-base bg-background"
              data-ocid="resident_billing.payment_method_select"
            >
              <option>UPI</option>
              <option>Cash</option>
              <option>NEFT/RTGS</option>
              <option>Cheque</option>
            </select>
          </div>

          <div className="space-y-1.5">
            <label className="block text-base font-medium" htmlFor="res-txn-id">
              Transaction ID{" "}
              <span className="text-muted-foreground font-normal">
                (optional)
              </span>
            </label>
            <input
              id="res-txn-id"
              type="text"
              value={txnId}
              onChange={(e) => setTxnId(e.target.value)}
              placeholder="e.g. UPI123456"
              className="w-full border border-input rounded-lg px-3 h-12 text-base bg-background"
              data-ocid="resident_billing.transaction_id_input"
            />
          </div>

          <div className="flex gap-3 pt-1">
            <Button
              variant="outline"
              className="flex-1 btn-accessible"
              onClick={onClose}
              disabled={mutation.isPending}
              data-ocid="resident_billing.cancel_button"
            >
              Cancel
            </Button>
            <Button
              className="flex-1 btn-accessible"
              onClick={() => mutation.mutate()}
              disabled={mutation.isPending}
              data-ocid="resident_billing.confirm_button"
            >
              {mutation.isPending ? "Processing…" : "Confirm Payment"}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}

function BillCard({
  bill,
  index,
  onPay,
}: {
  bill: Bill;
  index: number;
  onPay: (bill: Bill) => void;
}) {
  const isPending = bill.status !== BillStatus.paid;
  const isOverdue = bill.status === BillStatus.overdue;

  return (
    <Card
      className={cn(
        "shadow-card transition-smooth",
        isOverdue && "border-red-300",
      )}
      data-ocid={`resident_billing.item.${index}`}
    >
      <CardContent className="p-5">
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div className="flex-1 min-w-0 space-y-3">
            <div className="flex flex-wrap items-center gap-2">
              <span className="text-lg font-bold font-display">
                {formatDate(bill.issuedDate)}
              </span>
              <BillStatusBadge status={bill.status} />
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 gap-x-4 gap-y-2 text-base">
              <div>
                <span className="text-xs text-muted-foreground uppercase tracking-wide block">
                  Amount
                </span>
                <span className="text-xl font-bold text-foreground">
                  {formatCurrency(bill.amount)}
                </span>
              </div>
              <div>
                <span className="text-xs text-muted-foreground uppercase tracking-wide block">
                  Due Date
                </span>
                <span
                  className={cn(
                    "font-medium",
                    isOverdue ? "text-red-700 font-bold" : "text-foreground",
                  )}
                >
                  {formatDate(bill.dueDate)}
                </span>
              </div>
              {bill.penaltyAmount > 0n && (
                <div>
                  <span className="text-xs text-red-600 uppercase tracking-wide block">
                    Late Penalty
                  </span>
                  <span className="font-bold text-red-700 flex items-center gap-1">
                    <AlertTriangle className="w-4 h-4" />
                    {formatCurrency(bill.penaltyAmount)}
                  </span>
                </div>
              )}
              {bill.paidDate && (
                <div>
                  <span className="text-xs text-green-700 uppercase tracking-wide block">
                    Paid On
                  </span>
                  <span className="font-medium text-green-700">
                    {formatDate(bill.paidDate)}
                  </span>
                </div>
              )}
            </div>

            {isOverdue && (
              <div className="flex items-center gap-2 text-red-700 text-sm bg-red-50 rounded-lg px-3 py-2">
                <AlertTriangle className="w-4 h-4 shrink-0" />
                This bill is overdue. Please pay immediately to avoid additional
                penalty.
              </div>
            )}
          </div>

          {isPending && (
            <Button
              className="btn-accessible shrink-0"
              onClick={() => onPay(bill)}
              data-ocid={`resident_billing.pay_button.${index}`}
            >
              <Wallet className="w-4 h-4 mr-2" />
              Pay Now
            </Button>
          )}
        </div>
      </CardContent>
    </Card>
  );
}

// Summary card showing outstanding amount
function BillSummary({ bills }: { bills: Bill[] }) {
  const outstanding = bills
    .filter((b) => b.status !== BillStatus.paid)
    .reduce((sum, b) => sum + b.amount + b.penaltyAmount, 0n);
  const overdue = bills.filter((b) => b.status === BillStatus.overdue).length;
  const paid = bills.filter((b) => b.status === BillStatus.paid).length;

  if (bills.length === 0) return null;

  return (
    <div className="grid grid-cols-3 gap-3 mb-4">
      <Card className="shadow-card">
        <CardContent className="p-4 text-center">
          <p className="text-xs text-muted-foreground uppercase tracking-wide mb-1">
            Outstanding
          </p>
          <p className="text-xl font-bold text-primary">
            {outstanding > 0n
              ? `₹${Number(outstanding).toLocaleString("en-IN")}`
              : "₹0"}
          </p>
        </CardContent>
      </Card>
      <Card className="shadow-card">
        <CardContent className="p-4 text-center">
          <p className="text-xs text-red-600 uppercase tracking-wide mb-1">
            Overdue
          </p>
          <p className="text-xl font-bold text-red-700">{overdue}</p>
        </CardContent>
      </Card>
      <Card className="shadow-card">
        <CardContent className="p-4 text-center">
          <p className="text-xs text-green-700 uppercase tracking-wide mb-1">
            Paid
          </p>
          <p className="text-xl font-bold text-green-700">{paid}</p>
        </CardContent>
      </Card>
    </div>
  );
}

export default function ResidentBillingPage() {
  const { getRole } = useRole();
  const role = getRole() as AppRole;
  const { actor, isFetching } = useActor();
  const [selectedBill, setSelectedBill] = useState<Bill | null>(null);

  // For residents: get their flat bills; fallback to sample flat A-101 for demo
  // Use flat number from localStorage (set at login) or fallback to demo flat "A-101"
  const flatNumber =
    typeof window !== "undefined"
      ? (localStorage.getItem("flatNumber") ?? "A-101")
      : "A-101";

  const {
    data: bills,
    isLoading,
    error,
  } = useQuery<Bill[]>({
    queryKey: ["bills", "flat", flatNumber],
    queryFn: async () => {
      if (!actor) return [];
      return actor.getBillsByFlat(flatNumber);
    },
    enabled: !!actor && !isFetching,
  });

  const sortedBills = bills
    ? [...bills].sort((a, b) => {
        const order = {
          [BillStatus.overdue]: 0,
          [BillStatus.unpaid]: 1,
          [BillStatus.paid]: 2,
        };
        return order[a.status] - order[b.status];
      })
    : [];

  return (
    <Layout role={role}>
      <PageHeader
        title="My Bills"
        subtitle="View and pay your maintenance bills"
        icon="🧾"
      />

      <div className="p-4 md:p-6 max-w-2xl mx-auto">
        {isLoading && (
          <div className="space-y-3" data-ocid="resident_billing.loading_state">
            {[1, 2, 3].map((i) => (
              <Skeleton key={i} className="h-36 rounded-xl" />
            ))}
          </div>
        )}

        {error && (
          <div
            className="flex flex-col items-center gap-3 py-10 text-center"
            data-ocid="resident_billing.error_state"
          >
            <AlertTriangle className="w-10 h-10 text-destructive" />
            <p className="text-lg font-medium text-destructive">
              Could not load your bills. Please refresh.
            </p>
          </div>
        )}

        {!isLoading && !error && sortedBills.length === 0 && (
          <EmptyState
            icon="🎉"
            title="No bills found"
            description="You have no maintenance bills at this time. Great job staying current!"
            data-ocid="resident_billing.empty_state"
          />
        )}

        {!isLoading && !error && sortedBills.length > 0 && (
          <>
            <BillSummary bills={sortedBills} />
            <div className="space-y-4">
              {sortedBills.map((bill, i) => (
                <BillCard
                  key={String(bill.billId)}
                  bill={bill}
                  index={i + 1}
                  onPay={setSelectedBill}
                />
              ))}
            </div>
          </>
        )}
      </div>

      {selectedBill && (
        <PayDialog
          bill={selectedBill}
          open={!!selectedBill}
          onClose={() => setSelectedBill(null)}
        />
      )}
    </Layout>
  );
}
