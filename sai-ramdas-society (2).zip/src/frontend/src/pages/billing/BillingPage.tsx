import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import { cn } from "@/lib/utils";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import {
  AlertTriangle,
  CheckCircle,
  MessageCircle,
  RefreshCw,
  Wallet,
} from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { Layout } from "../../components/Layout";
import { EmptyState } from "../../components/ui/EmptyState";
import { PageHeader } from "../../components/ui/PageHeader";
import { useRole } from "../../hooks/use-role";
import { useActor } from "../../lib/backend-client";
import { BillStatus } from "../../types";
import type { AppRole, Bill } from "../../types";
import GenerateBillsForm from "./GenerateBillsForm";

function formatCurrency(amount: bigint): string {
  return `₹${Number(amount).toLocaleString("en-IN")}`;
}

function formatDate(ts: bigint): string {
  return new Date(Number(ts) / 1_000_000).toLocaleDateString("en-IN", {
    day: "numeric",
    month: "short",
    year: "numeric",
  });
}

// ─── WhatsApp Reminder Helper ─────────────────────────────────────────────────

function buildWhatsAppUrl(
  mobile: string,
  residentName: string,
  amount: bigint,
  dueDate: bigint,
): string {
  const cleanMobile = mobile.replace(/^0/, "");
  const dueDateStr = formatDate(dueDate);
  const message = `Dear ${residentName}, your maintenance bill of Rs.${Number(amount).toLocaleString("en-IN")} was due on ${dueDateStr}. Please pay at the earliest. Thank you, Sai Ramdas Society`;
  return `https://wa.me/91${cleanMobile}?text=${encodeURIComponent(message)}`;
}

// ─── Overdue Alert Banner ─────────────────────────────────────────────────────

function OverdueBillAlert({ bills }: { bills: Bill[] }) {
  const now = Date.now();
  const hasOverdue = bills.some(
    (b) => b.status !== BillStatus.paid && Number(b.dueDate) / 1_000_000 < now,
  );
  if (!hasOverdue) return null;
  return (
    <div
      className="flex items-start gap-3 p-4 rounded-xl bg-destructive/10 border border-destructive/40 mb-4"
      data-ocid="billing.overdue_alert"
      role="alert"
    >
      <AlertTriangle className="w-5 h-5 text-destructive mt-0.5 flex-shrink-0" />
      <div>
        <p className="text-base font-bold text-destructive leading-snug">
          ⚠️ Overdue Bills Alert
        </p>
        <p className="text-sm text-destructive/90 mt-0.5">
          Some bills have passed their due date. Please collect payments
          immediately.
        </p>
      </div>
    </div>
  );
}

// ─── Status Badge ─────────────────────────────────────────────────────────────

function BillStatusBadge({ status }: { status: BillStatus }) {
  const config = {
    [BillStatus.paid]: {
      label: "Paid",
      className: "bg-green-700/20 text-green-300 border-green-700/30",
      icon: <CheckCircle className="w-3 h-3" />,
    },
    [BillStatus.unpaid]: {
      label: "Unpaid",
      className: "bg-yellow-700/20 text-yellow-300 border-yellow-700/30",
      icon: null,
    },
    [BillStatus.overdue]: {
      label: "Overdue",
      className: "bg-red-700/20 text-red-300 border-red-700/30",
      icon: <AlertTriangle className="w-3 h-3" />,
    },
  };
  const c = config[status];
  return (
    <Badge
      variant="outline"
      className={cn(
        "flex items-center gap-1 text-xs font-semibold px-2 py-0.5",
        c.className,
      )}
    >
      {c.icon}
      {c.label}
    </Badge>
  );
}

// ─── Mark Paid Dialog ─────────────────────────────────────────────────────────

function MarkPaidDialog({
  bill,
  open,
  onClose,
}: { bill: Bill; open: boolean; onClose: () => void }) {
  const { actor } = useActor();
  const queryClient = useQueryClient();
  const [method, setMethod] = useState("UPI");
  const [txnId, setTxnId] = useState("");

  const mutation = useMutation({
    mutationFn: async () => {
      if (!actor) throw new Error("Not connected");
      await actor.recordPayment(bill.billId, method, txnId || "CASH");
    },
    onSuccess: () => {
      toast.success("Bill marked as paid!", { duration: 4000 });
      void queryClient.invalidateQueries({ queryKey: ["bills", "unpaid"] });
      onClose();
    },
    onError: () => toast.error("Failed to record payment.", { duration: 4000 }),
  });

  return (
    <Dialog open={open} onOpenChange={(v) => !v && onClose()}>
      <DialogContent
        className="max-w-sm mx-auto"
        data-ocid="billing.mark_paid_dialog"
      >
        <DialogHeader>
          <DialogTitle className="text-xl font-bold font-display">
            Record Payment
          </DialogTitle>
        </DialogHeader>
        <div className="space-y-4 pt-2">
          <div className="bg-muted/40 rounded-xl p-4 text-base">
            <div className="flex justify-between mb-1">
              <span className="text-muted-foreground">Flat</span>
              <span className="font-semibold">{bill.flatNumber}</span>
            </div>
            <div className="flex justify-between mb-1">
              <span className="text-muted-foreground">Amount</span>
              <span className="font-semibold">
                {formatCurrency(bill.amount)}
              </span>
            </div>
            {bill.penaltyAmount > 0n && (
              <div className="flex justify-between text-destructive">
                <span>Penalty</span>
                <span className="font-semibold">
                  +{formatCurrency(bill.penaltyAmount)}
                </span>
              </div>
            )}
          </div>

          <div className="space-y-1.5">
            <Label htmlFor="pay-method" className="text-base font-medium">
              Payment Method
            </Label>
            <select
              id="pay-method"
              value={method}
              onChange={(e) => setMethod(e.target.value)}
              className="w-full border border-input rounded-lg px-3 h-12 text-base bg-background"
              data-ocid="billing.payment_method_select"
            >
              <option>UPI</option>
              <option>Cash</option>
              <option>NEFT/RTGS</option>
              <option>Cheque</option>
            </select>
          </div>

          <div className="space-y-1.5">
            <Label htmlFor="txn-id" className="text-base font-medium">
              Transaction ID{" "}
              <span className="text-muted-foreground font-normal">
                (Optional)
              </span>
            </Label>
            <Input
              id="txn-id"
              type="text"
              value={txnId}
              onChange={(e) => setTxnId(e.target.value)}
              placeholder="e.g. UPI123456"
              className="h-12 text-base"
              data-ocid="billing.transaction_id_input"
            />
          </div>

          <div className="flex gap-3 pt-2">
            <Button
              variant="outline"
              className="flex-1 btn-accessible"
              onClick={onClose}
              disabled={mutation.isPending}
              data-ocid="billing.cancel_button"
            >
              Cancel
            </Button>
            <Button
              className="flex-1 btn-accessible"
              onClick={() => mutation.mutate()}
              disabled={mutation.isPending}
              data-ocid="billing.confirm_button"
            >
              {mutation.isPending ? (
                <span data-ocid="billing.confirm_loading_state">Saving…</span>
              ) : (
                "Mark as Paid"
              )}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}

// ─── Compact Bill Row ─────────────────────────────────────────────────────────

function BillRow({
  bill,
  index,
  onMarkPaid,
  isAdmin,
  residentName,
  mobile,
}: {
  bill: Bill;
  index: number;
  onMarkPaid: (bill: Bill) => void;
  isAdmin: boolean;
  residentName?: string;
  mobile?: string;
}) {
  const canMarkPaid = isAdmin && bill.status !== BillStatus.paid;
  const now = Date.now();
  const isOverdueByDate =
    bill.status !== BillStatus.paid && Number(bill.dueDate) / 1_000_000 < now;
  const isOverdue = isOverdueByDate || bill.status === BillStatus.overdue;

  return (
    <div
      className={cn(
        "flex items-center gap-3 px-3 py-2.5 border-b border-border last:border-0",
        isOverdue && "bg-destructive/5",
      )}
      data-ocid={`billing.item.${index}`}
    >
      {/* Flat + amount */}
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2 flex-wrap">
          <span
            className={cn(
              "font-bold text-base",
              isOverdue ? "text-red-500" : "text-foreground",
            )}
          >
            Flat {bill.flatNumber}
            {residentName && (
              <span
                className={cn(
                  "ml-1 font-normal text-sm",
                  isOverdue ? "text-red-400" : "text-muted-foreground",
                )}
              >
                — {residentName}
              </span>
            )}
          </span>
          <BillStatusBadge status={bill.status} />
          {bill.penaltyAmount > 0n && (
            <span className="text-xs text-destructive font-medium">
              +{formatCurrency(bill.penaltyAmount)} penalty
            </span>
          )}
        </div>
        <div className="flex items-center gap-3 mt-0.5">
          <span
            className={cn(
              "text-base font-semibold",
              isOverdue ? "text-red-500" : "text-foreground",
            )}
          >
            {formatCurrency(bill.amount)}
          </span>
          <span className="text-sm text-muted-foreground">
            Due: {formatDate(bill.dueDate)}
          </span>
        </div>
      </div>

      {/* Send Reminder (overdue only) */}
      {isOverdue && mobile && (
        <a
          href={buildWhatsAppUrl(
            mobile,
            residentName ?? `Flat ${bill.flatNumber}`,
            bill.amount,
            bill.dueDate,
          )}
          target="_blank"
          rel="noopener noreferrer"
          data-ocid={`billing.send_reminder_button.${index}`}
          className="flex-shrink-0"
        >
          <Button
            size="sm"
            variant="outline"
            className="h-9 text-xs gap-1 border-orange-500/50 text-orange-500 hover:bg-orange-500/10 hover:text-orange-400"
            tabIndex={-1}
          >
            <MessageCircle className="w-3.5 h-3.5" />
            Remind
          </Button>
        </a>
      )}

      {/* Mark paid */}
      {canMarkPaid && (
        <Button
          size="sm"
          className="btn-accessible flex-shrink-0 h-9 text-sm gap-1"
          onClick={() => onMarkPaid(bill)}
          data-ocid={`billing.mark_paid_button.${index}`}
        >
          <Wallet className="w-3.5 h-3.5" />
          Mark Paid
        </Button>
      )}
    </div>
  );
}

// ─── Main Page ────────────────────────────────────────────────────────────────

export default function BillingPage() {
  const { getRole } = useRole();
  const role = getRole() as AppRole;
  const { actor, isFetching } = useActor();
  const queryClient = useQueryClient();
  const [selectedBill, setSelectedBill] = useState<Bill | null>(null);
  const [showGenerate, setShowGenerate] = useState(false);

  const {
    data: bills,
    isLoading,
    error,
  } = useQuery<Bill[]>({
    queryKey: ["bills", "unpaid"],
    queryFn: async () => {
      if (!actor) return [];
      return actor.getAllUnpaidBills();
    },
    enabled: !!actor && !isFetching,
  });

  const applyPenaltiesMutation = useMutation({
    mutationFn: async () => {
      if (!actor) throw new Error("Not connected");
      await actor.applyPenalties();
    },
    onSuccess: () => {
      toast.success("Penalties applied.", { duration: 4000 });
      void queryClient.invalidateQueries({ queryKey: ["bills", "unpaid"] });
    },
    onError: () =>
      toast.error("Failed to apply penalties.", { duration: 4000 }),
  });

  const isAdmin = role === "admin" || role === "committee";

  return (
    <Layout role={role}>
      <PageHeader
        title="Maintenance Bills"
        subtitle="Society maintenance billing management"
        icon="💰"
        actions={
          isAdmin ? (
            <div className="flex gap-2 flex-wrap">
              <Button
                variant="outline"
                className="btn-accessible"
                onClick={() => applyPenaltiesMutation.mutate()}
                disabled={applyPenaltiesMutation.isPending}
                data-ocid="billing.apply_penalties_button"
              >
                <AlertTriangle className="w-4 h-4 mr-1.5 text-destructive" />
                Apply Penalties
              </Button>
              <Button
                className="btn-accessible"
                onClick={() => setShowGenerate(true)}
                data-ocid="billing.generate_bills_button"
              >
                <RefreshCw className="w-4 h-4 mr-1.5" />
                Generate Bills
              </Button>
            </div>
          ) : null
        }
      />

      <div className="px-4 pt-2 pb-4 max-w-4xl mx-auto">
        {/* Overdue alert banner */}
        {!isLoading && bills && bills.length > 0 && (
          <OverdueBillAlert bills={bills} />
        )}

        {isLoading && (
          <div className="space-y-1 mt-2" data-ocid="billing.loading_state">
            {[1, 2, 3, 4].map((i) => (
              <Skeleton key={i} className="h-14 rounded-lg" />
            ))}
          </div>
        )}

        {error && (
          <div
            className="flex flex-col items-center gap-3 py-10 text-center"
            data-ocid="billing.error_state"
          >
            <AlertTriangle className="w-10 h-10 text-destructive" />
            <p className="text-lg font-medium text-destructive">
              Failed to load bills. Please refresh.
            </p>
          </div>
        )}

        {!isLoading && !error && (bills?.length ?? 0) === 0 && (
          <div className="mt-4">
            <EmptyState
              icon="✅"
              title="All Bills Paid!"
              description="No unpaid or overdue bills at the moment."
              data-ocid="billing.empty_state"
            />
          </div>
        )}

        {!isLoading && !error && (bills?.length ?? 0) > 0 && (
          <div className="mt-2 border border-border rounded-xl overflow-hidden bg-card">
            {bills?.map((bill, i) => (
              <BillRow
                key={String(bill.billId)}
                bill={bill}
                index={i + 1}
                onMarkPaid={setSelectedBill}
                isAdmin={isAdmin}
              />
            ))}
          </div>
        )}
      </div>

      {selectedBill && (
        <MarkPaidDialog
          bill={selectedBill}
          open={!!selectedBill}
          onClose={() => setSelectedBill(null)}
        />
      )}

      <Dialog open={showGenerate} onOpenChange={setShowGenerate}>
        <DialogContent
          className="max-w-md mx-auto"
          data-ocid="billing.generate_bills_dialog"
        >
          <DialogHeader>
            <DialogTitle className="text-xl font-bold font-display">
              Generate Monthly Bills
            </DialogTitle>
          </DialogHeader>
          <GenerateBillsForm onSuccess={() => setShowGenerate(false)} />
        </DialogContent>
      </Dialog>
    </Layout>
  );
}
