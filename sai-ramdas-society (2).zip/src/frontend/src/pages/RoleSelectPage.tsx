import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { useNavigate } from "@tanstack/react-router";
import { useEffect } from "react";
import { LoadingSpinner } from "../components/ui/LoadingSpinner";
import { useAuth } from "../hooks/use-auth";
import { useRole } from "../hooks/use-role";
import { ROLE_CONFIGS } from "../types";
import type { AppRole } from "../types";

const ROLES: AppRole[] = ["admin", "committee", "resident", "security"];

const ROLE_BADGE_CLASSES: Record<AppRole, string> = {
  admin: "bg-primary/10 text-primary border-primary/30",
  committee: "bg-secondary text-secondary-foreground",
  resident: "bg-muted text-foreground",
  security: "bg-accent/20 text-accent-foreground border-accent/30",
};

// ─── Main Page ────────────────────────────────────────────────────────────────

export default function RoleSelectPage() {
  const navigate = useNavigate();
  const { isAuthenticated, isInitializing } = useAuth();
  const { setRole } = useRole();

  useEffect(() => {
    if (!isInitializing && !isAuthenticated) {
      void navigate({ to: "/login" });
    }
  }, [isAuthenticated, isInitializing, navigate]);

  if (isInitializing) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <LoadingSpinner size="lg" label="Checking session..." />
      </div>
    );
  }

  const handleRoleClick = (role: AppRole) => {
    setRole(role);
    void navigate({ to: "/dashboard" });
  };

  return (
    <div
      className="min-h-screen bg-background flex flex-col"
      data-ocid="role_select.page"
    >
      {/* Header */}
      <div className="bg-primary text-primary-foreground px-6 pt-10 pb-14 text-center">
        <div className="w-16 h-16 rounded-2xl bg-primary-foreground/20 mx-auto mb-3 flex items-center justify-center text-4xl">
          🏢
        </div>
        <h1 className="font-display text-2xl font-bold">Sai Ramdas Society</h1>
        <p className="text-primary-foreground/80 mt-1">
          Select your role to continue
        </p>
      </div>

      <div className="flex-1 flex flex-col items-center px-4 -mt-6 pb-8">
        <div className="w-full max-w-md bg-card rounded-2xl shadow-card border border-border p-6">
          <h2 className="font-display text-xl font-bold text-foreground mb-1">
            Who are you?
          </h2>
          <p className="text-muted-foreground text-base mb-6">
            Choose your role to see the right features for you.
          </p>

          <div className="flex flex-col gap-3" data-ocid="role_select.list">
            {ROLES.map((role, idx) => {
              const config = ROLE_CONFIGS[role];
              return (
                <button
                  key={role}
                  type="button"
                  onClick={() => handleRoleClick(role)}
                  data-ocid={`role_select.item.${idx + 1}`}
                  className="flex items-center gap-4 w-full p-4 rounded-xl border transition-smooth text-left touch-target group border-border hover:border-primary/40 hover:bg-primary/5"
                >
                  <div className="w-12 h-12 rounded-xl bg-muted flex items-center justify-center text-2xl flex-shrink-0 group-hover:scale-110 transition-transform">
                    {config.icon}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-0.5">
                      <span className="font-semibold text-foreground text-lg">
                        {config.label}
                      </span>
                      <Badge
                        className={ROLE_BADGE_CLASSES[role]}
                        variant="outline"
                      >
                        {config.label}
                      </Badge>
                    </div>
                    <p className="text-muted-foreground text-sm line-clamp-2">
                      {config.description}
                    </p>
                  </div>
                  <div className="text-muted-foreground group-hover:text-primary transition-colors">
                    →
                  </div>
                </button>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}
