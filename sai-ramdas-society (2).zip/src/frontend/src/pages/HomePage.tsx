import { Skeleton } from "@/components/ui/skeleton";
import { useNavigate } from "@tanstack/react-router";
import { BookOpen, Building2 } from "lucide-react";
import { motion } from "motion/react";
import { useRole } from "../hooks/use-role";
import {
  getOpenComplaintsCount,
  useActiveSocietyMembers,
  useAllComplaints,
  useAllResidents,
  useAllUnpaidBills,
  useTodayVisitors,
  useTotalFlatsOverride,
  useTotalShopsOverride,
} from "../hooks/useQueries";
import { SOCIETY_MEMBER_ROLE_LABELS, type SocietyMember } from "../types";

// ─── Tool card data ───────────────────────────────────────────────────────────

interface ToolCard {
  id: string;
  title: string;
  emoji: string;
  route: string;
  color: string;
  shadowColor: string;
  adminOnly?: boolean;
}

const tools: ToolCard[] = [
  {
    id: "members",
    title: "Members",
    emoji: "👥",
    route: "/residents",
    color: "bg-blue-500/15 text-blue-600",
    shadowColor: "rgba(59,130,246,0.35)",
  },
  {
    id: "bills",
    title: "Bills",
    emoji: "🧾",
    route: "/bills",
    color: "bg-emerald-500/15 text-emerald-600",
    shadowColor: "rgba(16,185,129,0.35)",
  },
  {
    id: "complaints",
    title: "Complaints",
    emoji: "💬",
    route: "/complaints",
    color: "bg-orange-500/15 text-orange-600",
    shadowColor: "rgba(249,115,22,0.35)",
  },
  {
    id: "visitors",
    title: "Visitors",
    emoji: "🚶",
    route: "/visitors",
    color: "bg-purple-500/15 text-purple-600",
    shadowColor: "rgba(168,85,247,0.35)",
  },
  {
    id: "notices",
    title: "Notices",
    emoji: "🔔",
    route: "/notices",
    color: "bg-rose-500/15 text-rose-600",
    shadowColor: "rgba(244,63,94,0.35)",
  },
  {
    id: "pre-approved",
    title: "Pre-Approved",
    emoji: "⭐",
    route: "/visitors/pre-approved",
    color: "bg-cyan-500/15 text-cyan-600",
    shadowColor: "rgba(6,182,212,0.35)",
  },
  {
    id: "security",
    title: "Security",
    emoji: "🛡️",
    route: "/visitors/log",
    color: "bg-slate-500/15 text-slate-600",
    shadowColor: "rgba(100,116,139,0.35)",
  },
  {
    id: "dashboard",
    title: "Dashboard",
    emoji: "🏢",
    route: "/dashboard",
    color: "bg-fuchsia-500/15 text-fuchsia-600",
    shadowColor: "rgba(217,70,239,0.35)",
  },
  {
    id: "rules",
    title: "Rules",
    emoji: "📜",
    route: "/rules",
    color: "bg-indigo-500/15 text-indigo-600",
    shadowColor: "rgba(99,102,241,0.35)",
  },
  {
    id: "settings",
    title: "Settings",
    emoji: "⚙️",
    route: "/admin/settings",
    color: "bg-slate-400/15 text-slate-600",
    shadowColor: "rgba(100,116,139,0.3)",
    adminOnly: true,
  },
];

// ─── Animation variants ───────────────────────────────────────────────────────

const containerVariants = {
  hidden: {},
  visible: { transition: { staggerChildren: 0.04 } },
};

const cardVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: {
    opacity: 1,
    y: 0,
    transition: {
      duration: 0.3,
      ease: [0.25, 0.46, 0.45, 0.94] as [number, number, number, number],
    },
  },
};

const heroVariants = {
  hidden: { opacity: 0, y: -20 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.5 } },
};

const sectionVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.4, ease: "easeOut" as const },
  },
};

// ─── Role avatar colour map ───────────────────────────────────────────────────

const ROLE_RING_COLORS: Record<
  string,
  { ring: string; shadow: string; glow: string }
> = {
  chairman: {
    ring: "#facc15",
    shadow: "rgba(234,179,8,0.6)",
    glow: "rgba(250,204,21,0.4)",
  },
  viceChairman: {
    ring: "#fb923c",
    shadow: "rgba(249,115,22,0.6)",
    glow: "rgba(251,146,60,0.4)",
  },
  secretary: {
    ring: "#60a5fa",
    shadow: "rgba(59,130,246,0.6)",
    glow: "rgba(96,165,250,0.4)",
  },
  treasurer: {
    ring: "#4ade80",
    shadow: "rgba(34,197,94,0.6)",
    glow: "rgba(74,222,128,0.4)",
  },
  member: {
    ring: "#a78bfa",
    shadow: "rgba(139,92,246,0.6)",
    glow: "rgba(167,139,250,0.4)",
  },
};

const ROLE_BADGE_COLORS: Record<string, string> = {
  chairman: "bg-yellow-100 text-yellow-800 border-yellow-200",
  viceChairman: "bg-orange-100 text-orange-800 border-orange-200",
  secretary: "bg-blue-100 text-blue-800 border-blue-200",
  treasurer: "bg-green-100 text-green-800 border-green-200",
  member: "bg-violet-100 text-violet-800 border-violet-200",
};

// ─── Committee member card ────────────────────────────────────────────────────

function MemberCard({
  member,
  index,
}: { member: SocietyMember; index: number }) {
  const initials = member.nameEnglish
    .split(" ")
    .filter((w) => /^[A-Z]/.test(w))
    .slice(0, 2)
    .map((w) => w[0])
    .join("");

  const roleColors = ROLE_RING_COLORS[member.role] ?? {
    ring: "#6366f1",
    shadow: "rgba(99,102,241,0.5)",
    glow: "rgba(99,102,241,0.3)",
  };
  const badgeColor =
    ROLE_BADGE_COLORS[member.role] ?? "bg-muted text-foreground border-border";
  const roleLabel = SOCIETY_MEMBER_ROLE_LABELS[member.role];

  return (
    <motion.div
      data-ocid={`committee.member_card.${index + 1}`}
      variants={cardVariants}
      className="flex flex-col items-center gap-2 p-4 rounded-2xl bg-card border border-border transition-smooth text-center min-w-[140px]"
      style={{
        boxShadow:
          "0 4px 6px rgba(0,0,0,0.07), 0 10px 20px rgba(0,0,0,0.05), 0 1px 0 rgba(255,255,255,0.9) inset",
        transform: "translateZ(0)",
      }}
    >
      {/* 3D photo circle — larger + embossed ring */}
      <div
        className="relative flex-shrink-0"
        style={{
          width: 96,
          height: 96,
        }}
      >
        {/* Outer glow layer */}
        <div
          className="absolute inset-0 rounded-full"
          style={{
            background: `radial-gradient(circle at 35% 35%, ${roleColors.ring}60, transparent 70%)`,
            filter: "blur(6px)",
            transform: "scale(1.12)",
          }}
        />
        {/* Main ring with 3D bevel effect */}
        <div
          className="absolute inset-0 rounded-full"
          style={{
            background: `conic-gradient(from 135deg, ${roleColors.ring}ff, ${roleColors.ring}88, ${roleColors.ring}ff)`,
            boxShadow: [
              `0 0 0 3px ${roleColors.ring}`,
              `0 4px 12px ${roleColors.shadow}`,
              "inset 0 1px 2px rgba(255,255,255,0.6)",
              "inset 0 -1px 2px rgba(0,0,0,0.2)",
              `0 0 20px ${roleColors.glow}`,
            ].join(", "),
          }}
        />
        {/* Inner photo area */}
        <div
          className="absolute rounded-full overflow-hidden flex items-center justify-center"
          style={{
            inset: 5,
            background:
              "linear-gradient(135deg, oklch(0.85 0.05 204), oklch(0.65 0.15 270))",
            boxShadow:
              "inset 0 2px 6px rgba(0,0,0,0.25), inset 0 -1px 3px rgba(255,255,255,0.15)",
          }}
        >
          {member.photoId ? (
            <img
              src={member.photoId}
              alt={member.nameEnglish}
              className="w-full h-full object-cover"
            />
          ) : (
            <span className="text-2xl font-bold text-white font-display drop-shadow">
              {initials || "?"}
            </span>
          )}
        </div>
      </div>

      <div className="min-w-0 w-full">
        <p className="font-display font-bold text-sm text-foreground leading-tight truncate">
          {member.nameEnglish}
        </p>
      </div>
      <span
        className={`inline-flex items-center text-xs font-semibold px-2 py-1 rounded-full border ${badgeColor}`}
      >
        {roleLabel}
      </span>
    </motion.div>
  );
}

const SKELETON_IDS = ["sk1", "sk2", "sk3", "sk4", "sk5"] as const;

function CommitteeSkeleton() {
  return (
    <div className="flex gap-3 overflow-x-auto pb-2">
      {SKELETON_IDS.map((id) => (
        <div
          key={id}
          className="flex flex-col items-center gap-2 p-4 rounded-2xl bg-card border border-border min-w-[140px]"
        >
          <Skeleton className="w-24 h-24 rounded-full" />
          <Skeleton className="h-3.5 w-20" />
          <Skeleton className="h-5 w-16 rounded-full" />
        </div>
      ))}
    </div>
  );
}

// ─── Society Overview Hexagon ─────────────────────────────────────────────────

const _HEX_CLIP = "circle(50%)"; // Changed to circular

interface StatItem {
  label: string;
  value: number | string;
  emoji: string;
  /** Hex face gradient: top-lighter, bottom-darker */
  faceGradient: string;
  /** Ring/border color for outer hex */
  ringGradient: string;
  /** Glow color for drop-shadow */
  glowColor: string;
  ocid: string;
}

interface StatHexProps extends StatItem {
  delay?: number;
}

function StatHex({
  label,
  value,
  emoji,
  faceGradient,
  ringGradient,
  glowColor,
  ocid,
  delay = 0,
}: StatHexProps) {
  return (
    <motion.div
      data-ocid={ocid}
      variants={cardVariants}
      transition={{ delay }}
      className="flex-shrink-0 flex items-center justify-center"
      style={{
        width: "clamp(96px, 14vw, 118px)",
        height: "clamp(96px, 14vw, 118px)",
        filter: `drop-shadow(0 6px 10px ${glowColor}) drop-shadow(0 2px 4px rgba(0,0,0,0.25))`,
      }}
    >
      {/* Outer rim — light-top bevel simulation */}
      <div
        className="w-full h-full flex items-center justify-center rounded-full"
        style={{
          background: ringGradient,
          boxShadow:
            "inset 0 2px 3px rgba(255,255,255,0.5), inset 0 -2px 3px rgba(0,0,0,0.3)",
        }}
      >
        {/* Face circle — colored gradient with 3D depth */}
        <div
          className="flex flex-col items-center justify-center gap-0.5 rounded-full"
          style={{
            width: "88%",
            height: "88%",
            background: faceGradient,
            boxShadow: [
              "inset 0 3px 6px rgba(255,255,255,0.3)",
              "inset 0 -3px 6px rgba(0,0,0,0.25)",
              "inset 3px 0 4px rgba(255,255,255,0.1)",
            ].join(", "),
          }}
        >
          {/* Floating emoji icon */}
          <span
            className="leading-none select-none"
            style={{
              fontSize: "clamp(16px, 2.2vw, 20px)",
              filter:
                "drop-shadow(0 2px 3px rgba(0,0,0,0.35)) drop-shadow(0 0 6px rgba(255,255,255,0.3))",
              transform: "translateY(-1px)",
              display: "block",
            }}
          >
            {emoji}
          </span>
          <p
            className="text-base font-bold font-display leading-none text-white tabular-nums"
            style={{ textShadow: "0 1px 3px rgba(0,0,0,0.4)" }}
          >
            {value}
          </p>
          <p
            className="text-[8px] font-semibold text-white/85 leading-tight text-center px-2 max-w-full"
            style={{ textShadow: "0 1px 2px rgba(0,0,0,0.3)" }}
          >
            {label}
          </p>
        </div>
      </div>
    </motion.div>
  );
}

// CenterHex removed — label circle is now inlined in the Society Overview pipeline layout

function HoneycombSkeleton() {
  return (
    <div className="flex items-center gap-0 overflow-x-auto py-2">
      {/* Label placeholder */}
      <div
        className="flex-shrink-0 bg-muted animate-pulse rounded-full mr-4"
        style={{ width: 80, height: 80 }}
      />
      {/* Line placeholder */}
      <div className="h-0.5 w-6 bg-muted animate-pulse flex-shrink-0" />
      {[1, 2, 3, 4, 5, 6].map((k) => (
        <div key={k} className="flex items-center">
          <div
            className="flex-shrink-0 bg-muted animate-pulse rounded-full"
            style={{
              width: "clamp(72px, 11vw, 96px)",
              height: "clamp(72px, 11vw, 96px)",
            }}
          />
          {k < 6 && (
            <div className="h-0.5 w-4 bg-muted animate-pulse flex-shrink-0" />
          )}
        </div>
      ))}
    </div>
  );
}

// ─── HomePage ─────────────────────────────────────────────────────────────────

export default function HomePage() {
  const navigate = useNavigate();
  const { getRole } = useRole();
  const role = getRole();
  const isAdmin = role === "admin";

  const { data: committeeMembers, isLoading: loadingMembers } =
    useActiveSocietyMembers();
  const { data: residents = [], isLoading: residentsLoading } =
    useAllResidents();
  const { data: unpaidBills = [], isLoading: billsLoading } =
    useAllUnpaidBills();
  const { data: complaints = [], isLoading: complaintsLoading } =
    useAllComplaints();
  const { data: todayVisitors = [], isLoading: visitorsLoading } =
    useTodayVisitors();
  const { data: totalFlatsOverride, isLoading: flatsLoading } =
    useTotalFlatsOverride();
  const { data: totalShopsOverride, isLoading: shopsLoading } =
    useTotalShopsOverride();

  const statsLoading =
    residentsLoading ||
    billsLoading ||
    complaintsLoading ||
    visitorsLoading ||
    flatsLoading ||
    shopsLoading;

  const totalFlats =
    totalFlatsOverride !== null && totalFlatsOverride !== undefined
      ? Number(totalFlatsOverride)
      : "—";
  const totalShops =
    totalShopsOverride !== undefined ? Number(totalShopsOverride) : "—";
  const openComplaints = getOpenComplaintsCount(complaints);

  const stats: StatItem[] = [
    {
      label: "Total Flats",
      value: totalFlats,
      emoji: "🏠",
      faceGradient:
        "linear-gradient(145deg, #3b82f6 0%, #2563eb 55%, #1e40af 100%)",
      ringGradient: "linear-gradient(145deg, #93c5fd 0%, #1d4ed8 100%)",
      glowColor: "rgba(59,130,246,0.45)",
      ocid: "home.stat.flats",
    },
    {
      label: "Total Shops",
      value: totalShops,
      emoji: "🏪",
      faceGradient:
        "linear-gradient(145deg, #6366f1 0%, #4f46e5 55%, #3730a3 100%)",
      ringGradient: "linear-gradient(145deg, #a5b4fc 0%, #3730a3 100%)",
      glowColor: "rgba(99,102,241,0.45)",
      ocid: "home.stat.shops",
    },
    {
      label: "Residents",
      value: residents.length,
      emoji: "👨‍👩‍👧",
      faceGradient:
        "linear-gradient(145deg, #10b981 0%, #059669 55%, #047857 100%)",
      ringGradient: "linear-gradient(145deg, #6ee7b7 0%, #065f46 100%)",
      glowColor: "rgba(16,185,129,0.45)",
      ocid: "home.stat.residents",
    },
    {
      label: "Unpaid Bills",
      value: unpaidBills.length,
      emoji: "💰",
      faceGradient:
        "linear-gradient(145deg, #ef4444 0%, #dc2626 55%, #b91c1c 100%)",
      ringGradient: "linear-gradient(145deg, #fca5a5 0%, #991b1b 100%)",
      glowColor: "rgba(239,68,68,0.45)",
      ocid: "home.stat.unpaid_bills",
    },
    {
      label: "Complaints",
      value: openComplaints,
      emoji: "💬",
      faceGradient:
        "linear-gradient(145deg, #f97316 0%, #ea580c 55%, #c2410c 100%)",
      ringGradient: "linear-gradient(145deg, #fdba74 0%, #9a3412 100%)",
      glowColor: "rgba(249,115,22,0.45)",
      ocid: "home.stat.open_complaints",
    },
    {
      label: "Visitors Today",
      value: todayVisitors.length,
      emoji: "👣",
      faceGradient:
        "linear-gradient(145deg, #8b5cf6 0%, #7c3aed 55%, #6d28d9 100%)",
      ringGradient: "linear-gradient(145deg, #c4b5fd 0%, #4c1d95 100%)",
      glowColor: "rgba(139,92,246,0.45)",
      ocid: "home.stat.today_visitors",
    },
  ];

  const visibleTools = tools.filter((t) => !t.adminOnly || isAdmin);

  return (
    <div
      className="relative min-h-screen"
      style={{
        background:
          "linear-gradient(160deg, #e8f0ff 0%, #f0f4ff 30%, #ffffff 60%, #f5f0ff 100%)",
      }}
    >
      {/* Full-page watermark background */}
      <img
        src="/assets/images/sr_building.jpeg"
        alt=""
        aria-hidden="true"
        className="absolute inset-0 w-full h-full object-cover opacity-[0.08] pointer-events-none select-none z-0"
      />
      {/* Page content above watermark */}
      <div className="relative z-10">
        {/* Header */}
        <header
          className="sticky top-0 z-50 backdrop-blur-sm border-b"
          style={{
            background:
              "linear-gradient(135deg, oklch(0.98 0.01 264) 0%, oklch(0.96 0.02 264) 100%)",
            boxShadow:
              "0 4px 16px rgba(59,130,246,0.12), 0 2px 6px rgba(0,0,0,0.08), 0 1px 0 rgba(255,255,255,0.9) inset",
          }}
        >
          <div className="max-w-5xl mx-auto px-4 py-3 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-xl bg-primary flex items-center justify-center shadow-sm">
                <Building2 className="w-5 h-5 text-primary-foreground" />
              </div>
              <div className="font-display font-bold text-sm text-foreground leading-tight">
                Sai Ramdas Society
              </div>
            </div>
            <button
              type="button"
              data-ocid="header.login_button"
              className="btn-accessible touch-target font-semibold bg-primary text-primary-foreground px-4 py-1.5 rounded-xl text-sm shadow-sm hover:opacity-90 transition-smooth focus-visible:ring-2 focus-visible:ring-ring focus-visible:outline-none"
              onClick={() => navigate({ to: "/login" })}
            >
              Member Login
            </button>
          </div>
        </header>

        {/* Hero */}
        <motion.section
          className="max-w-5xl mx-auto px-4 pt-6 pb-3"
          variants={heroVariants}
          initial="hidden"
          animate="visible"
        >
          <div className="flex items-center justify-between gap-4">
            {/* Left: Building Photo */}
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.1, duration: 0.4 }}
              className="flex-shrink-0"
            >
              <img
                src="/assets/images/sr_building.jpeg"
                alt="SR Building"
                className="h-36 w-36 rounded-2xl object-cover border-2 border-border shadow-md"
              />
            </motion.div>

            {/* Center: Welcome text */}
            <div
              className="flex-1 text-center min-w-0"
              style={{
                background: "rgba(255,255,255,0.72)",
                backdropFilter: "blur(12px)",
                borderRadius: "1.25rem",
                padding: "1rem 1.25rem",
                boxShadow:
                  "0 4px 24px rgba(59,130,246,0.10), 0 1px 4px rgba(0,0,0,0.06), inset 0 1px 0 rgba(255,255,255,0.9)",
                border: "1px solid rgba(99,102,241,0.12)",
              }}
            >
              <motion.div
                className="inline-flex items-center gap-2 bg-primary/10 border border-primary/20 rounded-full px-3 py-1 mb-3"
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.2, duration: 0.3 }}
              >
                <span className="text-xs font-medium text-primary">
                  🏠 Welcome
                </span>
              </motion.div>
              <h1 className="font-display font-bold text-3xl md:text-4xl text-foreground mb-1.5 leading-tight">
                Sai Ramdas Society
              </h1>
              <p className="text-sm text-muted-foreground max-w-md mx-auto">
                Complete housing society management — bills, complaints,
                visitors and more.
              </p>
            </div>

            {/* Right: SR Logo */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.1, duration: 0.4 }}
              className="flex-shrink-0"
            >
              <img
                src="/assets/images/sai_ramdas_nameplate.jpeg"
                alt="Sai Ramdas Name Plate"
                className="h-36 w-36 rounded-2xl object-cover border-2 border-border shadow-md"
              />
            </motion.div>
          </div>
        </motion.section>

        {/* ─── Committee Section ───────────────────────────────────────────────── */}
        <motion.section
          className="max-w-5xl mx-auto px-4 mb-4"
          variants={sectionVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          data-ocid="committee.section"
        >
          <div
            className="rounded-2xl bg-gradient-to-br from-primary/8 via-accent/10 to-secondary/20 border border-border/60 px-4 py-4"
            style={{
              boxShadow:
                "0 6px 24px rgba(99,102,241,0.10), 0 3px 8px rgba(0,0,0,0.06), inset 0 1px 0 rgba(255,255,255,0.85)",
            }}
          >
            <div className="flex items-center gap-2.5 mb-4">
              <div className="w-7 h-7 rounded-lg bg-primary/10 flex items-center justify-center">
                <BookOpen className="w-3.5 h-3.5 text-primary" />
              </div>
              <div>
                <h2
                  className="font-display font-bold text-sm text-foreground leading-tight"
                  style={{ textShadow: "0 1px 2px rgba(0,0,0,0.08)" }}
                >
                  Our Committee
                </h2>
                <p className="text-xs text-muted-foreground">
                  Society management body
                </p>
              </div>
            </div>

            {loadingMembers ? (
              <CommitteeSkeleton />
            ) : (
              <motion.div
                className="flex gap-3 overflow-x-auto pb-1 md:flex-wrap md:overflow-visible md:justify-center"
                variants={containerVariants}
                initial="hidden"
                whileInView="visible"
                viewport={{ once: true }}
                data-ocid="committee.members_list"
              >
                {(committeeMembers ?? []).map((member) => (
                  <MemberCard
                    key={Number(member.id)}
                    member={member}
                    index={Number(member.orderNumber) - 1}
                  />
                ))}
                {(!committeeMembers || committeeMembers.length === 0) && (
                  <div
                    data-ocid="committee.empty_state"
                    className="w-full py-6 text-center text-muted-foreground"
                  >
                    <span className="text-2xl block mb-1">👥</span>
                    <p className="text-sm font-medium">
                      Committee information not available
                    </p>
                  </div>
                )}
              </motion.div>
            )}
          </div>
        </motion.section>

        {/* ─── Society Overview — single horizontal pipeline row ────────────── */}
        <motion.section
          className="max-w-5xl mx-auto px-4 mb-4"
          variants={sectionVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          data-ocid="home.stats_section"
        >
          <div
            className="rounded-2xl border border-primary/20"
            style={{
              background:
                "linear-gradient(145deg, #f0f7ff 0%, #e8f0fe 40%, #ede9fe 100%)",
              boxShadow:
                "0 8px 32px rgba(59,130,246,0.12), 0 4px 12px rgba(0,0,0,0.06), inset 0 1px 0 rgba(255,255,255,0.9)",
            }}
          >
            {statsLoading ? (
              <div className="py-5 px-4 overflow-x-auto">
                <HoneycombSkeleton />
              </div>
            ) : (
              <motion.div
                className="py-5 px-4 overflow-x-auto"
                variants={containerVariants}
                initial="hidden"
                whileInView="visible"
                viewport={{ once: true }}
              >
                {/* Single horizontal pipeline row — scrollable on mobile */}
                <div className="flex items-center min-w-max gap-0">
                  {/* ── Left label circle ── */}
                  <motion.div
                    variants={cardVariants}
                    className="flex-shrink-0 flex items-center justify-center"
                    style={{
                      width: 88,
                      height: 88,
                      filter:
                        "drop-shadow(0 6px 12px rgba(59,130,246,0.45)) drop-shadow(0 2px 4px rgba(0,0,0,0.25))",
                    }}
                  >
                    <div
                      className="w-full h-full flex items-center justify-center rounded-full"
                      style={{
                        background:
                          "linear-gradient(145deg, rgba(255,255,255,0.85) 0%, rgba(186,230,253,0.7) 40%, rgba(147,197,253,0.5) 100%)",
                        boxShadow:
                          "inset 0 3px 5px rgba(255,255,255,0.7), inset 0 -3px 5px rgba(30,64,175,0.3)",
                      }}
                    >
                      <motion.div
                        className="flex flex-col items-center justify-center gap-0.5 rounded-full"
                        style={{
                          width: "88%",
                          height: "88%",
                          background:
                            "linear-gradient(145deg, #3b82f6 0%, #2563eb 45%, #1d4ed8 100%)",
                          boxShadow: [
                            "inset 0 4px 8px rgba(255,255,255,0.35)",
                            "inset 0 -4px 8px rgba(0,0,0,0.3)",
                            "inset 3px 0 6px rgba(255,255,255,0.15)",
                          ].join(", "),
                        }}
                        animate={{
                          boxShadow: [
                            "inset 0 4px 8px rgba(255,255,255,0.35), inset 0 -4px 8px rgba(0,0,0,0.3), 0 0 0px 0px rgba(59,130,246,0)",
                            "inset 0 4px 8px rgba(255,255,255,0.35), inset 0 -4px 8px rgba(0,0,0,0.3), 0 0 18px 6px rgba(59,130,246,0.5)",
                            "inset 0 4px 8px rgba(255,255,255,0.35), inset 0 -4px 8px rgba(0,0,0,0.3), 0 0 0px 0px rgba(59,130,246,0)",
                          ],
                        }}
                        transition={{
                          duration: 2.5,
                          repeat: Number.POSITIVE_INFINITY,
                          ease: "easeInOut",
                        }}
                      >
                        <span
                          style={{
                            fontSize: 20,
                            filter:
                              "drop-shadow(0 2px 4px rgba(0,0,0,0.4)) drop-shadow(0 0 8px rgba(255,255,255,0.4))",
                            transform: "translateY(-1px)",
                            display: "block",
                            lineHeight: 1,
                          }}
                        >
                          🏘️
                        </span>
                        <p
                          className="text-[8px] font-bold font-display text-white text-center leading-tight px-1"
                          style={{ textShadow: "0 1px 3px rgba(0,0,0,0.4)" }}
                        >
                          Society
                          <br />
                          Overview
                        </p>
                      </motion.div>
                    </div>
                  </motion.div>

                  {/* ── Pipeline connector + 6 stat circles ── */}
                  {stats.map((stat, i) => (
                    <div key={stat.ocid} className="flex items-center">
                      {/* Connecting line segment */}
                      <div
                        className="flex-shrink-0"
                        style={{
                          width: 20,
                          height: 3,
                          background:
                            "linear-gradient(90deg, rgba(99,102,241,0.35) 0%, rgba(99,102,241,0.6) 50%, rgba(99,102,241,0.35) 100%)",
                          borderRadius: 2,
                          boxShadow: "0 1px 3px rgba(99,102,241,0.3)",
                        }}
                      />
                      {/* Stat circle */}
                      <StatHex {...stat} delay={i * 0.07} />
                    </div>
                  ))}
                </div>
              </motion.div>
            )}
          </div>
        </motion.section>

        {/* ─── Tool Cards Grid ─────────────────────────────────────────────────── */}
        <main className="max-w-5xl mx-auto px-4 pb-10">
          <div className="flex items-center gap-3 mb-3">
            <div className="h-px flex-1 bg-border/50" />
            <motion.h2
              className="text-xs font-bold text-muted-foreground tracking-widest uppercase"
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              viewport={{ once: true }}
              transition={{ delay: 0.1 }}
            >
              All Features
            </motion.h2>
            <div className="h-px flex-1 bg-border/50" />
          </div>

          <motion.div
            className="grid grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-2.5"
            variants={containerVariants}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            data-ocid="home.tools_grid"
          >
            {visibleTools.map((tool, index) => (
              <motion.button
                key={tool.id}
                data-ocid={`home.tool_card.${index + 1}`}
                variants={cardVariants}
                whileHover={{
                  scale: 1.04,
                  y: -4,
                  boxShadow:
                    "0 8px 20px rgba(0,0,0,0.12), 0 3px 8px rgba(0,0,0,0.08)",
                }}
                whileTap={{ scale: 0.96 }}
                className="relative flex flex-col items-center gap-2 p-3 rounded-xl bg-card border-[1.5px] border-border/70 transition-smooth cursor-pointer focus:outline-none focus-visible:ring-2 focus-visible:ring-ring text-center"
                style={{
                  boxShadow:
                    "0 2px 4px rgba(0,0,0,0.06), 0 6px 14px rgba(0,0,0,0.06), inset 0 1px 0 rgba(255,255,255,0.85)",
                  borderTop: "1px solid rgba(255,255,255,0.8)",
                }}
                onClick={() => navigate({ to: tool.route as "/" })}
                aria-label={tool.title}
              >
                {/* 3D icon container */}
                <div
                  className={`w-10 h-10 rounded-xl ${tool.color} flex items-center justify-center`}
                  style={{
                    boxShadow: [
                      `0 4px 8px ${tool.shadowColor}`,
                      "inset 0 1px 2px rgba(255,255,255,0.5)",
                      "inset 0 -1px 2px rgba(0,0,0,0.1)",
                    ].join(", "),
                  }}
                >
                  <span
                    className="leading-none select-none"
                    style={{
                      fontSize: "20px",
                      filter: `drop-shadow(0 2px 3px ${tool.shadowColor}) drop-shadow(0 1px 2px rgba(0,0,0,0.2))`,
                      transform: "translateY(-0.5px)",
                      display: "block",
                    }}
                  >
                    {tool.emoji}
                  </span>
                </div>

                {/* Text */}
                <span className="text-xs font-semibold text-foreground leading-tight">
                  {tool.title}
                </span>

                {/* Admin badge */}
                {tool.adminOnly && (
                  <span className="absolute top-1.5 right-1.5 bg-primary/10 text-primary text-[9px] font-bold px-1.5 py-0.5 rounded-full">
                    Admin
                  </span>
                )}
              </motion.button>
            ))}
          </motion.div>
        </main>

        {/* Footer */}
        <footer className="bg-card/80 border-t py-4 text-center text-xs text-muted-foreground">
          <p>© 2026 Sai Ramdas Society. Built with using ai by Pradip Ivare</p>
        </footer>
      </div>
      {/* end relative z-10 content wrapper */}
    </div>
  );
}
