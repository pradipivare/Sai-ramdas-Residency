import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { cn } from "@/lib/utils";
import { useNavigate } from "@tanstack/react-router";
import {
  AlertCircle,
  Bell,
  CheckCircle2,
  Clock,
  DoorOpen,
  Home,
  Phone,
  Receipt,
  XCircle,
} from "lucide-react";
import { Layout } from "../../components/Layout";
import { useRole } from "../../hooks/use-role";
import {
  formatCurrency,
  formatDate,
  useAllNotices,
  useBillsByFlat,
  useComplaintsByFlat,
} from "../../hooks/useQueries";
import type { AppRole, Bill, Complaint, Notice } from "../../types";
import { BillStatus, ComplaintStatus, NoticeType } from "../../types";

// ─── Bill status display ──────────────────────────────────────────────────────

function BillStatusBadge({ status }: { status: BillStatus }) {
  if (status === BillStatus.paid) {
    return (
      <Badge className="bg-primary/10 text-primary border-0 gap-1">
        <CheckCircle2 className="w-3.5 h-3.5" /> Paid
      </Badge>
    );
  }
  if (status === BillStatus.overdue) {
    return (
      <Badge variant="destructive" className="gap-1">
        <XCircle className="w-3.5 h-3.5" /> Overdue
      </Badge>
    );
  }
  return (
    <Badge className="bg-accent/30 text-accent-foreground border-0 gap-1">
      <Clock className="w-3.5 h-3.5" /> Unpaid
    </Badge>
  );
}

// ─── Complaint status display ─────────────────────────────────────────────────

function ComplaintStatusBadge({ status }: { status: ComplaintStatus }) {
  if (status === ComplaintStatus.resolved) {
    return (
      <Badge className="bg-primary/10 text-primary border-0 gap-1">
        <CheckCircle2 className="w-3.5 h-3.5" /> Resolved
      </Badge>
    );
  }
  if (status === ComplaintStatus.inProgress) {
    return (
      <Badge className="bg-accent/30 text-accent-foreground border-0 gap-1">
        <Clock className="w-3.5 h-3.5" /> In Progress
      </Badge>
    );
  }
  return (
    <Badge variant="secondary" className="gap-1">
      <AlertCircle className="w-3.5 h-3.5" /> Pending
    </Badge>
  );
}

// ─── Bill card ────────────────────────────────────────────────────────────────

function BillRow({ bill, index }: { bill: Bill; index: number }) {
  return (
    <div
      className="flex items-center justify-between py-3 border-b border-border last:border-0"
      data-ocid={`dashboard.bill.item.${index + 1}`}
    >
      <div>
        <p className="text-base font-semibold text-foreground">
          Maintenance Bill
        </p>
        <p className="text-sm text-muted-foreground">
          Due: {formatDate(bill.dueDate)}
        </p>
      </div>
      <div className="text-right flex flex-col items-end gap-1">
        <p className="text-base font-bold text-foreground">
          {formatCurrency(bill.amount)}
          {bill.penaltyAmount > 0n && (
            <span className="text-sm text-destructive ml-1">
              +{formatCurrency(bill.penaltyAmount)} penalty
            </span>
          )}
        </p>
        <BillStatusBadge status={bill.status} />
      </div>
    </div>
  );
}

// ─── Complaint row ────────────────────────────────────────────────────────────

function ComplaintRow({
  complaint,
  index,
}: {
  complaint: Complaint;
  index: number;
}) {
  return (
    <div
      className="flex items-start justify-between py-3 border-b border-border last:border-0 gap-4"
      data-ocid={`dashboard.complaint.item.${index + 1}`}
    >
      <div className="flex-1 min-w-0">
        <p className="text-base font-semibold text-foreground capitalize">
          {complaint.category} Issue
        </p>
        <p className="text-sm text-muted-foreground mt-0.5 line-clamp-1">
          {complaint.description}
        </p>
      </div>
      <ComplaintStatusBadge status={complaint.status} />
    </div>
  );
}

// ─── Notice row ───────────────────────────────────────────────────────────────

function NoticeItem({ notice, index }: { notice: Notice; index: number }) {
  const isEmergency = notice.noticeType === NoticeType.emergency;
  return (
    <div
      className={cn(
        "p-3 rounded-xl mb-2 last:mb-0",
        isEmergency
          ? "bg-destructive/10 border border-destructive/30"
          : "bg-muted/50",
      )}
      data-ocid={`dashboard.notice.item.${index + 1}`}
    >
      <div className="flex items-center gap-2 mb-1 flex-wrap">
        <p className="text-base font-semibold text-foreground">
          {notice.title}
        </p>
        {isEmergency && (
          <Badge variant="destructive" className="text-xs">
            🚨 Emergency
          </Badge>
        )}
      </div>
      <p className="text-sm text-muted-foreground line-clamp-2">
        {notice.content}
      </p>
    </div>
  );
}

// ─── Main component ───────────────────────────────────────────────────────────

// Demo flat for display — real app would get from resident profile
const DEMO_FLAT = "A-101";

export default function ResidentDashboard() {
  const navigate = useNavigate();
  const { getRole } = useRole();
  const role = getRole() as AppRole;

  const { data: bills = [], isLoading: billsLoading } =
    useBillsByFlat(DEMO_FLAT);
  const { data: complaints = [], isLoading: complaintsLoading } =
    useComplaintsByFlat(DEMO_FLAT);
  const { data: notices = [], isLoading: noticesLoading } = useAllNotices();

  const recentBills = [...bills]
    .sort((a, b) => Number(b.issuedDate) - Number(a.issuedDate))
    .slice(0, 3);

  const openComplaints = complaints.filter(
    (c) =>
      c.status === ComplaintStatus.pending ||
      c.status === ComplaintStatus.inProgress,
  );

  const recentNotices = [...notices]
    .sort((a, b) => Number(b.postedAt) - Number(a.postedAt))
    .slice(0, 3);

  const nextDueBill = recentBills.find(
    (b) => b.status === BillStatus.unpaid || b.status === BillStatus.overdue,
  );

  return (
    <Layout role={role}>
      {/* Header banner */}
      <div className="bg-primary text-primary-foreground px-4 py-6">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-12 h-12 rounded-2xl bg-primary-foreground/20 flex items-center justify-center">
            <Home className="w-6 h-6" />
          </div>
          <div>
            <h1
              className="text-2xl font-bold font-display"
              data-ocid="dashboard.title"
            >
              My Dashboard
            </h1>
            <p className="text-base opacity-80">Flat {DEMO_FLAT}</p>
          </div>
        </div>

        {/* Next due bill highlight */}
        {nextDueBill && !billsLoading && (
          <div
            className="bg-primary-foreground/15 rounded-2xl p-4"
            data-ocid="dashboard.next_due_bill"
          >
            <p className="text-sm opacity-80 uppercase tracking-wide font-medium">
              Next Maintenance Due
            </p>
            <div className="flex items-end justify-between mt-1">
              <div>
                <p className="text-3xl font-bold font-display">
                  {formatCurrency(
                    nextDueBill.amount + nextDueBill.penaltyAmount,
                  )}
                </p>
                <p className="text-sm opacity-80 mt-0.5">
                  Due by {formatDate(nextDueBill.dueDate)}
                </p>
              </div>
              <Button
                variant="secondary"
                className="btn-accessible bg-primary-foreground/20 hover:bg-primary-foreground/30 text-primary-foreground border-0"
                onClick={() => void navigate({ to: "/bills" })}
                data-ocid="dashboard.pay_bill_button"
              >
                Pay Now
              </Button>
            </div>
          </div>
        )}
      </div>

      <div className="p-4 space-y-5 max-w-2xl mx-auto">
        {/* Quick links */}
        <div
          className="grid grid-cols-3 gap-3"
          data-ocid="dashboard.quick_links"
        >
          {[
            {
              icon: <Receipt className="w-6 h-6 text-primary" />,
              label: "My Bills",
              path: "/bills",
              ocid: "dashboard.bills_link",
              bg: "bg-primary/10",
            },
            {
              icon: <AlertCircle className="w-6 h-6 text-accent-foreground" />,
              label: "Complaints",
              path: "/complaints",
              ocid: "dashboard.complaints_link",
              bg: "bg-accent/20",
            },
            {
              icon: <DoorOpen className="w-6 h-6 text-primary" />,
              label: "Visitors",
              path: "/visitors",
              ocid: "dashboard.visitors_link",
              bg: "bg-primary/10",
            },
          ].map(({ icon, label, path, ocid, bg }) => (
            <button
              key={path}
              type="button"
              onClick={() => void navigate({ to: path })}
              data-ocid={ocid}
              className={cn(
                "flex flex-col items-center justify-center gap-2 p-4 rounded-2xl transition-smooth min-h-[88px] touch-target",
                bg,
                "hover:opacity-80 active:scale-95",
              )}
            >
              {icon}
              <span className="text-sm font-semibold text-foreground">
                {label}
              </span>
            </button>
          ))}
        </div>

        {/* My complaints */}
        <section aria-label="My complaints">
          <div className="flex items-center justify-between mb-3">
            <h2 className="text-lg font-semibold text-foreground">
              My Complaints
              {openComplaints.length > 0 && (
                <Badge className="ml-2 bg-accent/30 text-accent-foreground border-0">
                  {openComplaints.length} open
                </Badge>
              )}
            </h2>
            <Button
              variant="ghost"
              size="sm"
              className="text-primary text-base"
              onClick={() => void navigate({ to: "/complaints" })}
              data-ocid="dashboard.all_complaints_link"
            >
              View All
            </Button>
          </div>
          <Card
            className="shadow-card"
            data-ocid="dashboard.complaints_section"
          >
            <CardContent className="p-4">
              {complaintsLoading ? (
                <div className="space-y-3">
                  {[1, 2].map((i) => (
                    <Skeleton key={i} className="h-16 w-full" />
                  ))}
                </div>
              ) : openComplaints.length === 0 ? (
                <div
                  className="flex flex-col items-center py-6 gap-2 text-center"
                  data-ocid="dashboard.complaints.empty_state"
                >
                  <CheckCircle2 className="w-10 h-10 text-primary/60" />
                  <p className="text-base text-muted-foreground">
                    No open complaints. All good!
                  </p>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => void navigate({ to: "/complaints" })}
                    data-ocid="dashboard.raise_complaint_button"
                    className="btn-accessible mt-1"
                  >
                    Raise a Complaint
                  </Button>
                </div>
              ) : (
                openComplaints
                  .slice(0, 3)
                  .map((c, i) => (
                    <ComplaintRow
                      key={String(c.complaintId)}
                      complaint={c}
                      index={i}
                    />
                  ))
              )}
            </CardContent>
          </Card>
        </section>

        {/* Recent bills */}
        <section aria-label="Recent bills">
          <div className="flex items-center justify-between mb-3">
            <h2 className="text-lg font-semibold text-foreground">
              Recent Bills
            </h2>
            <Button
              variant="ghost"
              size="sm"
              className="text-primary text-base"
              onClick={() => void navigate({ to: "/bills" })}
              data-ocid="dashboard.all_bills_link"
            >
              View All
            </Button>
          </div>
          <Card className="shadow-card" data-ocid="dashboard.bills_section">
            <CardContent className="p-4">
              {billsLoading ? (
                <div className="space-y-3">
                  {[1, 2].map((i) => (
                    <Skeleton key={i} className="h-14 w-full" />
                  ))}
                </div>
              ) : recentBills.length === 0 ? (
                <p
                  className="text-muted-foreground text-base text-center py-6"
                  data-ocid="dashboard.bills.empty_state"
                >
                  No bills issued yet.
                </p>
              ) : (
                recentBills.map((b, i) => (
                  <BillRow key={String(b.billId)} bill={b} index={i} />
                ))
              )}
            </CardContent>
          </Card>
        </section>

        {/* Society announcements */}
        <section aria-label="Announcements">
          <div className="flex items-center justify-between mb-3">
            <h2 className="text-lg font-semibold text-foreground">
              <Bell className="w-5 h-5 inline mr-2 text-primary" />
              Announcements
            </h2>
            <Button
              variant="ghost"
              size="sm"
              className="text-primary text-base"
              onClick={() => void navigate({ to: "/notices" })}
              data-ocid="dashboard.all_notices_link"
            >
              View All
            </Button>
          </div>
          <div data-ocid="dashboard.notices_section">
            {noticesLoading ? (
              <div className="space-y-2">
                {[1, 2, 3].map((i) => (
                  <Skeleton key={i} className="h-16 w-full rounded-xl" />
                ))}
              </div>
            ) : recentNotices.length === 0 ? (
              <Card className="shadow-card">
                <CardContent className="p-6 text-center">
                  <p
                    className="text-muted-foreground text-base"
                    data-ocid="dashboard.notices.empty_state"
                  >
                    No announcements at this time.
                  </p>
                </CardContent>
              </Card>
            ) : (
              <div>
                {recentNotices.map((n, i) => (
                  <NoticeItem key={String(n.noticeId)} notice={n} index={i} />
                ))}
              </div>
            )}
          </div>
        </section>

        {/* Emergency contact */}
        <section aria-label="Emergency contact">
          <Card className="shadow-card border-destructive/30 bg-destructive/5">
            <CardHeader className="pb-2">
              <CardTitle className="text-base text-destructive flex items-center gap-2">
                <Phone className="w-5 h-5" /> Emergency Contacts
              </CardTitle>
            </CardHeader>
            <CardContent className="p-4 pt-0 grid grid-cols-2 gap-3">
              {[
                { label: "Security Gate", number: "+91 98765 43210" },
                { label: "Society Office", number: "+91 87654 32109" },
              ].map(({ label, number }) => (
                <a
                  key={label}
                  href={`tel:${number.replace(/\s+/g, "")}`}
                  className="flex items-center gap-2 p-3 bg-card rounded-xl border border-border hover:bg-muted/50 transition-smooth min-h-[56px]"
                  data-ocid={`dashboard.emergency.${label.toLowerCase().replace(/\s+/g, "_")}_link`}
                >
                  <Phone className="w-4 h-4 text-destructive flex-shrink-0" />
                  <div>
                    <p className="text-sm font-semibold text-foreground">
                      {label}
                    </p>
                    <p className="text-xs text-muted-foreground">{number}</p>
                  </div>
                </a>
              ))}
            </CardContent>
          </Card>
        </section>
      </div>
    </Layout>
  );
}
