import { Layout } from "@/components/Layout";
import { EmptyState } from "@/components/ui/EmptyState";
import { PageHeader } from "@/components/ui/PageHeader";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import { useRole } from "@/hooks/use-role";
import { useActor } from "@/lib/backend-client";
import type { AppRole, Visitor } from "@/types";
import { ApprovalStatus } from "@/types";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { CheckCircle, Clock, XCircle } from "lucide-react";
import { useState } from "react";

function formatTime(ts: bigint): string {
  const d = new Date(Number(ts) / 1_000_000);
  return d.toLocaleTimeString("en-IN", { hour: "2-digit", minute: "2-digit" });
}

function formatDate(ts: bigint): string {
  const d = new Date(Number(ts) / 1_000_000);
  return d.toLocaleDateString("en-IN", {
    day: "numeric",
    month: "short",
    year: "numeric",
  });
}

interface ApprovalCardProps {
  visitor: Visitor;
  index: number;
  onApprove: (id: bigint, otp: string) => void;
  onReject: (id: bigint) => void;
  isApproving: boolean;
  isRejecting: boolean;
  activeId: bigint | null;
}

function ApprovalCard({
  visitor,
  index,
  onApprove,
  onReject,
  isApproving,
  isRejecting,
  activeId,
}: ApprovalCardProps) {
  const [otp, setOtp] = useState("");
  const [otpError, setOtpError] = useState("");

  const isThisLoading =
    activeId === visitor.visitorId && (isApproving || isRejecting);

  const handleApprove = () => {
    if (!otp.trim()) {
      setOtpError("Please enter the OTP provided by the visitor");
      return;
    }
    setOtpError("");
    onApprove(visitor.visitorId, otp.trim());
  };

  const handleReject = () => {
    setOtpError("");
    onReject(visitor.visitorId);
  };

  return (
    <Card
      className="border border-border shadow-card overflow-hidden"
      data-ocid={`approval.item.${index + 1}`}
    >
      {/* Card header */}
      <div className="bg-yellow-50 border-b border-yellow-200 px-4 py-3 flex items-center gap-2">
        <Clock className="w-5 h-5 text-yellow-700" />
        <span className="font-semibold text-yellow-800 text-base">
          Awaiting Your Approval
        </span>
      </div>

      <div className="p-4 flex flex-col gap-4">
        {/* Visitor info */}
        <div className="flex flex-col gap-1">
          <h3 className="text-xl font-bold text-foreground">{visitor.name}</h3>
          <p className="text-base text-muted-foreground">
            Mobile:{" "}
            <span className="font-medium text-foreground">
              {visitor.mobile}
            </span>
          </p>
          <p className="text-base text-muted-foreground">
            Purpose:{" "}
            <span className="font-medium text-foreground">
              {visitor.purpose}
            </span>
          </p>
          <p className="text-sm text-muted-foreground">
            Arrived: {formatTime(visitor.entryTime)} ·{" "}
            {formatDate(visitor.entryTime)}
          </p>
        </div>

        {/* OTP Input */}
        <div className="flex flex-col gap-2">
          <Label
            htmlFor={`otp-${String(visitor.visitorId)}`}
            className="text-base font-semibold"
          >
            Enter OTP from Visitor
          </Label>
          <Input
            id={`otp-${String(visitor.visitorId)}`}
            type="text"
            inputMode="numeric"
            placeholder="Enter OTP code"
            value={otp}
            onChange={(e) => {
              setOtp(e.target.value);
              if (otpError) setOtpError("");
            }}
            className="h-12 text-lg font-mono tracking-widest"
            maxLength={8}
            data-ocid={`approval.otp_input.${index + 1}`}
            aria-invalid={!!otpError}
          />
          {otpError && (
            <p
              className="text-destructive text-sm font-medium"
              role="alert"
              data-ocid={`approval.field_error.${index + 1}`}
            >
              {otpError}
            </p>
          )}
        </div>

        {/* Action buttons */}
        <div className="flex flex-col sm:flex-row gap-3">
          <Button
            className="btn-accessible flex-1 h-14 text-base font-semibold bg-green-600 hover:bg-green-700 text-white border-0"
            onClick={handleApprove}
            disabled={isThisLoading}
            data-ocid={`approval.confirm_button.${index + 1}`}
          >
            <CheckCircle className="w-5 h-5 mr-2" />
            {isThisLoading && isApproving ? "Approving..." : "Approve Entry"}
          </Button>
          <Button
            variant="destructive"
            className="btn-accessible flex-1 h-14 text-base font-semibold"
            onClick={handleReject}
            disabled={isThisLoading}
            data-ocid={`approval.cancel_button.${index + 1}`}
          >
            <XCircle className="w-5 h-5 mr-2" />
            {isThisLoading && isRejecting ? "Rejecting..." : "Reject"}
          </Button>
        </div>
      </div>
    </Card>
  );
}

function HistoryRow({ visitor, index }: { visitor: Visitor; index: number }) {
  const isApproved = visitor.approvalStatus === ApprovalStatus.approved;
  return (
    <Card
      className="px-4 py-3 border border-border flex items-center gap-3 shadow-card"
      data-ocid={`approval.history_item.${index + 1}`}
    >
      {isApproved ? (
        <CheckCircle className="w-5 h-5 text-green-600 flex-shrink-0" />
      ) : (
        <XCircle className="w-5 h-5 text-red-500 flex-shrink-0" />
      )}
      <div className="flex-1 min-w-0">
        <p className="font-semibold text-foreground text-base">
          {visitor.name}
        </p>
        <p className="text-sm text-muted-foreground truncate">
          {visitor.purpose} · {formatTime(visitor.entryTime)}
        </p>
      </div>
      <span
        className={`text-sm font-medium px-3 py-1 rounded-full border ${
          isApproved
            ? "bg-green-50 text-green-700 border-green-200"
            : "bg-red-50 text-red-700 border-red-200"
        }`}
      >
        {isApproved ? "Approved" : "Rejected"}
      </span>
    </Card>
  );
}

export default function VisitorApprovalPage() {
  const { getRole } = useRole();
  const role = (getRole() ?? "resident") as AppRole;
  const { actor, isFetching } = useActor();
  const queryClient = useQueryClient();
  const [flatNumber, setFlatNumber] = useState("");
  const [submittedFlat, setSubmittedFlat] = useState("");
  const [activeId, setActiveId] = useState<bigint | null>(null);

  const { data: visitors, isLoading } = useQuery<Visitor[]>({
    queryKey: ["visitors", "flat", submittedFlat],
    queryFn: async () => {
      if (!actor || !submittedFlat.trim()) return [];
      return actor.getVisitorsByFlat(submittedFlat.trim().toUpperCase());
    },
    enabled: !!actor && !isFetching && submittedFlat.trim().length > 0,
    refetchInterval: 15_000,
  });

  const approveMutation = useMutation({
    mutationFn: async ({
      visitorId,
      otpCode,
    }: {
      visitorId: bigint;
      otpCode: string;
    }) => {
      if (!actor) throw new Error("No actor");
      await actor.approveVisitor(visitorId, otpCode);
    },
    onMutate: ({ visitorId }) => setActiveId(visitorId),
    onSettled: () => {
      setActiveId(null);
      void queryClient.invalidateQueries({ queryKey: ["visitors"] });
    },
  });

  const rejectMutation = useMutation({
    mutationFn: async (visitorId: bigint) => {
      if (!actor) throw new Error("No actor");
      await actor.rejectVisitor(visitorId);
    },
    onMutate: (visitorId) => setActiveId(visitorId),
    onSettled: () => {
      setActiveId(null);
      void queryClient.invalidateQueries({ queryKey: ["visitors"] });
    },
  });

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (flatNumber.trim()) setSubmittedFlat(flatNumber.trim());
  };

  const pending = (visitors ?? []).filter(
    (v) => v.approvalStatus === ApprovalStatus.pending,
  );
  const history = (visitors ?? []).filter(
    (v) => v.approvalStatus !== ApprovalStatus.pending,
  );

  return (
    <Layout role={role}>
      <PageHeader
        title="Visitor Approvals"
        icon="🔔"
        subtitle="Approve or reject visitors waiting at the gate"
      />

      {/* Flat lookup */}
      <form
        onSubmit={handleSearch}
        className="px-4 py-4 bg-card border-b border-border flex flex-col sm:flex-row gap-3"
        data-ocid="approval.flat_search_form"
      >
        <div className="flex-1">
          <Label htmlFor="flat-search" className="sr-only">
            Your Flat Number
          </Label>
          <Input
            id="flat-search"
            placeholder="Enter your flat number (e.g. A-101)"
            value={flatNumber}
            onChange={(e) => setFlatNumber(e.target.value)}
            className="h-12 text-base"
            data-ocid="approval.flat_search_input"
          />
        </div>
        <Button
          type="submit"
          className="btn-accessible h-12 px-8"
          data-ocid="approval.search_button"
        >
          View My Visitors
        </Button>
      </form>

      <div className="px-4 py-4 flex flex-col gap-4">
        {/* Pending approvals */}
        {submittedFlat && (
          <>
            <h2 className="text-lg font-bold text-foreground flex items-center gap-2">
              <Clock className="w-5 h-5 text-yellow-600" />
              Pending Approval
              {pending.length > 0 && (
                <span className="inline-flex items-center justify-center w-6 h-6 rounded-full bg-yellow-100 text-yellow-800 text-sm font-bold">
                  {pending.length}
                </span>
              )}
            </h2>

            {isLoading ? (
              <div
                className="flex flex-col gap-3"
                data-ocid="approval.loading_state"
              >
                {[1, 2].map((n) => (
                  <Card key={n} className="p-4 flex flex-col gap-3">
                    <Skeleton className="h-6 w-40" />
                    <Skeleton className="h-4 w-56" />
                    <Skeleton className="h-12 w-full" />
                  </Card>
                ))}
              </div>
            ) : pending.length === 0 ? (
              <EmptyState
                icon="✅"
                title="No pending visitors"
                description="No visitors are waiting for your approval right now."
              />
            ) : (
              <div
                className="flex flex-col gap-4"
                data-ocid="approval.pending_list"
              >
                {pending.map((v, i) => (
                  <ApprovalCard
                    key={Number(v.visitorId)}
                    visitor={v}
                    index={i}
                    onApprove={(id, otp) =>
                      approveMutation.mutate({ visitorId: id, otpCode: otp })
                    }
                    onReject={(id) => rejectMutation.mutate(id)}
                    isApproving={approveMutation.isPending}
                    isRejecting={rejectMutation.isPending}
                    activeId={activeId}
                  />
                ))}
              </div>
            )}

            {/* Error state */}
            {(approveMutation.isError || rejectMutation.isError) && (
              <div
                className="rounded-xl bg-destructive/10 border border-destructive/30 p-4 text-destructive text-base font-medium"
                data-ocid="approval.error_state"
                role="alert"
              >
                Action failed. Please check the OTP and try again.
              </div>
            )}

            {/* History */}
            {history.length > 0 && (
              <>
                <h2 className="text-lg font-bold text-foreground mt-2">
                  Recent History
                </h2>
                <div
                  className="flex flex-col gap-2"
                  data-ocid="approval.history_list"
                >
                  {history.slice(0, 10).map((v, i) => (
                    <HistoryRow
                      key={Number(v.visitorId)}
                      visitor={v}
                      index={i}
                    />
                  ))}
                </div>
              </>
            )}
          </>
        )}

        {!submittedFlat && (
          <EmptyState
            icon="🏠"
            title="Enter your flat number"
            description="Type your flat number above to see visitors waiting for approval."
          />
        )}
      </div>
    </Layout>
  );
}
