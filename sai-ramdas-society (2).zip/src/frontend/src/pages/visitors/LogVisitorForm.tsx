import { Layout } from "@/components/Layout";
import { PageHeader } from "@/components/ui/PageHeader";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useRole } from "@/hooks/use-role";
import { useActor } from "@/lib/backend-client";
import type { AppRole } from "@/types";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useNavigate } from "@tanstack/react-router";
import { ArrowLeft, CheckCircle } from "lucide-react";
import { useState } from "react";

interface FormData {
  name: string;
  mobile: string;
  flatVisiting: string;
  purpose: string;
}

const PURPOSE_OPTIONS = [
  "Guest Visit",
  "Delivery",
  "Maintenance / Repair",
  "Domestic Help",
  "Cab / Auto Driver",
  "Food Delivery",
  "Courier",
  "Medical Visit",
  "Other",
];

function FieldError({ msg }: { msg?: string }) {
  if (!msg) return null;
  return (
    <p
      className="text-destructive text-sm mt-1 font-medium"
      role="alert"
      data-ocid="log_visitor.field_error"
    >
      {msg}
    </p>
  );
}

export default function LogVisitorForm() {
  const { getRole } = useRole();
  const role = (getRole() ?? "security") as AppRole;
  const navigate = useNavigate();
  const { actor, isFetching } = useActor();
  const queryClient = useQueryClient();

  const [form, setForm] = useState<FormData>({
    name: "",
    mobile: "",
    flatVisiting: "",
    purpose: "",
  });
  const [errors, setErrors] = useState<Partial<FormData>>({});
  const [otpResult, setOtpResult] = useState<{
    visitorId: bigint;
    otp: string;
  } | null>(null);

  const set = (field: keyof FormData, val: string) => {
    setForm((prev) => ({ ...prev, [field]: val }));
    if (errors[field]) setErrors((prev) => ({ ...prev, [field]: undefined }));
  };

  const validate = (): boolean => {
    const errs: Partial<FormData> = {};
    if (!form.name.trim()) errs.name = "Visitor name is required";
    if (!/^[6-9]\d{9}$/.test(form.mobile))
      errs.mobile = "Enter a valid 10-digit mobile number";
    if (!form.flatVisiting.trim())
      errs.flatVisiting = "Flat number is required";
    if (!form.purpose) errs.purpose = "Please select a purpose";
    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const logMutation = useMutation({
    mutationFn: async (data: FormData) => {
      if (!actor) throw new Error("No actor");
      const result = await actor.logVisitorEntry(
        data.name.trim(),
        data.mobile.trim(),
        data.flatVisiting.trim().toUpperCase(),
        data.purpose,
      );
      return { visitorId: result[0], otp: result[1] };
    },
    onSuccess: (data) => {
      setOtpResult(data);
      void queryClient.invalidateQueries({ queryKey: ["visitors"] });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;
    logMutation.mutate(form);
  };

  const handleNewEntry = () => {
    setForm({ name: "", mobile: "", flatVisiting: "", purpose: "" });
    setErrors({});
    setOtpResult(null);
    logMutation.reset();
  };

  // Success screen
  if (otpResult) {
    return (
      <Layout role={role}>
        <PageHeader
          title="Visitor Logged"
          icon="✅"
          subtitle="Entry recorded successfully"
        />
        <div className="px-4 py-8 flex flex-col items-center gap-6 max-w-lg mx-auto">
          <div
            className="w-20 h-20 rounded-full bg-green-100 flex items-center justify-center"
            data-ocid="log_visitor.success_state"
          >
            <CheckCircle className="w-10 h-10 text-green-700" />
          </div>
          <div className="text-center">
            <h2 className="text-2xl font-bold font-display text-foreground">
              Entry Logged!
            </h2>
            <p className="text-muted-foreground text-base mt-2">
              Share this OTP with the visitor to give to the resident for
              approval.
            </p>
          </div>

          <Card className="w-full border-2 border-primary/30 bg-primary/5 p-6 text-center shadow-card">
            <p className="text-sm font-medium text-muted-foreground mb-2">
              OTP CODE — Share with Visitor
            </p>
            <p
              className="text-5xl font-mono font-bold text-primary tracking-widest"
              data-ocid="log_visitor.otp_display"
            >
              {otpResult.otp}
            </p>
            <p className="text-sm text-muted-foreground mt-3">
              Visitor ID: #{String(otpResult.visitorId)}
            </p>
          </Card>

          <div className="flex flex-col sm:flex-row gap-3 w-full">
            <Button
              onClick={handleNewEntry}
              className="btn-accessible flex-1"
              data-ocid="log_visitor.new_entry_button"
            >
              Log Another Visitor
            </Button>
            <Button
              variant="outline"
              onClick={() => void navigate({ to: "/visitors" })}
              className="btn-accessible flex-1"
              data-ocid="log_visitor.back_to_list_button"
            >
              Back to Visitor Log
            </Button>
          </div>
        </div>
      </Layout>
    );
  }

  return (
    <Layout role={role}>
      <PageHeader
        title="Log Visitor Entry"
        icon="🚪"
        subtitle="Record a new visitor at the gate"
        actions={
          <Button
            variant="ghost"
            className="btn-accessible gap-2"
            onClick={() => void navigate({ to: "/visitors" })}
            data-ocid="log_visitor.back_button"
          >
            <ArrowLeft className="w-5 h-5" />
            Back
          </Button>
        }
      />

      <form
        onSubmit={handleSubmit}
        className="px-4 py-6 max-w-lg mx-auto flex flex-col gap-5"
        noValidate
        data-ocid="log_visitor.form"
      >
        {/* Visitor Name */}
        <div className="flex flex-col gap-2">
          <Label htmlFor="visitor-name" className="text-base font-semibold">
            Visitor Name <span className="text-destructive">*</span>
          </Label>
          <Input
            id="visitor-name"
            placeholder="Full name of the visitor"
            value={form.name}
            onChange={(e) => set("name", e.target.value)}
            className="h-12 text-base"
            data-ocid="log_visitor.name_input"
            aria-invalid={!!errors.name}
          />
          <FieldError msg={errors.name} />
        </div>

        {/* Mobile Number */}
        <div className="flex flex-col gap-2">
          <Label htmlFor="visitor-mobile" className="text-base font-semibold">
            Mobile Number <span className="text-destructive">*</span>
          </Label>
          <Input
            id="visitor-mobile"
            type="tel"
            inputMode="numeric"
            placeholder="10-digit mobile number"
            value={form.mobile}
            onChange={(e) => set("mobile", e.target.value)}
            className="h-12 text-base"
            maxLength={10}
            data-ocid="log_visitor.mobile_input"
            aria-invalid={!!errors.mobile}
          />
          <FieldError msg={errors.mobile} />
        </div>

        {/* Flat Visiting */}
        <div className="flex flex-col gap-2">
          <Label htmlFor="flat-number" className="text-base font-semibold">
            Flat Number <span className="text-destructive">*</span>
          </Label>
          <Input
            id="flat-number"
            placeholder="e.g. A-101, B-204"
            value={form.flatVisiting}
            onChange={(e) => set("flatVisiting", e.target.value)}
            className="h-12 text-base"
            data-ocid="log_visitor.flat_input"
            aria-invalid={!!errors.flatVisiting}
          />
          <FieldError msg={errors.flatVisiting} />
        </div>

        {/* Purpose */}
        <div className="flex flex-col gap-2">
          <Label htmlFor="purpose" className="text-base font-semibold">
            Purpose of Visit <span className="text-destructive">*</span>
          </Label>
          <Select
            value={form.purpose}
            onValueChange={(val) => set("purpose", val)}
          >
            <SelectTrigger
              id="purpose"
              className="h-12 text-base"
              data-ocid="log_visitor.purpose_select"
              aria-invalid={!!errors.purpose}
            >
              <SelectValue placeholder="Select purpose..." />
            </SelectTrigger>
            <SelectContent>
              {PURPOSE_OPTIONS.map((opt) => (
                <SelectItem key={opt} value={opt} className="text-base py-3">
                  {opt}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <FieldError msg={errors.purpose} />
        </div>

        {/* Error state */}
        {logMutation.isError && (
          <div
            className="rounded-xl bg-destructive/10 border border-destructive/30 p-4 text-destructive text-base font-medium"
            data-ocid="log_visitor.error_state"
            role="alert"
          >
            Failed to log visitor. Please try again.
          </div>
        )}

        <Button
          type="submit"
          className="btn-accessible text-base font-semibold h-14 text-lg mt-2"
          disabled={logMutation.isPending || isFetching}
          data-ocid="log_visitor.submit_button"
        >
          {logMutation.isPending ? "Logging Entry..." : "Log Visitor & Get OTP"}
        </Button>
      </form>
    </Layout>
  );
}
