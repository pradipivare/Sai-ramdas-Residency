import { Layout } from "@/components/Layout";
import { EmptyState } from "@/components/ui/EmptyState";
import { PageHeader } from "@/components/ui/PageHeader";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { useRole } from "@/hooks/use-role";
import { useActor } from "@/lib/backend-client";
import { cn } from "@/lib/utils";
import type { AppRole, Visitor } from "@/types";
import { ApprovalStatus } from "@/types";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useNavigate } from "@tanstack/react-router";
import { LogOut, Plus, Search, UserCheck } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

function formatDateTime(ts: bigint): string {
  const d = new Date(Number(ts) / 1_000_000);
  return d.toLocaleString("en-IN", {
    day: "numeric",
    month: "short",
    hour: "2-digit",
    minute: "2-digit",
  });
}

const STATUS_CONFIG: Record<
  ApprovalStatus,
  { label: string; className: string }
> = {
  [ApprovalStatus.pending]: {
    label: "Pending",
    className: "bg-yellow-700/20 text-yellow-300 border-yellow-700/30",
  },
  [ApprovalStatus.approved]: {
    label: "Approved",
    className: "bg-green-700/20 text-green-300 border-green-700/30",
  },
  [ApprovalStatus.rejected]: {
    label: "Rejected",
    className: "bg-red-700/20 text-red-300 border-red-700/30",
  },
};

// ─── Compact Visitor Row ──────────────────────────────────────────────────────

function VisitorRow({
  visitor,
  index,
  onLogExit,
  isExiting,
  role,
}: {
  visitor: Visitor;
  index: number;
  onLogExit: (id: bigint) => void;
  isExiting: boolean;
  role: AppRole;
}) {
  const status = visitor.approvalStatus;
  const cfg = STATUS_CONFIG[status];

  return (
    <div
      className="flex items-center gap-3 px-3 py-2.5 border-b border-border last:border-0"
      data-ocid={`visitor_log.item.${index}`}
    >
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2 flex-wrap">
          <span className="font-semibold text-base text-foreground truncate">
            {visitor.name}
          </span>
        </div>
        <p className="text-sm text-muted-foreground">
          Flat {visitor.flatVisiting} • {formatDateTime(visitor.entryTime)}
        </p>
      </div>

      <div className="flex items-center gap-2 flex-shrink-0">
        <Badge
          variant="outline"
          className={cn(
            "text-xs font-semibold px-2 py-0.5 border",
            cfg.className,
          )}
        >
          {cfg.label}
        </Badge>
        {visitor.exitTime ? (
          <span className="text-xs text-muted-foreground">Exited</span>
        ) : (
          role === "security" &&
          status === ApprovalStatus.approved && (
            <Button
              size="sm"
              variant="outline"
              className="h-8 text-xs gap-1 px-2"
              onClick={() => onLogExit(visitor.visitorId)}
              disabled={isExiting}
              data-ocid={`visitor_log.exit_button.${index}`}
            >
              <LogOut className="w-3.5 h-3.5" />
              Exit
            </Button>
          )
        )}
        {visitor.approvalStatus === ApprovalStatus.pending &&
          role === "security" && (
            <span className="text-xs font-mono font-bold text-primary bg-primary/10 px-2 py-0.5 rounded">
              {visitor.otpCode}
            </span>
          )}
      </div>
    </div>
  );
}

// ─── Main Page ────────────────────────────────────────────────────────────────

export default function VisitorsPage() {
  const { getRole } = useRole();
  const role = (getRole() ?? "security") as AppRole;
  const navigate = useNavigate();
  const { actor, isFetching } = useActor();
  const queryClient = useQueryClient();
  const [search, setSearch] = useState("");
  const [filterFlat, setFilterFlat] = useState("");

  const isAdmin = role === "admin" || role === "committee";

  const { data: visitors, isLoading } = useQuery<Visitor[]>({
    queryKey: ["visitors", "today"],
    queryFn: async () => {
      if (!actor) return [];
      return actor.getTodayVisitors();
    },
    enabled: !!actor && !isFetching,
    refetchInterval: 30_000,
  });

  const { data: flatVisitors, isLoading: isFlatLoading } = useQuery<Visitor[]>({
    queryKey: ["visitors", "flat", filterFlat],
    queryFn: async () => {
      if (!actor || !filterFlat.trim()) return [];
      return actor.getVisitorsByFlat(filterFlat.trim());
    },
    enabled: !!actor && !isFetching && filterFlat.trim().length > 0,
  });

  const exitMutation = useMutation({
    mutationFn: async (visitorId: bigint) => {
      if (!actor) throw new Error("No actor");
      await actor.logVisitorExit(visitorId);
    },
    onSuccess: () => {
      void queryClient.invalidateQueries({ queryKey: ["visitors"] });
      toast.success("Visitor exit recorded", { duration: 4000 });
    },
    onError: () =>
      toast.error("Failed to record exit. Please try again.", {
        duration: 4000,
      }),
  });

  const displayList: Visitor[] =
    filterFlat.trim() && isAdmin ? (flatVisitors ?? []) : (visitors ?? []);

  const filtered = displayList.filter((v) => {
    const q = search.toLowerCase();
    return (
      v.name.toLowerCase().includes(q) ||
      v.flatVisiting.toLowerCase().includes(q) ||
      v.mobile.includes(q)
    );
  });

  const loading = isLoading || (filterFlat.trim() ? isFlatLoading : false);

  const pendingCount = filtered.filter(
    (v) => v.approvalStatus === ApprovalStatus.pending,
  ).length;

  return (
    <Layout role={role}>
      <PageHeader
        title="Visitor Log"
        icon="🚪"
        subtitle={isAdmin ? "All visitor records" : "Today's visitor log"}
        actions={
          role === "security" ? (
            <Button
              className="btn-accessible gap-2"
              onClick={() => void navigate({ to: "/visitors/log" })}
              data-ocid="visitors.log_entry_button"
            >
              <Plus className="w-5 h-5" />
              Log Entry
            </Button>
          ) : undefined
        }
      />

      {/* Summary row */}
      <div className="px-4 py-2 flex gap-2 flex-wrap bg-muted/20 border-b border-border text-sm">
        <span className="font-semibold text-foreground">
          Total: {filtered.length}
        </span>
        {pendingCount > 0 && (
          <span className="font-semibold text-amber-700">
            • Pending: {pendingCount}
          </span>
        )}
      </div>

      {/* Filters */}
      <div className="px-4 py-2 flex flex-col sm:flex-row gap-2 bg-card border-b border-border">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="Name, flat, mobile..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-9 h-10 text-base"
            data-ocid="visitors.search_input"
          />
        </div>
        {isAdmin && (
          <Input
            placeholder="Filter by flat (e.g. A-101)"
            value={filterFlat}
            onChange={(e) => setFilterFlat(e.target.value)}
            className="h-10 text-base sm:w-48"
            data-ocid="visitors.flat_filter_input"
          />
        )}
        {role === "security" && (
          <Button
            variant="outline"
            className="btn-accessible gap-2 h-10"
            onClick={() => void navigate({ to: "/visitors/pre-approved" })}
            data-ocid="visitors.pre_approved_link"
          >
            <UserCheck className="w-4 h-4" />
            Pre-Approved
          </Button>
        )}
      </div>

      {/* Visitor list */}
      <div className="px-4 py-3">
        {loading ? (
          <div className="space-y-1">
            {[1, 2, 3, 4].map((n) => (
              <Skeleton key={n} className="h-14 rounded-lg" />
            ))}
          </div>
        ) : filtered.length === 0 ? (
          <EmptyState
            icon="🚶"
            title="No visitors found"
            description={
              search ? "Try a different search." : "No entries logged today."
            }
            data-ocid="visitors.empty_state"
          />
        ) : (
          <div className="border border-border rounded-xl overflow-hidden bg-card">
            {filtered.map((v, i) => (
              <VisitorRow
                key={Number(v.visitorId)}
                visitor={v}
                index={i + 1}
                role={role}
                onLogExit={(id) => exitMutation.mutate(id)}
                isExiting={exitMutation.isPending}
              />
            ))}
          </div>
        )}
      </div>
    </Layout>
  );
}
