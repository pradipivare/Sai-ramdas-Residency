import { Layout } from "@/components/Layout";
import { EmptyState } from "@/components/ui/EmptyState";
import { PageHeader } from "@/components/ui/PageHeader";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import { useRole } from "@/hooks/use-role";
import { useActor } from "@/lib/backend-client";
import type { AppRole, PreApprovedGuest } from "@/types";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Phone, Plus, Trash2, UserCheck } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

interface AddGuestForm {
  flatNumber: string;
  name: string;
  mobile: string;
  relationship: string;
}

const RELATIONSHIP_OPTIONS = [
  "Family Member",
  "Parent",
  "Sibling",
  "Child",
  "Friend",
  "Regular Maid",
  "Driver",
  "Nurse / Caregiver",
  "Other",
];

function GuestCard({
  guest,
  index,
  onRemove,
  isRemoving,
  isAdmin,
}: {
  guest: PreApprovedGuest;
  index: number;
  onRemove: (id: bigint) => void;
  isRemoving: boolean;
  isAdmin: boolean;
}) {
  const [confirmOpen, setConfirmOpen] = useState(false);
  return (
    <>
      <Card
        className="border border-border shadow-card p-4"
        data-ocid={`pre_approved.item.${index + 1}`}
      >
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center text-2xl flex-shrink-0">
            👤
          </div>
          <div className="flex-1 min-w-0">
            <p className="font-bold text-foreground text-lg">{guest.name}</p>
            <p className="text-base text-muted-foreground truncate">
              Flat:{" "}
              <span className="font-medium text-foreground">
                {guest.flatNumber}
              </span>
              {" · "}
              {guest.relationship}
            </p>
            <div className="flex items-center gap-1 mt-0.5 text-sm text-muted-foreground">
              <Phone className="w-4 h-4" />
              <span>{guest.mobile}</span>
            </div>
          </div>
          {isAdmin && (
            <Button
              variant="ghost"
              size="sm"
              className="text-destructive hover:text-destructive hover:bg-destructive/10 touch-target"
              onClick={() => setConfirmOpen(true)}
              data-ocid={`pre_approved.delete_button.${index + 1}`}
              aria-label={`Remove ${guest.name} from pre-approved list`}
            >
              <Trash2 className="w-5 h-5" />
            </Button>
          )}
        </div>
      </Card>

      {isAdmin && (
        <Dialog open={confirmOpen} onOpenChange={setConfirmOpen}>
          <DialogContent data-ocid="pre_approved.dialog">
            <DialogHeader>
              <DialogTitle className="text-xl">
                Remove Pre-Approved Guest?
              </DialogTitle>
            </DialogHeader>
            <p className="text-base text-muted-foreground">
              <span className="font-semibold text-foreground">
                {guest.name}
              </span>{" "}
              will no longer have automatic gate entry. They will need OTP
              approval next time.
            </p>
            <DialogFooter className="flex flex-col sm:flex-row gap-3 mt-2">
              <Button
                variant="outline"
                onClick={() => setConfirmOpen(false)}
                className="btn-accessible flex-1"
                data-ocid="pre_approved.cancel_button"
              >
                Cancel
              </Button>
              <Button
                variant="destructive"
                className="btn-accessible flex-1"
                disabled={isRemoving}
                onClick={() => {
                  onRemove(guest.guestId);
                  setConfirmOpen(false);
                }}
                data-ocid="pre_approved.confirm_button"
              >
                {isRemoving ? "Removing..." : "Yes, Remove"}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
    </>
  );
}

export default function PreApprovedGuestsPage() {
  const { getRole } = useRole();
  const role = (getRole() ?? "security") as AppRole;
  const { actor, isFetching } = useActor();
  const queryClient = useQueryClient();

  const isAdmin = role === "admin";

  const [flatSearch, setFlatSearch] = useState("");
  const [submittedFlat, setSubmittedFlat] = useState("");
  const [addOpen, setAddOpen] = useState(false);
  const [addForm, setAddForm] = useState<AddGuestForm>({
    flatNumber: "",
    name: "",
    mobile: "",
    relationship: "",
  });
  const [addErrors, setAddErrors] = useState<Partial<AddGuestForm>>({});

  const { data: guests, isLoading } = useQuery<PreApprovedGuest[]>({
    queryKey: ["pre-approved", submittedFlat],
    queryFn: async () => {
      if (!actor || !submittedFlat.trim()) return [];
      return actor.getPreApprovedGuests(submittedFlat.trim().toUpperCase());
    },
    enabled: !!actor && !isFetching && submittedFlat.trim().length > 0,
  });

  const addMutation = useMutation({
    mutationFn: async (form: AddGuestForm) => {
      if (!actor) throw new Error("No actor");
      await actor.addPreApprovedGuest(
        form.flatNumber.trim().toUpperCase(),
        form.name.trim(),
        form.mobile.trim(),
        form.relationship,
      );
    },
    onSuccess: () => {
      void queryClient.invalidateQueries({ queryKey: ["pre-approved"] });
      setAddOpen(false);
      setAddForm({ flatNumber: "", name: "", mobile: "", relationship: "" });
      toast.success("Guest added to pre-approved list!", { duration: 4000 });
    },
    onError: () =>
      toast.error("Failed to add guest. Please try again.", { duration: 4000 }),
  });

  const removeMutation = useMutation({
    mutationFn: async (guestId: bigint) => {
      if (!actor) throw new Error("No actor");
      await actor.removePreApprovedGuest(guestId);
    },
    onSuccess: () => {
      void queryClient.invalidateQueries({ queryKey: ["pre-approved"] });
      toast.info("Guest removed from pre-approved list", { duration: 4000 });
    },
    onError: () =>
      toast.error("Failed to remove guest. Please try again.", {
        duration: 4000,
      }),
  });

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (flatSearch.trim()) setSubmittedFlat(flatSearch.trim());
  };

  const setAddField = (field: keyof AddGuestForm, val: string) => {
    setAddForm((prev) => ({ ...prev, [field]: val }));
    if (addErrors[field])
      setAddErrors((prev) => ({ ...prev, [field]: undefined }));
  };

  const validateAdd = (): boolean => {
    const errs: Partial<AddGuestForm> = {};
    if (!addForm.flatNumber.trim()) errs.flatNumber = "Flat number is required";
    if (!addForm.name.trim()) errs.name = "Name is required";
    if (!/^[6-9]\d{9}$/.test(addForm.mobile))
      errs.mobile = "Enter a valid 10-digit mobile number";
    if (!addForm.relationship)
      errs.relationship = "Please select a relationship";
    setAddErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validateAdd()) return;
    addMutation.mutate(addForm);
  };

  return (
    <Layout role={role}>
      <PageHeader
        title="Pre-Approved Guests"
        icon="✅"
        subtitle="Guests who can enter without OTP approval"
        actions={
          isAdmin ? (
            <Button
              className="btn-accessible gap-2"
              onClick={() => setAddOpen(true)}
              data-ocid="pre_approved.add_button"
            >
              <Plus className="w-5 h-5" />
              Add Guest
            </Button>
          ) : undefined
        }
      />

      {/* Info banner for security */}
      {role === "security" && (
        <div className="mx-4 mt-4 rounded-xl bg-primary/10 border border-primary/20 px-4 py-3 flex items-center gap-3">
          <UserCheck className="w-6 h-6 text-primary flex-shrink-0" />
          <p className="text-base font-medium text-foreground">
            These guests can enter without OTP. Check this list before asking
            for OTP.
          </p>
        </div>
      )}

      {/* Flat search */}
      <form
        onSubmit={handleSearch}
        className="px-4 py-4 bg-card border-b border-border mt-4 flex flex-col sm:flex-row gap-3"
        data-ocid="pre_approved.search_form"
      >
        <div className="flex-1">
          <Label htmlFor="flat-search-pa" className="sr-only">
            Flat Number
          </Label>
          <Input
            id="flat-search-pa"
            placeholder="Enter flat number (e.g. A-101)"
            value={flatSearch}
            onChange={(e) => setFlatSearch(e.target.value)}
            className="h-12 text-base"
            data-ocid="pre_approved.flat_search_input"
          />
        </div>
        <Button
          type="submit"
          className="btn-accessible h-12 px-8"
          data-ocid="pre_approved.search_button"
        >
          View Guests
        </Button>
      </form>

      {/* Guest list */}
      <div className="px-4 py-4 flex flex-col gap-3">
        {submittedFlat && (
          <>
            <p className="text-sm text-muted-foreground font-medium">
              Pre-approved guests for flat{" "}
              <span className="font-bold text-foreground">
                {submittedFlat.toUpperCase()}
              </span>
            </p>
            {isLoading ? (
              <div
                className="flex flex-col gap-3"
                data-ocid="pre_approved.loading_state"
              >
                {[1, 2, 3].map((n) => (
                  <Card key={n} className="p-4 flex items-center gap-3">
                    <Skeleton className="w-12 h-12 rounded-full" />
                    <div className="flex flex-col gap-2 flex-1">
                      <Skeleton className="h-5 w-32" />
                      <Skeleton className="h-4 w-48" />
                    </div>
                  </Card>
                ))}
              </div>
            ) : !guests || guests.length === 0 ? (
              <EmptyState
                icon="👤"
                title="No pre-approved guests"
                description="No guests have been added to the pre-approved list for this flat."
                action={
                  isAdmin
                    ? { label: "Add a Guest", onClick: () => setAddOpen(true) }
                    : undefined
                }
              />
            ) : (
              guests.map((g, i) => (
                <GuestCard
                  key={Number(g.guestId)}
                  guest={g}
                  index={i}
                  onRemove={(id) => removeMutation.mutate(id)}
                  isRemoving={removeMutation.isPending}
                  isAdmin={isAdmin}
                />
              ))
            )}
          </>
        )}

        {!submittedFlat && (
          <EmptyState
            icon="🔍"
            title="Search by flat number"
            description="Enter a flat number above to view or manage pre-approved guests."
          />
        )}
      </div>

      {/* Add Guest Dialog — admin only */}
      {isAdmin && (
        <Dialog open={addOpen} onOpenChange={setAddOpen}>
          <DialogContent
            className="max-w-md w-full"
            data-ocid="pre_approved.dialog"
          >
            <DialogHeader>
              <DialogTitle className="text-xl font-bold">
                Add Pre-Approved Guest
              </DialogTitle>
            </DialogHeader>

            <form
              onSubmit={handleAdd}
              className="flex flex-col gap-4 mt-2"
              noValidate
            >
              {/* Flat Number */}
              <div className="flex flex-col gap-2">
                <Label htmlFor="add-flat" className="text-base font-semibold">
                  Flat Number <span className="text-destructive">*</span>
                </Label>
                <Input
                  id="add-flat"
                  placeholder="e.g. A-101"
                  value={addForm.flatNumber}
                  onChange={(e) => setAddField("flatNumber", e.target.value)}
                  className="h-12 text-base"
                  data-ocid="pre_approved.flat_input"
                />
                {addErrors.flatNumber && (
                  <p
                    className="text-destructive text-sm font-medium"
                    role="alert"
                  >
                    {addErrors.flatNumber}
                  </p>
                )}
              </div>

              {/* Guest Name */}
              <div className="flex flex-col gap-2">
                <Label htmlFor="add-name" className="text-base font-semibold">
                  Guest Name <span className="text-destructive">*</span>
                </Label>
                <Input
                  id="add-name"
                  placeholder="Full name"
                  value={addForm.name}
                  onChange={(e) => setAddField("name", e.target.value)}
                  className="h-12 text-base"
                  data-ocid="pre_approved.name_input"
                />
                {addErrors.name && (
                  <p
                    className="text-destructive text-sm font-medium"
                    role="alert"
                  >
                    {addErrors.name}
                  </p>
                )}
              </div>

              {/* Mobile */}
              <div className="flex flex-col gap-2">
                <Label htmlFor="add-mobile" className="text-base font-semibold">
                  Mobile Number <span className="text-destructive">*</span>
                </Label>
                <Input
                  id="add-mobile"
                  type="tel"
                  inputMode="numeric"
                  placeholder="10-digit mobile number"
                  value={addForm.mobile}
                  onChange={(e) => setAddField("mobile", e.target.value)}
                  className="h-12 text-base"
                  maxLength={10}
                  data-ocid="pre_approved.mobile_input"
                />
                {addErrors.mobile && (
                  <p
                    className="text-destructive text-sm font-medium"
                    role="alert"
                  >
                    {addErrors.mobile}
                  </p>
                )}
              </div>

              {/* Relationship */}
              <div className="flex flex-col gap-2">
                <Label
                  htmlFor="add-relationship"
                  className="text-base font-semibold"
                >
                  Relationship <span className="text-destructive">*</span>
                </Label>
                <select
                  id="add-relationship"
                  value={addForm.relationship}
                  onChange={(e) => setAddField("relationship", e.target.value)}
                  className="h-12 text-base border border-input rounded-lg px-3 bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-ring"
                  data-ocid="pre_approved.relationship_select"
                >
                  <option value="">Select relationship...</option>
                  {RELATIONSHIP_OPTIONS.map((opt) => (
                    <option key={opt} value={opt}>
                      {opt}
                    </option>
                  ))}
                </select>
                {addErrors.relationship && (
                  <p
                    className="text-destructive text-sm font-medium"
                    role="alert"
                  >
                    {addErrors.relationship}
                  </p>
                )}
              </div>

              {addMutation.isError && (
                <div
                  className="rounded-xl bg-destructive/10 border border-destructive/30 p-3 text-destructive text-sm font-medium"
                  data-ocid="pre_approved.error_state"
                  role="alert"
                >
                  Failed to add guest. Please try again.
                </div>
              )}

              <DialogFooter className="flex flex-col sm:flex-row gap-3 mt-2">
                <Button
                  type="button"
                  variant="outline"
                  className="btn-accessible flex-1"
                  onClick={() => setAddOpen(false)}
                  data-ocid="pre_approved.cancel_button"
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  className="btn-accessible flex-1"
                  disabled={addMutation.isPending}
                  data-ocid="pre_approved.submit_button"
                >
                  {addMutation.isPending ? "Adding..." : "Add Guest"}
                </Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      )}
    </Layout>
  );
}
