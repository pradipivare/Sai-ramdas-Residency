import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { BookOpen, Search } from "lucide-react";
import { AnimatePresence, motion } from "motion/react";
import { useMemo, useState } from "react";
import { Layout } from "../../components/Layout";
import { EmptyState } from "../../components/ui/EmptyState";
import { PageHeader } from "../../components/ui/PageHeader";
import { useRole } from "../../hooks/use-role";
import { useSocietyRules } from "../../hooks/useQueries";
import type { AppRole, SocietyRule } from "../../types";

// ─── Category Config ───────────────────────────────────────────────────────────

type CategoryKey = "all" | "financial" | "security" | "maintenance" | "conduct";

interface CategoryConfig {
  key: CategoryKey;
  label: string;
  color: string;
}

const CATEGORIES: CategoryConfig[] = [
  {
    key: "all",
    label: "All",
    color: "bg-primary text-primary-foreground",
  },
  {
    key: "financial",
    label: "Financial",
    color: "bg-accent text-accent-foreground",
  },
  {
    key: "security",
    label: "Security",
    color: "bg-destructive text-destructive-foreground",
  },
  {
    key: "maintenance",
    label: "Maintenance",
    color: "bg-secondary text-secondary-foreground",
  },
  {
    key: "conduct",
    label: "Conduct",
    color: "bg-muted text-foreground",
  },
];

function getCategoryConfig(category: string): CategoryConfig {
  const lower = category.toLowerCase();
  return (
    CATEGORIES.find((c) => c.key !== "all" && lower.includes(c.key)) ??
    CATEGORIES[0]
  );
}

// ─── Rule Card ────────────────────────────────────────────────────────────────

interface RuleCardProps {
  rule: SocietyRule;
  index: number;
  delay: number;
}

function RuleCard({ rule, index, delay }: RuleCardProps) {
  const [expanded, setExpanded] = useState(false);
  const catConfig = getCategoryConfig(rule.category);

  const desc = rule.descriptionEnglish || rule.descriptionMarathi;
  const isLong = desc.length > 200;
  const needsTruncation = isLong && !expanded;

  return (
    <motion.article
      data-ocid={`rules.item.${index}`}
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -10 }}
      transition={{ duration: 0.3, delay, ease: "easeOut" }}
      className="rounded-2xl border-2 border-border bg-card shadow-card p-5 transition-smooth hover:shadow-md"
    >
      {/* Rule number + category badge */}
      <div className="flex flex-wrap items-center gap-2 mb-3">
        <span className="flex items-center justify-center w-9 h-9 rounded-full bg-primary/10 text-primary font-bold font-display text-base flex-shrink-0">
          {String(rule.orderNumber)}
        </span>
        <Badge className={`${catConfig.color} text-sm px-3 py-1 font-semibold`}>
          {catConfig.label}
        </Badge>
        {rule.tags.map((tag) => (
          <Badge key={tag} variant="outline" className="text-sm px-2 py-0.5">
            {tag}
          </Badge>
        ))}
      </div>

      {/* Title — English primary */}
      <h2 className="font-display font-bold text-xl leading-snug text-foreground mb-3">
        {rule.titleEnglish || rule.titleMarathi}
      </h2>

      {/* Description */}
      <div
        className={`text-base leading-relaxed text-foreground ${
          needsTruncation ? "line-clamp-4" : ""
        }`}
      >
        <p className="whitespace-pre-wrap break-words">{desc}</p>
      </div>

      {/* Expand/Collapse */}
      {isLong && (
        <button
          type="button"
          onClick={() => setExpanded((prev) => !prev)}
          data-ocid={`rules.expand_button.${index}`}
          className="mt-3 text-primary font-medium text-base underline underline-offset-2 hover:text-primary/80 transition-smooth focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring rounded"
          aria-expanded={expanded}
        >
          {expanded ? "Show Less ↑" : "Read More ↓"}
        </button>
      )}
    </motion.article>
  );
}

// ─── Loading Skeleton ──────────────────────────────────────────────────────────

function RulesLoadingSkeleton() {
  return (
    <div className="flex flex-col gap-4" data-ocid="rules.loading_state">
      {[1, 2, 3, 4].map((i) => (
        <div
          key={i}
          className="rounded-2xl border-2 border-border bg-card p-5 shadow-card"
        >
          <div className="flex gap-2 mb-3">
            <Skeleton className="h-9 w-9 rounded-full" />
            <Skeleton className="h-7 w-28 rounded-full" />
          </div>
          <Skeleton className="h-7 w-2/3 mb-3" />
          <Skeleton className="h-5 w-full mb-1" />
          <Skeleton className="h-5 w-5/6 mb-1" />
          <Skeleton className="h-5 w-4/6" />
        </div>
      ))}
    </div>
  );
}

// ─── Main Page ────────────────────────────────────────────────────────────────

export default function SocietyRulesPage() {
  const { getRole } = useRole();
  const role = getRole() as AppRole | null;

  const { data: rules, isLoading, error } = useSocietyRules();

  const [search, setSearch] = useState("");
  const [activeCategory, setActiveCategory] = useState<CategoryKey>("all");

  // Filter by category + search
  const filteredRules = useMemo(() => {
    if (!rules) return [];

    let result: SocietyRule[] = [...rules];

    // Category filter
    if (activeCategory !== "all") {
      result = result.filter((r) =>
        r.category.toLowerCase().includes(activeCategory),
      );
    }

    // Search filter (English or Marathi title/description)
    if (search.trim()) {
      const q = search.trim().toLowerCase();
      result = result.filter(
        (r) =>
          r.titleEnglish.toLowerCase().includes(q) ||
          r.titleMarathi.toLowerCase().includes(q) ||
          r.descriptionEnglish.toLowerCase().includes(q) ||
          r.descriptionMarathi.toLowerCase().includes(q) ||
          r.tags.some((t) => t.toLowerCase().includes(q)),
      );
    }

    // Sort by orderNumber
    return result.sort((a, b) => Number(a.orderNumber - b.orderNumber));
  }, [rules, activeCategory, search]);

  if (!role) return null;

  return (
    <Layout role={role}>
      {/* Page Header */}
      <PageHeader
        title="Society Rules"
        subtitle="All Rules & Regulations"
        icon="📜"
      />

      <div className="max-w-2xl mx-auto px-4 py-6 space-y-5">
        {/* Search Bar */}
        <div className="relative" data-ocid="rules.search_input">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground pointer-events-none" />
          <Input
            type="search"
            placeholder="Search rules…"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-10 h-12 text-lg border-2 border-input focus:border-primary rounded-xl"
            aria-label="Search rules"
          />
        </div>

        {/* Category Filter Tabs */}
        <div
          className="flex flex-wrap gap-2"
          role="tablist"
          aria-label="Filter by category"
          data-ocid="rules.category_tabs"
        >
          {CATEGORIES.map((cat) => (
            <button
              key={cat.key}
              type="button"
              role="tab"
              aria-selected={activeCategory === cat.key}
              onClick={() => setActiveCategory(cat.key)}
              data-ocid={`rules.filter.${cat.key}`}
              className={`px-4 py-2 rounded-xl text-base font-semibold border-2 transition-smooth focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring min-h-[44px] ${
                activeCategory === cat.key
                  ? "border-primary bg-primary text-primary-foreground shadow-card"
                  : "border-border bg-card text-foreground hover:bg-muted"
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>

        {/* Rules count indicator */}
        {!isLoading && !error && rules && rules.length > 0 && (
          <p className="text-base text-muted-foreground font-medium">
            {filteredRules.length === rules.length
              ? `Total ${rules.length} rules`
              : `Showing ${filteredRules.length} of ${rules.length} rules`}
          </p>
        )}

        {/* Loading State */}
        {isLoading && <RulesLoadingSkeleton />}

        {/* Error State */}
        {error && (
          <div
            data-ocid="rules.error_state"
            className="rounded-2xl border-2 border-destructive bg-destructive/5 p-6 text-center"
          >
            <BookOpen className="w-10 h-10 text-destructive mx-auto mb-3" />
            <p className="text-destructive font-semibold text-lg">
              Failed to load rules. Please refresh the page.
            </p>
          </div>
        )}

        {/* Empty State — no rules at all */}
        {!isLoading && !error && rules && rules.length === 0 && (
          <EmptyState
            icon="📜"
            title="No rules available"
            description="Society rules will be added soon."
          />
        )}

        {/* Empty State — search/filter no results */}
        {!isLoading &&
          !error &&
          rules &&
          rules.length > 0 &&
          filteredRules.length === 0 && (
            <div data-ocid="rules.empty_state">
              <EmptyState
                icon="🔍"
                title="No rules found"
                description={
                  search
                    ? `No rules match "${search}".`
                    : "No rules in the selected category."
                }
                action={{
                  label: "Show All Rules",
                  onClick: () => {
                    setSearch("");
                    setActiveCategory("all");
                  },
                }}
              />
            </div>
          )}

        {/* Rules List */}
        {!isLoading && filteredRules.length > 0 && (
          <AnimatePresence mode="popLayout">
            <div className="flex flex-col gap-4" data-ocid="rules.list">
              {filteredRules.map((rule, i) => (
                <RuleCard
                  key={String(rule.id)}
                  rule={rule}
                  index={i + 1}
                  delay={i * 0.07}
                />
              ))}
            </div>
          </AnimatePresence>
        )}
      </div>
    </Layout>
  );
}
