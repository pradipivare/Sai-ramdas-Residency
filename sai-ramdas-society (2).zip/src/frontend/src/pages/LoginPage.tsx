import { Button } from "@/components/ui/button";
import { useInternetIdentity } from "@caffeineai/core-infrastructure";
import { useNavigate } from "@tanstack/react-router";
import { useEffect } from "react";
import { LoadingSpinner } from "../components/ui/LoadingSpinner";
import { useRole } from "../hooks/use-role";

export default function LoginPage() {
  const { login, isAuthenticated, isInitializing, isLoggingIn } =
    useInternetIdentity();
  const navigate = useNavigate();
  const { getRole } = useRole();

  // Redirect if already authenticated
  useEffect(() => {
    if (isAuthenticated) {
      const role = getRole();
      if (role) {
        void navigate({ to: "/dashboard" });
      } else {
        void navigate({ to: "/role-select" });
      }
    }
  }, [isAuthenticated, getRole, navigate]);

  if (isInitializing) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <LoadingSpinner size="lg" label="Loading your session..." />
      </div>
    );
  }

  return (
    <div
      className="min-h-screen flex flex-col bg-background"
      data-ocid="login.page"
    >
      {/* Header band */}
      <div className="bg-primary px-6 pt-12 pb-16 text-primary-foreground text-center">
        <div className="w-20 h-20 rounded-2xl bg-primary-foreground/20 mx-auto mb-4 flex items-center justify-center text-5xl">
          🏢
        </div>
        <h1 className="font-display text-3xl font-bold mb-2">
          Sai Ramdas Society
        </h1>
        <p className="text-primary-foreground/80 text-lg">
          Resident &amp; Society Management
        </p>
      </div>

      {/* Card */}
      <div className="flex-1 flex items-start justify-center px-4 -mt-8">
        <div className="w-full max-w-sm bg-card rounded-2xl shadow-card border border-border p-8">
          <h2 className="font-display text-2xl font-bold text-foreground mb-2">
            Welcome Back
          </h2>
          <p className="text-muted-foreground text-accessible mb-8">
            Sign in securely using Internet Identity to access your society
            dashboard.
          </p>

          <Button
            onClick={login}
            disabled={isLoggingIn}
            className="w-full btn-accessible text-lg font-semibold"
            data-ocid="login.submit_button"
          >
            {isLoggingIn ? (
              <span className="flex items-center gap-2">
                <span className="inline-block w-4 h-4 border-2 border-current border-t-transparent rounded-full animate-spin" />
                Connecting...
              </span>
            ) : (
              "🔐  Sign In with Internet Identity"
            )}
          </Button>

          <p className="text-center text-sm text-muted-foreground mt-6">
            Internet Identity provides secure, password-free login. No personal
            data is stored.
          </p>
        </div>
      </div>

      {/* Feature highlights */}
      <div className="px-4 py-8 max-w-sm mx-auto w-full">
        {[
          { icon: "💰", text: "View & pay maintenance bills" },
          { icon: "📢", text: "Raise complaints & track status" },
          { icon: "🚪", text: "Manage visitor entries securely" },
          { icon: "📌", text: "Get society notices & alerts" },
        ].map(({ icon, text }) => (
          <div key={text} className="flex items-center gap-3 py-3">
            <div className="w-10 h-10 rounded-xl bg-accent/20 flex items-center justify-center text-xl flex-shrink-0">
              {icon}
            </div>
            <span className="text-accessible text-foreground">{text}</span>
          </div>
        ))}
      </div>

      <footer className="text-center text-sm text-muted-foreground py-4 border-t border-border bg-muted/30">
        © 2026 Sai Ramdas Society. Built with using ai by Pradip Ivare
      </footer>
    </div>
  );
}
