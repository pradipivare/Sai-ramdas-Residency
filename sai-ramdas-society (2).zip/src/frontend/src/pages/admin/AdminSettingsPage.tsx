import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import { useMutation, useQuery } from "@tanstack/react-query";
import { useNavigate } from "@tanstack/react-router";
import {
  AlertTriangle,
  ChevronRight,
  ClipboardList,
  Eye,
  EyeOff,
  KeyRound,
  Lock,
  Settings,
  Users,
} from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { Layout } from "../../components/Layout";
import { RoleGuard } from "../../components/RoleGuard";
import { useRole } from "../../hooks/use-role";
import { useActor } from "../../lib/backend-client";
import type { AppRole } from "../../types";

// ─── PIN hash (SHA-256 hex digest) ──────────────────────────────────────────

async function hashPin(pin: string): Promise<string> {
  const encoded = new TextEncoder().encode(pin);
  const hash = await crypto.subtle.digest("SHA-256", encoded);
  return Array.from(new Uint8Array(hash))
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
}

// ─── Types ───────────────────────────────────────────────────────────────────

interface AdminActionLogEntry {
  id: bigint;
  action: string;
  performedBy: unknown;
  details: string;
  timestamp: bigint;
}

interface ExtendedActor {
  getAdminSetting(key: string): Promise<{
    key: string;
    value: string;
    updatedBy: unknown;
    updatedAt: bigint;
  } | null>;
  setAdminSetting(key: string, value: string): Promise<void>;
  verifyAdminPin(pinHash: string): Promise<boolean>;
  setAdminPin(newPinHash: string): Promise<void>;
  getAdminActionLog(): Promise<AdminActionLogEntry[]>;
}

// ─── PIN Input ───────────────────────────────────────────────────────────────

function PinInput({
  label,
  value,
  onChange,
  ocid,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  ocid: string;
}) {
  const [show, setShow] = useState(false);
  return (
    <div className="space-y-1.5">
      <Label className="text-base font-medium">{label}</Label>
      <div className="relative">
        <Input
          type={show ? "text" : "password"}
          inputMode="numeric"
          maxLength={4}
          value={value}
          onChange={(e) =>
            onChange(e.target.value.replace(/\D/g, "").slice(0, 4))
          }
          placeholder="••••"
          className="text-xl tracking-[0.5em] pr-12 text-center font-mono h-12"
          data-ocid={ocid}
        />
        <button
          type="button"
          className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
          onClick={() => setShow((s) => !s)}
          aria-label={show ? "Hide PIN" : "Show PIN"}
        >
          {show ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
        </button>
      </div>
    </div>
  );
}

// ─── Set PIN Section ─────────────────────────────────────────────────────────

function SetPinSection({
  hasPin,
  onPinChanged,
}: { hasPin: boolean; onPinChanged: () => void }) {
  const { actor } = useActor();
  const extended = actor as unknown as ExtendedActor;
  const [pin, setPin] = useState("");
  const [confirm, setConfirm] = useState("");
  const [currentPin, setCurrentPin] = useState("");
  const [error, setError] = useState("");

  const mutation = useMutation({
    mutationFn: async () => {
      if (!extended) throw new Error("Actor not ready");
      if (pin.length !== 4 || confirm.length !== 4)
        throw new Error("PIN must be 4 digits");
      if (pin !== confirm) throw new Error("PINs do not match");
      if (hasPin) {
        const currentHash = await hashPin(currentPin);
        const valid = await extended.verifyAdminPin(currentHash);
        if (!valid) throw new Error("Current PIN is incorrect");
      }
      const newHash = await hashPin(pin);
      await extended.setAdminPin(newHash);
    },
    onSuccess: () => {
      toast.success("PIN set successfully.");
      setPin("");
      setConfirm("");
      setCurrentPin("");
      setError("");
      onPinChanged();
    },
    onError: (e) => {
      const msg = e instanceof Error ? e.message : "Error setting PIN";
      setError(msg);
    },
  });

  return (
    <div className="space-y-4">
      {hasPin && (
        <PinInput
          label="Current PIN"
          value={currentPin}
          onChange={setCurrentPin}
          ocid="admin_settings.current_pin_input"
        />
      )}
      <PinInput
        label={hasPin ? "New PIN" : "Set New PIN"}
        value={pin}
        onChange={setPin}
        ocid="admin_settings.new_pin_input"
      />
      <PinInput
        label="Confirm PIN"
        value={confirm}
        onChange={setConfirm}
        ocid="admin_settings.confirm_pin_input"
      />
      {error && (
        <p
          className="text-sm text-destructive font-medium"
          data-ocid="admin_settings.pin_error_state"
        >
          {error}
        </p>
      )}
      <Button
        onClick={() => mutation.mutate()}
        disabled={
          mutation.isPending ||
          pin.length !== 4 ||
          confirm.length !== 4 ||
          (hasPin && currentPin.length !== 4)
        }
        className="w-full btn-accessible"
        data-ocid="admin_settings.set_pin_submit_button"
      >
        {mutation.isPending ? (
          <span data-ocid="admin_settings.pin_loading_state">Saving…</span>
        ) : hasPin ? (
          "Change PIN"
        ) : (
          "Set PIN"
        )}
      </Button>
    </div>
  );
}

// ─── Action Log (Always Visible) ─────────────────────────────────────────────

function AdminActionLogSection() {
  const { actor, isFetching } = useActor();
  const extended = actor as unknown as ExtendedActor;

  const { data: logs = [], isLoading } = useQuery({
    queryKey: ["adminActionLog"],
    queryFn: async () => {
      if (!extended) return [];
      return extended.getAdminActionLog();
    },
    enabled: !!actor && !isFetching,
  });

  const formatTs = (ts: bigint) =>
    new Date(Number(ts) / 1_000_000).toLocaleString("en-IN", {
      day: "numeric",
      month: "short",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });

  const formatPrincipal = (p: unknown): string => {
    if (!p) return "—";
    const s = String(p);
    return s.length > 12 ? `${s.slice(0, 6)}…${s.slice(-4)}` : s;
  };

  if (isLoading) {
    return (
      <div className="space-y-2">
        {[1, 2, 3].map((i) => (
          <Skeleton key={i} className="h-16 w-full rounded-xl" />
        ))}
      </div>
    );
  }

  if (logs.length === 0) {
    return (
      <div
        className="text-center py-8 text-muted-foreground text-base"
        data-ocid="admin_settings.log.empty_state"
      >
        <ClipboardList className="w-10 h-10 mx-auto mb-2 opacity-40" />
        <p>No action logs yet.</p>
      </div>
    );
  }

  return (
    <div className="divide-y divide-border rounded-xl border border-border overflow-hidden">
      {logs.slice(0, 20).map((log, i) => (
        <div
          key={String(log.id)}
          className="flex items-start gap-3 px-4 py-3 bg-card hover:bg-muted/30 transition-colors"
          data-ocid={`admin_settings.log.item.${i + 1}`}
        >
          <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0 mt-0.5">
            <ClipboardList className="w-4 h-4 text-primary" />
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-base font-medium text-foreground leading-snug">
              {log.action}
            </p>
            <p className="text-sm text-muted-foreground mt-0.5 truncate">
              {log.details}
            </p>
            <div className="flex items-center gap-2 mt-1 flex-wrap">
              <Badge variant="secondary" className="text-xs">
                {formatPrincipal(log.performedBy)}
              </Badge>
              <span className="text-xs text-muted-foreground">
                {formatTs(log.timestamp)}
              </span>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}

// ─── Main Page ────────────────────────────────────────────────────────────────

export default function AdminSettingsPage() {
  const { getRole } = useRole();
  const role = getRole() as AppRole | null;
  const navigate = useNavigate();
  const { actor, isFetching } = useActor();
  const extended = actor as unknown as ExtendedActor;

  // Check whether PIN is already set
  const { data: pinSetting, refetch: refetchPinStatus } = useQuery({
    queryKey: ["adminSetting", "pinSet"],
    queryFn: async () => {
      if (!extended) return null;
      return extended.getAdminSetting("pinSet");
    },
    enabled: !!actor && !isFetching,
  });

  const hasPin = pinSetting?.value === "true";

  return (
    <RoleGuard role={role} allowedRoles={["admin"]}>
      <Layout role={role ?? "admin"}>
        {/* Page header */}
        <div
          className="bg-card border-b border-border px-4 py-5"
          data-ocid="admin_settings.page"
        >
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-primary/10 flex items-center justify-center">
              <Settings className="w-6 h-6 text-primary" />
            </div>
            <div>
              <h1
                className="text-2xl font-bold font-display text-foreground"
                data-ocid="admin_settings.title"
              >
                Admin Settings
              </h1>
              <p className="text-base text-muted-foreground">
                Settings &amp; Security
              </p>
            </div>
          </div>
        </div>

        <div className="p-4 space-y-5 max-w-2xl mx-auto">
          {/* Warning banner */}
          <div className="flex items-start gap-3 p-4 rounded-xl bg-destructive/10 border border-destructive/30">
            <AlertTriangle className="w-5 h-5 text-destructive mt-0.5 flex-shrink-0" />
            <p className="text-sm text-destructive font-medium leading-snug">
              Admin-only section. Residents cannot access these settings.
            </p>
          </div>

          {/* PIN Management */}
          <Card className="shadow-card" data-ocid="admin_settings.pin_section">
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center gap-2 text-lg">
                <KeyRound className="w-5 h-5 text-primary" />
                Admin PIN
              </CardTitle>
              <p className="text-sm text-muted-foreground mt-0.5">
                4-digit PIN for admin access.
              </p>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center gap-3 p-3 rounded-lg bg-muted/50">
                <Lock className="w-4 h-4 text-muted-foreground flex-shrink-0" />
                <p className="text-sm text-muted-foreground">
                  PIN Status:{" "}
                  <Badge
                    variant={hasPin ? "default" : "secondary"}
                    className="ml-1"
                  >
                    {hasPin ? "Set ✓" : "Not Set"}
                  </Badge>
                </p>
              </div>
              <SetPinSection
                hasPin={hasPin}
                onPinChanged={() => void refetchPinStatus()}
              />
            </CardContent>
          </Card>

          {/* Admin Action Log — always visible */}
          <Card className="shadow-card" data-ocid="admin_settings.log_section">
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center gap-2 text-lg">
                <ClipboardList className="w-5 h-5 text-primary" />
                Admin Action Log
              </CardTitle>
            </CardHeader>
            <CardContent>
              <AdminActionLogSection />
            </CardContent>
          </Card>

          {/* Quick link to Society Body */}
          <button
            type="button"
            onClick={() => void navigate({ to: "/admin/society-body" })}
            className="w-full flex items-center justify-between gap-4 p-4 rounded-xl bg-primary/10 hover:bg-primary/15 border border-primary/20 transition-smooth group"
            data-ocid="admin_settings.society_body_link"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-primary/20 flex items-center justify-center">
                <Users className="w-5 h-5 text-primary" />
              </div>
              <div className="text-left">
                <p className="text-base font-semibold text-foreground">
                  Society Body Management
                </p>
                <p className="text-sm text-muted-foreground">
                  Manage Chairman, Secretary &amp; Members
                </p>
              </div>
            </div>
            <ChevronRight className="w-5 h-5 text-muted-foreground group-hover:text-primary transition-colors flex-shrink-0" />
          </button>
        </div>
      </Layout>
    </RoleGuard>
  );
}
