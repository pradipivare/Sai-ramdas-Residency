import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import { cn } from "@/lib/utils";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useNavigate } from "@tanstack/react-router";
import {
  AlertCircle,
  Check,
  ClipboardList,
  DollarSign,
  Home,
  KeyRound,
  Lock,
  MessageCircle,
  MessageSquarePlus,
  Pencil,
  PlusCircle,
  Receipt,
  ShieldCheck,
  Store,
  User,
  Users,
  X,
} from "lucide-react";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { Layout } from "../../components/Layout";
import { useRole } from "../../hooks/use-role";
import {
  formatCurrency,
  formatDate,
  getOpenComplaintsCount,
  useAllComplaints,
  useAllFlats,
  useAllNotices,
  useAllResidents,
  useAllUnpaidBills,
  useOverdueBillsWithResidents,
  useTodayVisitors,
  useTotalFlatsOverride,
  useTotalShopsOverride,
} from "../../hooks/useQueries";
import { useActor } from "../../lib/backend-client";
import type { AppRole, Notice, OverdueMemberReport } from "../../types";
import { NoticeType } from "../../types";

// ─── Admin Login Gate ─────────────────────────────────────────────────────────

const SESSION_KEY = "admin_verified";

interface AdminActor {
  verifyAdminCredentials(username: string, password: string): Promise<boolean>;
  verifyAdminPin(pinHash: string): Promise<boolean>;
}

async function sha256Hex(text: string): Promise<string> {
  const encoder = new TextEncoder();
  const data = encoder.encode(text);
  const hashBuffer = await crypto.subtle.digest("SHA-256", data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map((b) => b.toString(16).padStart(2, "0")).join("");
}

function AdminLoginGate({ children }: { children: React.ReactNode }) {
  const { actor, isFetching } = useActor();
  const extActor = actor as unknown as AdminActor;
  const [verified, setVerified] = useState(
    () => sessionStorage.getItem(SESSION_KEY) === "true",
  );
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [checking, setChecking] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    if (verified || !actor || isFetching) return;
    void (async () => {
      try {
        const noPin = await actor.verifyAdminPin("");
        if (noPin) {
          sessionStorage.setItem(SESSION_KEY, "true");
          setVerified(true);
        }
      } catch {
        // PIN is set — show login form
      }
    })();
  }, [actor, isFetching, verified]);

  async function handleLogin() {
    if (!username.trim() || !password.trim()) {
      setError("Please enter both username and password");
      return;
    }
    if (!actor) {
      setError("Connection not ready. Please wait.");
      return;
    }
    setChecking(true);
    setError("");
    try {
      let ok = false;
      if (typeof extActor.verifyAdminCredentials === "function") {
        ok = await extActor.verifyAdminCredentials(
          username.trim(),
          password.trim(),
        );
      } else {
        const hash = await sha256Hex(password.trim());
        ok = await actor.verifyAdminPin(hash);
      }
      if (ok) {
        sessionStorage.setItem(SESSION_KEY, "true");
        setVerified(true);
        toast.success("Admin access granted!");
      } else {
        setError("Invalid username or password. Please try again.");
        setPassword("");
      }
    } catch {
      setError("Login failed. Please try again.");
    } finally {
      setChecking(false);
    }
  }

  if (verified) return <>{children}</>;

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-6">
      <Card className="w-full max-w-sm shadow-card">
        <CardContent className="p-8">
          <div className="flex flex-col items-center gap-4 mb-6">
            <div className="w-16 h-16 rounded-2xl bg-primary/10 flex items-center justify-center">
              <Lock className="w-8 h-8 text-primary" />
            </div>
            <div className="text-center">
              <h1 className="text-2xl font-bold font-display text-foreground">
                Admin Login
              </h1>
              <p className="text-base text-muted-foreground mt-1">
                Enter your credentials to access the admin panel
              </p>
            </div>
          </div>

          <div className="space-y-4">
            <div className="space-y-1.5">
              <Label htmlFor="admin-username" className="text-base font-medium">
                Username
              </Label>
              <div className="relative">
                <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input
                  id="admin-username"
                  type="text"
                  placeholder="Enter username"
                  value={username}
                  onChange={(e) => {
                    setUsername(e.target.value);
                    setError("");
                  }}
                  onKeyDown={(e) => e.key === "Enter" && void handleLogin()}
                  className="h-12 pl-10 text-base"
                  autoFocus
                  autoComplete="username"
                  data-ocid="admin.username_input"
                />
              </div>
            </div>

            <div className="space-y-1.5">
              <Label htmlFor="admin-password" className="text-base font-medium">
                Password
              </Label>
              <div className="relative">
                <KeyRound className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input
                  id="admin-password"
                  type="password"
                  placeholder="Enter password"
                  value={password}
                  onChange={(e) => {
                    setPassword(e.target.value);
                    setError("");
                  }}
                  onKeyDown={(e) => e.key === "Enter" && void handleLogin()}
                  className="h-12 pl-10 text-base"
                  autoComplete="current-password"
                  data-ocid="admin.password_input"
                />
              </div>
            </div>

            {error && (
              <p
                className="text-sm text-destructive font-medium text-center"
                data-ocid="admin.login_error_state"
              >
                {error}
              </p>
            )}

            <Button
              className="w-full btn-accessible h-12 text-base gap-2"
              onClick={() => void handleLogin()}
              disabled={
                checking || !username.trim() || !password.trim() || isFetching
              }
              data-ocid="admin.login_submit_button"
            >
              {checking ? (
                <span data-ocid="admin.login_loading_state">Verifying…</span>
              ) : (
                <>
                  <ShieldCheck className="w-5 h-5" /> Login
                </>
              )}
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

// ─── Stat card ────────────────────────────────────────────────────────────────

function StatCard({
  icon,
  label,
  value,
  color,
  loading,
  ocid,
}: {
  icon: React.ReactNode;
  label: string;
  value: number | string;
  color: string;
  loading?: boolean;
  ocid: string;
}) {
  return (
    <Card
      className="shadow-card hover:shadow-md transition-smooth"
      data-ocid={ocid}
    >
      <CardContent className="p-5 flex items-center gap-4">
        <div
          className={cn(
            "w-14 h-14 rounded-2xl flex items-center justify-center flex-shrink-0",
            color,
          )}
        >
          {icon}
        </div>
        <div className="min-w-0 flex-1">
          {loading ? (
            <>
              <Skeleton className="h-8 w-16 mb-1" />
              <Skeleton className="h-4 w-24" />
            </>
          ) : (
            <>
              <p className="text-3xl font-bold font-display text-foreground leading-none">
                {value}
              </p>
              <p className="text-base text-muted-foreground mt-1 leading-tight">
                {label}
              </p>
            </>
          )}
        </div>
      </CardContent>
    </Card>
  );
}

// ─── Editable Total Flats Card ─────────────────────────────────────────────────

function TotalFlatsCard() {
  const { data: flats = [], isLoading: flatsLoading } = useAllFlats();
  const { data: override, isLoading: overrideLoading } =
    useTotalFlatsOverride();
  const { actor } = useActor();
  const queryClient = useQueryClient();
  const [editing, setEditing] = useState(false);
  const [inputVal, setInputVal] = useState("");

  const displayValue =
    override !== null && override !== undefined
      ? Number(override)
      : flats.length;
  const isLoading = flatsLoading || overrideLoading;

  const mutation = useMutation({
    mutationFn: async (count: bigint) => {
      if (!actor) throw new Error("No actor");
      await actor.setTotalFlatsOverride(count);
    },
    onSuccess: () => {
      toast.success("Total flats updated!");
      void queryClient.invalidateQueries({ queryKey: ["totalFlatsOverride"] });
      setEditing(false);
    },
    onError: () => toast.error("Update failed"),
  });

  function saveEdit() {
    const num = Number.parseInt(inputVal, 10);
    if (Number.isNaN(num) || num < 0) {
      toast.error("Please enter a valid number");
      return;
    }
    mutation.mutate(BigInt(num));
  }

  return (
    <Card
      className="shadow-card hover:shadow-md transition-smooth"
      data-ocid="dashboard.stat.flats"
    >
      <CardContent className="p-5 flex items-center gap-4">
        <div className="w-14 h-14 rounded-2xl bg-primary/10 flex items-center justify-center flex-shrink-0">
          <Home className="w-6 h-6 text-primary" />
        </div>
        <div className="min-w-0 flex-1">
          {isLoading ? (
            <>
              <Skeleton className="h-8 w-16 mb-1" />
              <Skeleton className="h-4 w-24" />
            </>
          ) : editing ? (
            <div className="flex items-center gap-1.5">
              <Input
                type="number"
                min={0}
                value={inputVal}
                onChange={(e) => setInputVal(e.target.value)}
                className="h-9 w-20 text-base font-bold p-2"
                autoFocus
                onKeyDown={(e) => {
                  if (e.key === "Enter") saveEdit();
                  if (e.key === "Escape") setEditing(false);
                }}
                data-ocid="dashboard.flats_override_input"
              />
              <button
                type="button"
                onClick={saveEdit}
                disabled={mutation.isPending}
                className="w-8 h-8 rounded-lg bg-primary/10 text-primary flex items-center justify-center hover:bg-primary/20 transition-colors"
                aria-label="Save"
                data-ocid="dashboard.flats_override_save"
              >
                <Check className="w-4 h-4" />
              </button>
              <button
                type="button"
                onClick={() => setEditing(false)}
                className="w-8 h-8 rounded-lg bg-muted text-muted-foreground flex items-center justify-center hover:bg-muted/70 transition-colors"
                aria-label="Cancel"
                data-ocid="dashboard.flats_override_cancel"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          ) : (
            <div className="flex items-center gap-2">
              <p className="text-3xl font-bold font-display text-foreground leading-none">
                {displayValue}
              </p>
              {override !== null && override !== undefined && (
                <Badge variant="secondary" className="text-xs">
                  Overridden
                </Badge>
              )}
              <button
                type="button"
                onClick={() => {
                  setInputVal(String(displayValue));
                  setEditing(true);
                }}
                className="w-7 h-7 rounded-lg flex items-center justify-center hover:bg-muted transition-colors"
                aria-label="Edit total flats"
                data-ocid="dashboard.flats_override_edit_button"
              >
                <Pencil className="w-3.5 h-3.5 text-muted-foreground" />
              </button>
            </div>
          )}
          <p className="text-base text-muted-foreground mt-1 leading-tight">
            Total Flats
          </p>
        </div>
      </CardContent>
    </Card>
  );
}

// ─── Editable Total Shops Card ────────────────────────────────────────────────

function TotalShopsCard() {
  const { data: override, isLoading: overrideLoading } =
    useTotalShopsOverride();
  const { actor } = useActor();
  const queryClient = useQueryClient();
  const [editing, setEditing] = useState(false);
  const [inputVal, setInputVal] = useState("");

  const displayValue = override !== undefined ? Number(override) : 0;

  const mutation = useMutation({
    mutationFn: async (count: bigint) => {
      if (!actor) throw new Error("No actor");
      await actor.setTotalShopsOverride(count);
    },
    onSuccess: () => {
      toast.success("Total shops updated!");
      void queryClient.invalidateQueries({ queryKey: ["totalShopsOverride"] });
      setEditing(false);
    },
    onError: () => toast.error("Update failed"),
  });

  function saveEdit() {
    const num = Number.parseInt(inputVal, 10);
    if (Number.isNaN(num) || num < 0) {
      toast.error("Please enter a valid number");
      return;
    }
    mutation.mutate(BigInt(num));
  }

  return (
    <Card
      className="shadow-card hover:shadow-md transition-smooth"
      data-ocid="dashboard.stat.shops"
    >
      <CardContent className="p-5 flex items-center gap-4">
        <div className="w-14 h-14 rounded-2xl bg-indigo-500/10 flex items-center justify-center flex-shrink-0">
          <Store className="w-6 h-6 text-indigo-600" />
        </div>
        <div className="min-w-0 flex-1">
          {overrideLoading ? (
            <>
              <Skeleton className="h-8 w-16 mb-1" />
              <Skeleton className="h-4 w-24" />
            </>
          ) : editing ? (
            <div className="flex items-center gap-1.5">
              <Input
                type="number"
                min={0}
                value={inputVal}
                onChange={(e) => setInputVal(e.target.value)}
                className="h-9 w-20 text-base font-bold p-2"
                autoFocus
                onKeyDown={(e) => {
                  if (e.key === "Enter") saveEdit();
                  if (e.key === "Escape") setEditing(false);
                }}
                data-ocid="dashboard.shops_override_input"
              />
              <button
                type="button"
                onClick={saveEdit}
                disabled={mutation.isPending}
                className="w-8 h-8 rounded-lg bg-indigo-500/10 text-indigo-600 flex items-center justify-center hover:bg-indigo-500/20 transition-colors"
                aria-label="Save"
                data-ocid="dashboard.shops_override_save"
              >
                <Check className="w-4 h-4" />
              </button>
              <button
                type="button"
                onClick={() => setEditing(false)}
                className="w-8 h-8 rounded-lg bg-muted text-muted-foreground flex items-center justify-center hover:bg-muted/70 transition-colors"
                aria-label="Cancel"
                data-ocid="dashboard.shops_override_cancel"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          ) : (
            <div className="flex items-center gap-2">
              <p className="text-3xl font-bold font-display text-foreground leading-none">
                {displayValue}
              </p>
              {override !== undefined && Number(override) > 0 && (
                <Badge variant="secondary" className="text-xs">
                  Overridden
                </Badge>
              )}
              <button
                type="button"
                onClick={() => {
                  setInputVal(String(displayValue));
                  setEditing(true);
                }}
                className="w-7 h-7 rounded-lg flex items-center justify-center hover:bg-muted transition-colors"
                aria-label="Edit total shops"
                data-ocid="dashboard.shops_override_edit_button"
              >
                <Pencil className="w-3.5 h-3.5 text-muted-foreground" />
              </button>
            </div>
          )}
          <p className="text-base text-muted-foreground mt-1 leading-tight">
            Total Shops
          </p>
        </div>
      </CardContent>
    </Card>
  );
}

// ─── Notice row ───────────────────────────────────────────────────────────────

function NoticeRow({ notice, index }: { notice: Notice; index: number }) {
  const isEmergency = notice.noticeType === NoticeType.emergency;
  return (
    <div
      className="flex items-start gap-3 py-3 border-b border-border last:border-0"
      data-ocid={`dashboard.notice.item.${index + 1}`}
    >
      <div
        className={cn(
          "w-2.5 h-2.5 rounded-full mt-2 flex-shrink-0",
          isEmergency ? "bg-destructive" : "bg-primary",
        )}
      />
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2 flex-wrap">
          <p className="text-base font-semibold text-foreground truncate">
            {notice.title}
          </p>
          {isEmergency && (
            <Badge
              variant="destructive"
              className="text-xs flex-shrink-0"
              data-ocid={`dashboard.notice.emergency_badge.${index + 1}`}
            >
              🚨 Emergency
            </Badge>
          )}
          {notice.isPinned && !isEmergency && (
            <Badge variant="secondary" className="text-xs flex-shrink-0">
              📌 Pinned
            </Badge>
          )}
        </div>
        <p className="text-sm text-muted-foreground mt-0.5 line-clamp-1">
          {notice.content}
        </p>
      </div>
    </div>
  );
}

// ─── Quick action button ──────────────────────────────────────────────────────

function QuickAction({
  icon,
  label,
  description,
  onClick,
  ocid,
  variant = "primary",
}: {
  icon: React.ReactNode;
  label: string;
  description: string;
  onClick: () => void;
  ocid: string;
  variant?: "primary" | "accent" | "secondary";
}) {
  const colors: Record<string, string> = {
    primary: "bg-primary/10 text-primary hover:bg-primary/20",
    accent: "bg-accent/20 text-accent-foreground hover:bg-accent/30",
    secondary: "bg-secondary text-secondary-foreground hover:bg-secondary/80",
  };
  return (
    <button
      type="button"
      onClick={onClick}
      data-ocid={ocid}
      className={cn(
        "flex items-center gap-4 w-full p-4 rounded-xl text-left transition-smooth min-h-[72px]",
        colors[variant],
      )}
    >
      <div className="w-10 h-10 flex items-center justify-center flex-shrink-0">
        {icon}
      </div>
      <div>
        <p className="text-lg font-semibold leading-tight">{label}</p>
        <p className="text-sm opacity-70 mt-0.5">{description}</p>
      </div>
    </button>
  );
}

// ─── Overdue Member Row ───────────────────────────────────────────────────────

function buildWhatsAppUrl(
  mobile: string,
  residentName: string,
  amount: bigint,
  dueDate: bigint,
): string {
  const cleanMobile = mobile.replace(/^0/, "");
  const dueDateStr = formatDate(dueDate);
  const message = `Dear ${residentName}, your maintenance bill of Rs.${Number(amount).toLocaleString("en-IN")} was due on ${dueDateStr}. Please pay at the earliest. Thank you, Sai Ramdas Society`;
  return `https://wa.me/91${cleanMobile}?text=${encodeURIComponent(message)}`;
}

function OverdueMemberRow({
  report,
  index,
}: {
  report: OverdueMemberReport;
  index: number;
}) {
  return (
    <div
      className="flex items-center gap-3 px-4 py-3 border-b border-border last:border-0 bg-destructive/3"
      data-ocid={`dashboard.overdue.item.${index}`}
    >
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2 flex-wrap">
          <span className="font-bold text-base text-red-500">
            Flat {report.flatNumber}
          </span>
          <span className="text-base font-medium text-foreground truncate">
            {report.residentName}
          </span>
        </div>
        <div className="flex items-center gap-3 mt-0.5 flex-wrap">
          <span className="text-sm font-semibold text-red-500">
            {formatCurrency(report.amount)}
          </span>
          <span className="text-sm text-muted-foreground">
            Due: {formatDate(report.dueDate)}
          </span>
          {report.penaltyAmount > 0n && (
            <span className="text-xs text-destructive font-medium">
              +{formatCurrency(report.penaltyAmount)} penalty
            </span>
          )}
        </div>
      </div>
      {report.mobile && (
        <a
          href={buildWhatsAppUrl(
            report.mobile,
            report.residentName,
            report.amount,
            report.dueDate,
          )}
          target="_blank"
          rel="noopener noreferrer"
          data-ocid={`dashboard.overdue.send_reminder_button.${index}`}
          className="flex-shrink-0"
        >
          <button
            type="button"
            className="flex items-center gap-1.5 h-9 px-3 rounded-lg border border-orange-500/50 text-orange-500 text-xs font-semibold hover:bg-orange-500/10 transition-colors"
            tabIndex={-1}
          >
            <MessageCircle className="w-3.5 h-3.5" />
            Send Reminder
          </button>
        </a>
      )}
    </div>
  );
}

// ─── Main Component ───────────────────────────────────────────────────────────

function AdminDashboardContent() {
  const navigate = useNavigate();
  const { getRole } = useRole();
  const role = getRole() as AppRole;

  const { data: residents = [], isLoading: residentsLoading } =
    useAllResidents();
  const { data: unpaidBills = [], isLoading: billsLoading } =
    useAllUnpaidBills();
  const { data: complaints = [], isLoading: complaintsLoading } =
    useAllComplaints();
  const { data: todayVisitors = [], isLoading: visitorsLoading } =
    useTodayVisitors();
  const { data: notices = [], isLoading: noticesLoading } = useAllNotices();
  const { data: overdueBills = [], isLoading: overdueLoading } =
    useOverdueBillsWithResidents();

  const isCommittee = role === "committee";
  const isAdmin = role === "admin";
  const greeting = isCommittee ? "Committee Dashboard" : "Admin Dashboard";
  const subtitle = isCommittee
    ? "Manage complaints, notices & approvals"
    : "Full society management & controls";

  const openComplaints = getOpenComplaintsCount(complaints);
  const recentNotices = [...notices]
    .sort((a, b) => Number(b.postedAt) - Number(a.postedAt))
    .slice(0, 3);

  const totalUnpaid = unpaidBills.reduce(
    (sum, b) => sum + Number(b.amount) + Number(b.penaltyAmount),
    0,
  );

  return (
    <Layout role={role}>
      {/* Page header */}
      <div className="bg-card border-b border-border px-4 py-5">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-primary/10 flex items-center justify-center">
            <ShieldCheck className="w-6 h-6 text-primary" />
          </div>
          <div>
            <h1
              className="text-2xl font-bold font-display text-foreground"
              data-ocid="dashboard.title"
            >
              {greeting}
            </h1>
            <p className="text-base text-muted-foreground">{subtitle}</p>
          </div>
        </div>
      </div>

      <div className="p-4 space-y-6 max-w-4xl mx-auto">
        {/* Stat cards */}
        <section aria-label="Key metrics">
          <h2 className="text-lg font-semibold text-foreground mb-3">
            Society Overview
          </h2>
          <div
            className="grid grid-cols-2 gap-3 sm:grid-cols-3"
            data-ocid="dashboard.stats_section"
          >
            {isAdmin ? (
              <TotalFlatsCard />
            ) : (
              <StatCard
                icon={<Home className="w-6 h-6 text-primary" />}
                label="Flats"
                value={residents.length}
                color="bg-primary/10"
                loading={residentsLoading}
                ocid="dashboard.stat.flats"
              />
            )}
            {isAdmin ? (
              <TotalShopsCard />
            ) : (
              <StatCard
                icon={<Store className="w-6 h-6 text-indigo-600" />}
                label="Shops"
                value="—"
                color="bg-indigo-500/10"
                loading={false}
                ocid="dashboard.stat.shops"
              />
            )}
            <StatCard
              icon={<Users className="w-6 h-6 text-primary" />}
              label="Residents"
              value={residents.length}
              color="bg-primary/10"
              loading={residentsLoading}
              ocid="dashboard.stat.residents"
            />
            <StatCard
              icon={<DollarSign className="w-6 h-6 text-destructive" />}
              label="Unpaid Bills"
              value={billsLoading ? "—" : unpaidBills.length}
              color="bg-destructive/10"
              loading={billsLoading}
              ocid="dashboard.stat.unpaid_bills"
            />
            <StatCard
              icon={<AlertCircle className="w-6 h-6 text-accent-foreground" />}
              label="Open Complaints"
              value={complaintsLoading ? "—" : openComplaints}
              color="bg-accent/20"
              loading={complaintsLoading}
              ocid="dashboard.stat.open_complaints"
            />
            <StatCard
              icon={<Users className="w-6 h-6 text-primary" />}
              label="Today's Visitors"
              value={visitorsLoading ? "—" : todayVisitors.length}
              color="bg-primary/10"
              loading={visitorsLoading}
              ocid="dashboard.stat.today_visitors"
            />
            {!isCommittee && (
              <StatCard
                icon={<Receipt className="w-6 h-6 text-destructive" />}
                label="Total Dues"
                value={billsLoading ? "—" : formatCurrency(BigInt(totalUnpaid))}
                color="bg-destructive/10"
                loading={billsLoading}
                ocid="dashboard.stat.total_dues"
              />
            )}
          </div>
        </section>

        {/* Quick actions */}
        <section aria-label="Quick actions">
          <h2 className="text-lg font-semibold text-foreground mb-3">
            Quick Actions
          </h2>
          <Card className="shadow-card" data-ocid="dashboard.quick_actions">
            <CardContent className="p-3 space-y-2">
              {!isCommittee && (
                <QuickAction
                  icon={<PlusCircle className="w-6 h-6" />}
                  label="Add Member"
                  description="Register new owner or tenant"
                  onClick={() => void navigate({ to: "/residents" })}
                  ocid="dashboard.add_member_button"
                  variant="primary"
                />
              )}
              {!isCommittee && (
                <QuickAction
                  icon={<Receipt className="w-6 h-6" />}
                  label="Generate Bills"
                  description="Monthly maintenance billing"
                  onClick={() => void navigate({ to: "/bills" })}
                  ocid="dashboard.generate_bills_button"
                  variant="accent"
                />
              )}
              <QuickAction
                icon={<MessageSquarePlus className="w-6 h-6" />}
                label="Post Notice"
                description="Send announcement to all residents"
                onClick={() => void navigate({ to: "/notices" })}
                ocid="dashboard.post_notice_button"
                variant="secondary"
              />
              <QuickAction
                icon={<ClipboardList className="w-6 h-6" />}
                label="View Complaints"
                description="Resolve resident complaints"
                onClick={() => void navigate({ to: "/complaints" })}
                ocid="dashboard.view_complaints_button"
                variant="secondary"
              />
            </CardContent>
          </Card>
        </section>

        {/* Overdue Summary — admin only */}
        {isAdmin && (
          <section aria-label="Overdue bill summary">
            <div className="flex items-center gap-2 mb-3">
              <h2 className="text-lg font-semibold text-red-500">
                🔴 Overdue Summary
              </h2>
              {!overdueLoading && (
                <span className="text-sm font-bold bg-destructive/10 text-destructive px-2.5 py-0.5 rounded-full">
                  {overdueBills.length} overdue
                </span>
              )}
            </div>
            <Card
              className="shadow-card border-destructive/30"
              data-ocid="dashboard.overdue_summary_section"
            >
              <div className="px-4 py-3 bg-destructive/10 border-b border-destructive/20 rounded-t-xl flex items-center gap-2">
                <AlertCircle className="w-4 h-4 text-destructive" />
                <span className="text-base font-semibold text-destructive">
                  Members with pending dues past due date
                </span>
              </div>
              <CardContent className="p-0">
                {overdueLoading ? (
                  <div
                    className="p-4 space-y-2"
                    data-ocid="dashboard.overdue_summary.loading_state"
                  >
                    {[1, 2, 3].map((i) => (
                      <Skeleton key={i} className="h-12 w-full" />
                    ))}
                  </div>
                ) : overdueBills.length === 0 ? (
                  <p
                    className="text-muted-foreground text-base text-center py-8"
                    data-ocid="dashboard.overdue_summary.empty_state"
                  >
                    ✅ No overdue members — all payments are on time!
                  </p>
                ) : (
                  <div>
                    {overdueBills.map((report, i) => (
                      <OverdueMemberRow
                        key={String(report.billId)}
                        report={report}
                        index={i + 1}
                      />
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </section>
        )}

        {/* Recent notices */}
        <section aria-label="Recent notices">
          <div className="flex items-center justify-between mb-3">
            <h2 className="text-lg font-semibold text-foreground">
              Recent Notices
            </h2>
            <Button
              variant="ghost"
              size="sm"
              className="text-primary text-base"
              onClick={() => void navigate({ to: "/notices" })}
              data-ocid="dashboard.all_notices_link"
            >
              View All
            </Button>
          </div>
          <Card className="shadow-card" data-ocid="dashboard.notices_section">
            <CardContent className="p-4">
              {noticesLoading ? (
                <div className="space-y-3">
                  {[1, 2, 3].map((i) => (
                    <Skeleton key={i} className="h-12 w-full" />
                  ))}
                </div>
              ) : recentNotices.length === 0 ? (
                <p
                  className="text-muted-foreground text-base text-center py-6"
                  data-ocid="dashboard.notices.empty_state"
                >
                  No notices yet.
                </p>
              ) : (
                recentNotices.map((notice, i) => (
                  <NoticeRow
                    key={String(notice.noticeId)}
                    notice={notice}
                    index={i}
                  />
                ))
              )}
            </CardContent>
          </Card>
        </section>
      </div>
    </Layout>
  );
}

export default function AdminDashboard() {
  return (
    <AdminLoginGate>
      <AdminDashboardContent />
    </AdminLoginGate>
  );
}
