import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { Switch } from "@/components/ui/switch";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import {
  Camera,
  Edit2,
  Eye,
  Plus,
  Trash2,
  Upload,
  UserCheck,
  Users,
} from "lucide-react";
import { useRef, useState } from "react";
import { toast } from "sonner";
import type { SocietyMember } from "../../backend";
import { SocietyMemberRole as SocietyMemberRoleEnum } from "../../backend";
import { Layout } from "../../components/Layout";
import { RoleGuard } from "../../components/RoleGuard";
import { useRole } from "../../hooks/use-role";
import { useActor } from "../../lib/backend-client";
import type { AppRole, SocietyMemberRole } from "../../types";
import { SOCIETY_MEMBER_ROLE_LABELS } from "../../types";

// ─── Types ───────────────────────────────────────────────────────────────────

const ROLE_OPTIONS: { value: SocietyMemberRole; label: string }[] = [
  { value: "chairman", label: "Chairman" },
  { value: "viceChairman", label: "Vice Chairman" },
  { value: "secretary", label: "Secretary" },
  { value: "treasurer", label: "Treasurer" },
  { value: "member", label: "Member" },
];

// ─── Photo Capture Button ─────────────────────────────────────────────────────

interface PhotoCaptureProps {
  memberId: bigint;
  memberIndex: number;
  onCapture: (id: bigint, dataUrl: string) => void;
  isPending: boolean;
}

function PhotoCaptureButtons({
  memberId,
  memberIndex,
  onCapture,
  isPending,
}: PhotoCaptureProps) {
  const cameraRef = useRef<HTMLInputElement>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  function handleFile(file: File) {
    const reader = new FileReader();
    reader.onload = (e) => {
      const dataUrl = e.target?.result as string;
      onCapture(memberId, dataUrl);
    };
    reader.readAsDataURL(file);
  }

  return (
    <div className="flex gap-1.5 mt-2">
      <button
        type="button"
        onClick={() => cameraRef.current?.click()}
        disabled={isPending}
        className="flex items-center gap-1 px-2 py-1.5 rounded-lg bg-primary/10 text-primary text-sm font-medium hover:bg-primary/20 transition-colors"
        aria-label="Take photo with camera"
        data-ocid={`society_body.camera_button.${memberIndex}`}
      >
        <Camera className="w-4 h-4" />
        Camera
      </button>
      <button
        type="button"
        onClick={() => fileRef.current?.click()}
        disabled={isPending}
        className="flex items-center gap-1 px-2 py-1.5 rounded-lg bg-muted text-foreground text-sm font-medium hover:bg-muted/70 transition-colors"
        aria-label="Upload photo from file"
        data-ocid={`society_body.upload_button.${memberIndex}`}
      >
        <Upload className="w-4 h-4" />
        Upload
      </button>
      <input
        ref={cameraRef}
        type="file"
        accept="image/*"
        capture="user"
        className="hidden"
        onChange={(e) => {
          const f = e.target.files?.[0];
          if (f) handleFile(f);
          e.target.value = "";
        }}
      />
      <input
        ref={fileRef}
        type="file"
        accept="image/*"
        className="hidden"
        onChange={(e) => {
          const f = e.target.files?.[0];
          if (f) handleFile(f);
          e.target.value = "";
        }}
      />
    </div>
  );
}

// ─── Member Form ─────────────────────────────────────────────────────────────

interface MemberFormData {
  nameEnglish: string;
  role: SocietyMemberRole;
  contactPhone: string;
  contactEmail: string;
  orderNumber: string;
  isActive: boolean;
}

const emptyForm: MemberFormData = {
  nameEnglish: "",
  role: "member",
  contactPhone: "",
  contactEmail: "",
  orderNumber: "",
  isActive: true,
};

interface MemberFormProps {
  initial?: MemberFormData;
  onSubmit: (data: MemberFormData) => void;
  isPending: boolean;
  isEdit?: boolean;
}

function MemberForm({
  initial = emptyForm,
  onSubmit,
  isPending,
  isEdit,
}: MemberFormProps) {
  const [form, setForm] = useState<MemberFormData>(initial);
  const set = (key: keyof MemberFormData, value: string | boolean) =>
    setForm((f) => ({ ...f, [key]: value }));

  return (
    <form
      onSubmit={(e) => {
        e.preventDefault();
        onSubmit(form);
      }}
      className="space-y-5"
    >
      <div className="space-y-2">
        <Label className="text-base font-semibold">Full Name *</Label>
        <Input
          required
          value={form.nameEnglish}
          onChange={(e) => set("nameEnglish", e.target.value)}
          placeholder="e.g. Ram Patil"
          className="h-13 text-lg font-medium"
          data-ocid="society_body.form.name_input"
        />
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label className="text-base font-semibold">Role</Label>
          <Select
            value={form.role}
            onValueChange={(v) => set("role", v as SocietyMemberRole)}
          >
            <SelectTrigger
              className="h-12 text-base"
              data-ocid="society_body.form.role_select"
            >
              <SelectValue placeholder="Select role" />
            </SelectTrigger>
            <SelectContent>
              {ROLE_OPTIONS.map((r) => (
                <SelectItem
                  key={r.value}
                  value={r.value}
                  className="text-base py-3"
                >
                  {r.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div className="space-y-2">
          <Label className="text-base font-semibold">Order</Label>
          <Input
            type="number"
            min={1}
            value={form.orderNumber}
            onChange={(e) => set("orderNumber", e.target.value)}
            placeholder="1"
            className="h-12 text-base"
            data-ocid="society_body.form.order_input"
          />
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label className="text-base font-semibold">Phone</Label>
          <Input
            type="tel"
            value={form.contactPhone}
            onChange={(e) => set("contactPhone", e.target.value)}
            placeholder="9876543210"
            className="h-12 text-base"
            data-ocid="society_body.form.phone_input"
          />
        </div>
        <div className="space-y-2">
          <Label className="text-base font-semibold">Email</Label>
          <Input
            type="email"
            value={form.contactEmail}
            onChange={(e) => set("contactEmail", e.target.value)}
            placeholder="ram@example.com"
            className="h-12 text-base"
            data-ocid="society_body.form.email_input"
          />
        </div>
      </div>

      <div className="flex items-center gap-3 p-3 rounded-xl bg-muted/50">
        <Switch
          checked={form.isActive}
          onCheckedChange={(v) => set("isActive", v)}
          data-ocid="society_body.form.active_toggle"
        />
        <Label className="text-base font-medium cursor-pointer">
          {form.isActive ? "Active" : "Inactive"}
        </Label>
      </div>

      <Button
        type="submit"
        disabled={isPending}
        className="w-full btn-accessible text-base h-12"
        data-ocid="society_body.form.submit_button"
      >
        {isPending ? (
          <span data-ocid="society_body.form.loading_state">
            {isEdit ? "Updating…" : "Adding…"}
          </span>
        ) : isEdit ? (
          "Update Member"
        ) : (
          "Add Member"
        )}
      </Button>
    </form>
  );
}

// ─── Member Card ──────────────────────────────────────────────────────────────

interface MemberCardProps {
  member: SocietyMember;
  index: number;
  onEdit: (m: SocietyMember) => void;
  onDelete: (id: bigint) => void;
  onUploadPhoto: (id: bigint, dataUrl: string) => void;
  photoUploading: bigint | null;
}

function MemberCard({
  member,
  index,
  onEdit,
  onDelete,
  onUploadPhoto,
  photoUploading,
}: MemberCardProps) {
  const role = member.role as SocietyMemberRole;
  const phone = member.contactPhone ?? "";
  const photoId = member.photoId ?? "";

  const roleColors: Record<SocietyMemberRole, string> = {
    chairman: "bg-primary/10 text-primary",
    viceChairman: "bg-accent/20 text-accent-foreground",
    secretary: "bg-secondary text-secondary-foreground",
    treasurer: "bg-muted text-foreground",
    member: "bg-muted/60 text-muted-foreground",
  };

  const isUploading = photoUploading === member.id;

  return (
    <Card
      className={`shadow-card transition-smooth ${!member.isActive ? "opacity-60" : ""}`}
      data-ocid={`society_body.member.item.${index + 1}`}
    >
      <CardContent className="p-4">
        <div className="flex items-start gap-4">
          {/* Avatar */}
          <div className="flex-shrink-0">
            {photoId ? (
              <img
                src={photoId}
                alt={member.nameEnglish}
                className="w-16 h-16 rounded-2xl object-cover border-2 border-border"
              />
            ) : (
              <div className="w-16 h-16 rounded-2xl bg-primary/10 flex items-center justify-center text-2xl font-bold text-primary border-2 border-border">
                {member.nameEnglish.charAt(0).toUpperCase()}
              </div>
            )}
          </div>

          <div className="flex-1 min-w-0">
            <div className="flex items-start justify-between gap-2">
              <div className="min-w-0">
                <p className="text-base font-bold text-foreground leading-tight">
                  {member.nameEnglish}
                </p>
              </div>
              <div className="flex gap-1 flex-shrink-0">
                <button
                  type="button"
                  onClick={() => onEdit(member)}
                  className="w-9 h-9 rounded-lg flex items-center justify-center hover:bg-muted transition-colors"
                  aria-label="Edit member"
                  data-ocid={`society_body.edit_button.${index + 1}`}
                >
                  <Edit2 className="w-4 h-4 text-muted-foreground" />
                </button>
                <button
                  type="button"
                  onClick={() => onDelete(member.id)}
                  className="w-9 h-9 rounded-lg flex items-center justify-center hover:bg-destructive/10 transition-colors"
                  aria-label="Remove member"
                  data-ocid={`society_body.delete_button.${index + 1}`}
                >
                  <Trash2 className="w-4 h-4 text-destructive" />
                </button>
              </div>
            </div>

            <div className="flex items-center gap-2 mt-1.5 flex-wrap">
              <Badge className={`text-xs ${roleColors[role]}`}>
                {SOCIETY_MEMBER_ROLE_LABELS[role]}
              </Badge>
              {!member.isActive && (
                <Badge variant="secondary" className="text-xs">
                  Inactive
                </Badge>
              )}
            </div>

            {phone && (
              <p className="text-sm text-muted-foreground mt-1">📞 {phone}</p>
            )}

            {/* Photo upload buttons */}
            <PhotoCaptureButtons
              memberId={member.id}
              memberIndex={index + 1}
              onCapture={onUploadPhoto}
              isPending={isUploading}
            />
            {isUploading && (
              <p className="text-xs text-muted-foreground mt-1">
                Uploading photo…
              </p>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

// ─── Preview Row ──────────────────────────────────────────────────────────────

function HomePagePreview({ members }: { members: SocietyMember[] }) {
  const active = [...members]
    .filter((m) => m.isActive)
    .sort((a, b) => Number(a.orderNumber) - Number(b.orderNumber));

  return (
    <Card
      className="shadow-card bg-muted/30"
      data-ocid="society_body.preview_panel"
    >
      <CardHeader className="pb-2">
        <CardTitle className="flex items-center gap-2 text-base">
          <Eye className="w-4 h-4 text-muted-foreground" />
          Home Page Preview
        </CardTitle>
      </CardHeader>
      <CardContent>
        {active.length === 0 ? (
          <p className="text-sm text-muted-foreground py-2">
            No active members.
          </p>
        ) : (
          <div className="flex gap-3 overflow-x-auto pb-2 snap-x">
            {active.map((m) => {
              const role = m.role as SocietyMemberRole;
              const photoId = m.photoId ?? "";
              return (
                <div
                  key={String(m.id)}
                  className="flex-shrink-0 snap-start text-center w-20"
                >
                  {photoId ? (
                    <img
                      src={photoId}
                      alt={m.nameEnglish}
                      className="w-14 h-14 rounded-full object-cover border-2 border-primary/30 mx-auto"
                    />
                  ) : (
                    <div className="w-14 h-14 rounded-full bg-primary/10 flex items-center justify-center text-xl font-bold text-primary border-2 border-primary/30 mx-auto">
                      {m.nameEnglish.charAt(0)}
                    </div>
                  )}
                  <p className="text-xs font-semibold text-foreground mt-1 leading-tight truncate">
                    {m.nameEnglish}
                  </p>
                  <p className="text-xs text-muted-foreground leading-tight truncate">
                    {SOCIETY_MEMBER_ROLE_LABELS[role]}
                  </p>
                </div>
              );
            })}
          </div>
        )}
      </CardContent>
    </Card>
  );
}

// ─── Main Page ────────────────────────────────────────────────────────────────

export default function SocietyBodyManagePage() {
  const { getRole } = useRole();
  const role = getRole() as AppRole | null;
  const { actor, isFetching } = useActor();
  const queryClient = useQueryClient();

  const [showAddForm, setShowAddForm] = useState(false);
  const [editingMember, setEditingMember] = useState<SocietyMember | null>(
    null,
  );
  const [photoUploadingId, setPhotoUploadingId] = useState<bigint | null>(null);
  const [confirmDeleteId, setConfirmDeleteId] = useState<bigint | null>(null);

  const { data: members = [], isLoading } = useQuery<SocietyMember[]>({
    queryKey: ["societyMembers"],
    queryFn: async () => {
      if (!actor) return [];
      return actor.getSocietyMembers();
    },
    enabled: !!actor && !isFetching,
  });

  const refetch = () =>
    void queryClient.invalidateQueries({ queryKey: ["societyMembers"] });

  const addMutation = useMutation({
    mutationFn: async (data: MemberFormData) => {
      if (!actor) throw new Error("Actor not ready");
      await actor.addSocietyMember(
        data.nameEnglish,
        data.nameEnglish,
        SocietyMemberRoleEnum[data.role as keyof typeof SocietyMemberRoleEnum],
        null,
        data.contactPhone || null,
        data.contactEmail || null,
        BigInt(Number.parseInt(data.orderNumber || "99", 10)),
      );
    },
    onSuccess: () => {
      toast.success("Member added!");
      setShowAddForm(false);
      refetch();
    },
    onError: () => toast.error("Failed to add member"),
  });

  const updateMutation = useMutation({
    mutationFn: async ({ id, data }: { id: bigint; data: MemberFormData }) => {
      if (!actor) throw new Error("Actor not ready");
      const existing = members.find((m) => m.id === id);
      if (!existing) throw new Error("Member not found");
      await actor.updateSocietyMember({
        ...existing,
        nameMarathi: data.nameEnglish,
        nameEnglish: data.nameEnglish,
        role: SocietyMemberRoleEnum[
          data.role as keyof typeof SocietyMemberRoleEnum
        ],
        contactPhone: data.contactPhone || undefined,
        contactEmail: data.contactEmail || undefined,
        orderNumber: BigInt(Number.parseInt(data.orderNumber || "99", 10)),
        isActive: data.isActive,
      });
    },
    onSuccess: () => {
      toast.success("Member updated!");
      setEditingMember(null);
      refetch();
    },
    onError: () => toast.error("Update failed"),
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: bigint) => {
      if (!actor) throw new Error("Actor not ready");
      await actor.deleteSocietyMember(id);
    },
    onSuccess: () => {
      toast.success("Member removed");
      setConfirmDeleteId(null);
      refetch();
    },
    onError: () => toast.error("Remove failed"),
  });

  const photoMutation = useMutation({
    mutationFn: async ({ id, dataUrl }: { id: bigint; dataUrl: string }) => {
      if (!actor) throw new Error("Actor not ready");
      await actor.setSocietyMemberPhoto(id, dataUrl);
    },
    onSuccess: () => {
      toast.success("Photo uploaded!");
      setPhotoUploadingId(null);
      refetch();
    },
    onError: () => {
      toast.error("Photo upload failed");
      setPhotoUploadingId(null);
    },
  });

  function handlePhotoCapture(id: bigint, dataUrl: string) {
    setPhotoUploadingId(id);
    photoMutation.mutate({ id, dataUrl });
  }

  const sortedMembers = [...members].sort(
    (a, b) => Number(a.orderNumber) - Number(b.orderNumber),
  );

  return (
    <RoleGuard role={role} allowedRoles={["admin"]}>
      <Layout role={role ?? "admin"}>
        {/* Page header */}
        <div
          className="bg-card border-b border-border px-4 py-5"
          data-ocid="society_body.page"
        >
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-primary/10 flex items-center justify-center">
              <Users className="w-6 h-6 text-primary" />
            </div>
            <div>
              <h1
                className="text-2xl font-bold font-display text-foreground"
                data-ocid="society_body.title"
              >
                Society Body Management
              </h1>
              <p className="text-base text-muted-foreground">
                Manage committee members &amp; roles
              </p>
            </div>
          </div>
        </div>

        <div className="p-4 space-y-5 max-w-2xl mx-auto">
          {/* Home page preview */}
          {!isLoading && members.length > 0 && (
            <HomePagePreview members={sortedMembers} />
          )}

          {/* Add member button */}
          {!showAddForm && (
            <Button
              onClick={() => setShowAddForm(true)}
              className="w-full btn-accessible gap-2 h-12 text-base"
              data-ocid="society_body.add_member_button"
            >
              <Plus className="w-5 h-5" />
              Add New Member
            </Button>
          )}

          {/* Add member form */}
          {showAddForm && (
            <Card
              className="shadow-card border-primary/30"
              data-ocid="society_body.add_form_panel"
            >
              <CardHeader className="pb-3">
                <CardTitle className="flex items-center gap-2 text-lg">
                  <UserCheck className="w-5 h-5 text-primary" />
                  Add New Member
                </CardTitle>
              </CardHeader>
              <CardContent>
                <MemberForm
                  onSubmit={(data) => addMutation.mutate(data)}
                  isPending={addMutation.isPending}
                />
                <Button
                  variant="ghost"
                  className="w-full mt-3"
                  onClick={() => setShowAddForm(false)}
                  data-ocid="society_body.cancel_add_button"
                >
                  Cancel
                </Button>
              </CardContent>
            </Card>
          )}

          {/* Members list */}
          <section>
            <h2 className="text-lg font-semibold text-foreground mb-3">
              All Members ({members.length})
            </h2>
            {isLoading ? (
              <div className="space-y-3">
                {[1, 2, 3].map((i) => (
                  <Skeleton key={i} className="h-28 w-full rounded-2xl" />
                ))}
              </div>
            ) : sortedMembers.length === 0 ? (
              <div
                className="text-center py-12 text-muted-foreground"
                data-ocid="society_body.members.empty_state"
              >
                <Users className="w-12 h-12 mx-auto mb-3 opacity-30" />
                <p className="text-base font-medium">No members yet</p>
                <p className="text-sm mt-1">
                  Click the button above to add the first member.
                </p>
              </div>
            ) : (
              <div className="space-y-3" data-ocid="society_body.members.list">
                {sortedMembers.map((m, i) => (
                  <MemberCard
                    key={String(m.id)}
                    member={m}
                    index={i}
                    onEdit={setEditingMember}
                    onDelete={(id) => setConfirmDeleteId(id)}
                    onUploadPhoto={handlePhotoCapture}
                    photoUploading={photoUploadingId}
                  />
                ))}
              </div>
            )}
          </section>
        </div>

        {/* Edit dialog */}
        <Dialog
          open={!!editingMember}
          onOpenChange={(open) => {
            if (!open) setEditingMember(null);
          }}
        >
          <DialogContent
            className="max-w-lg"
            data-ocid="society_body.edit_dialog"
          >
            <DialogHeader>
              <DialogTitle>Edit Member</DialogTitle>
            </DialogHeader>
            {editingMember && (
              <MemberForm
                isEdit
                initial={{
                  nameEnglish: editingMember.nameEnglish,
                  role: editingMember.role as SocietyMemberRole,
                  contactPhone: editingMember.contactPhone ?? "",
                  contactEmail: editingMember.contactEmail ?? "",
                  orderNumber: String(editingMember.orderNumber),
                  isActive: editingMember.isActive,
                }}
                onSubmit={(data) =>
                  updateMutation.mutate({ id: editingMember.id, data })
                }
                isPending={updateMutation.isPending}
              />
            )}
          </DialogContent>
        </Dialog>

        {/* Confirm delete dialog */}
        <Dialog
          open={!!confirmDeleteId}
          onOpenChange={(open) => {
            if (!open) setConfirmDeleteId(null);
          }}
        >
          <DialogContent
            className="max-w-sm"
            data-ocid="society_body.delete_dialog"
          >
            <DialogHeader>
              <DialogTitle className="text-destructive">
                Remove Member?
              </DialogTitle>
            </DialogHeader>
            <p className="text-base text-muted-foreground">
              This member will be removed from the society body.
            </p>
            <div className="flex gap-3 mt-4">
              <Button
                variant="destructive"
                className="flex-1 btn-accessible"
                onClick={() =>
                  confirmDeleteId && deleteMutation.mutate(confirmDeleteId)
                }
                disabled={deleteMutation.isPending}
                data-ocid="society_body.confirm_delete_button"
              >
                {deleteMutation.isPending ? "Removing…" : "Yes, Remove"}
              </Button>
              <Button
                variant="outline"
                className="flex-1 btn-accessible"
                onClick={() => setConfirmDeleteId(null)}
                data-ocid="society_body.cancel_delete_button"
              >
                Cancel
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </Layout>
    </RoleGuard>
  );
}
