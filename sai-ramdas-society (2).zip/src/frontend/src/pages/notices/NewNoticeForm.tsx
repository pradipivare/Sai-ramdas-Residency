import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";
import { AlertTriangle, CalendarDays, FileText, X } from "lucide-react";
import type { KeyboardEvent } from "react";
import { useState } from "react";
import { useActor } from "../../lib/backend-client";
import { NoticeType } from "../../types";

interface NewNoticeFormProps {
  onClose: () => void;
  onSuccess: () => void;
}

const NOTICE_TYPES: {
  value: NoticeType;
  label: string;
  description: string;
  icon: React.ReactNode;
}[] = [
  {
    value: NoticeType.regular,
    label: "Regular",
    description: "General society update",
    icon: <FileText className="w-5 h-5" />,
  },
  {
    value: NoticeType.event,
    label: "Event",
    description: "Meeting or activity",
    icon: <CalendarDays className="w-5 h-5" />,
  },
  {
    value: NoticeType.emergency,
    label: "Emergency",
    description: "Urgent alert for all",
    icon: <AlertTriangle className="w-5 h-5" />,
  },
];

export function NewNoticeForm({ onClose, onSuccess }: NewNoticeFormProps) {
  const { actor } = useActor();

  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");
  const [noticeType, setNoticeType] = useState<NoticeType>(NoticeType.regular);
  const [isPinned, setIsPinned] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const titleTouched = title.length > 0;
  const contentTouched = content.length > 0;
  const titleError =
    title.trim().length === 0
      ? "Title is required"
      : title.length > 200
        ? "Title too long (max 200 chars)"
        : null;
  const contentError =
    content.trim().length === 0 ? "Content is required" : null;
  const canSubmit = !titleError && !contentError && !submitting;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!canSubmit || !actor) return;
    setSubmitting(true);
    setError(null);
    try {
      await actor.createNotice(
        title.trim(),
        content.trim(),
        noticeType,
        isPinned,
      );
      onSuccess();
    } catch (err) {
      console.error("Failed to create notice", err);
      setError("Failed to post notice. Please try again.");
    } finally {
      setSubmitting(false);
    }
  };

  const handleBackdropKey = (e: KeyboardEvent<HTMLDivElement>) => {
    if (e.key === "Escape") onClose();
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center"
      data-ocid="notices.dialog"
    >
      {/* Backdrop */}
      <div
        className="absolute inset-0 bg-foreground/30 backdrop-blur-sm"
        aria-hidden="true"
        role="button"
        tabIndex={-1}
        onClick={onClose}
        onKeyDown={handleBackdropKey}
      />

      {/* Panel */}
      <dialog
        open
        className="relative bg-card w-full sm:max-w-lg rounded-t-3xl sm:rounded-2xl border border-border shadow-card max-h-[92dvh] overflow-y-auto m-0 p-0"
        aria-labelledby="new-notice-title"
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-5 border-b border-border">
          <h2
            id="new-notice-title"
            className="font-display font-bold text-2xl text-foreground"
          >
            Post New Notice
          </h2>
          <button
            type="button"
            onClick={onClose}
            data-ocid="notices.close_button"
            aria-label="Close form"
            className="touch-target flex items-center justify-center rounded-xl hover:bg-muted transition-smooth text-muted-foreground hover:text-foreground"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        <form
          onSubmit={handleSubmit}
          className="px-6 py-5 flex flex-col gap-6"
          noValidate
        >
          {/* Notice Type */}
          <fieldset className="flex flex-col gap-3">
            <legend className="text-base font-semibold text-foreground">
              Notice Type
            </legend>
            <div className="grid grid-cols-3 gap-2">
              {NOTICE_TYPES.map(({ value, label, description, icon }) => {
                const selected = noticeType === value;
                const isEmergency = value === NoticeType.emergency;
                return (
                  <label
                    key={value}
                    className={`flex flex-col items-center gap-1.5 p-3 rounded-xl border-2 transition-smooth text-center cursor-pointer min-h-[48px] ${
                      selected
                        ? isEmergency
                          ? "border-destructive bg-destructive/10 text-destructive"
                          : "border-primary bg-primary/10 text-primary"
                        : "border-border bg-background text-muted-foreground hover:border-primary/50"
                    }`}
                  >
                    <input
                      type="radio"
                      name="noticeType"
                      value={value}
                      checked={selected}
                      onChange={() => setNoticeType(value)}
                      data-ocid={`notices.type_${value}_radio`}
                      className="sr-only"
                    />
                    <span
                      className={
                        selected && isEmergency
                          ? "text-destructive"
                          : selected
                            ? "text-primary"
                            : ""
                      }
                    >
                      {icon}
                    </span>
                    <span className="text-sm font-semibold leading-tight">
                      {label}
                    </span>
                    <span className="text-xs leading-tight opacity-80 hidden sm:block">
                      {description}
                    </span>
                  </label>
                );
              })}
            </div>
          </fieldset>

          {/* Title */}
          <div className="flex flex-col gap-2">
            <Label
              htmlFor="notice-title"
              className="text-base font-semibold text-foreground"
            >
              Title <span className="text-destructive">*</span>
            </Label>
            <Input
              id="notice-title"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="E.g. Water Supply Shutdown on Sunday"
              data-ocid="notices.title_input"
              className="text-base h-12 border-2"
              maxLength={200}
            />
            {titleTouched && titleError && (
              <p
                className="text-destructive text-sm"
                data-ocid="notices.title_field_error"
                role="alert"
              >
                {titleError}
              </p>
            )}
          </div>

          {/* Content */}
          <div className="flex flex-col gap-2">
            <Label
              htmlFor="notice-content"
              className="text-base font-semibold text-foreground"
            >
              Content <span className="text-destructive">*</span>
            </Label>
            <Textarea
              id="notice-content"
              value={content}
              onChange={(e) => setContent(e.target.value)}
              placeholder="Write the full notice here. Be clear and specific for residents."
              data-ocid="notices.content_textarea"
              className="text-base border-2 resize-none min-h-[140px] leading-relaxed"
              rows={5}
            />
            {contentTouched && contentError && (
              <p
                className="text-destructive text-sm"
                data-ocid="notices.content_field_error"
                role="alert"
              >
                {contentError}
              </p>
            )}
          </div>

          {/* Pin toggle */}
          <div className="flex items-center justify-between p-4 rounded-xl bg-muted/50 border border-border">
            <div className="flex flex-col gap-0.5">
              <Label
                htmlFor="pin-toggle"
                className="text-base font-semibold text-foreground cursor-pointer"
              >
                Pin this notice
              </Label>
              <p className="text-sm text-muted-foreground">
                Pinned notices always appear at the top
              </p>
            </div>
            <Switch
              id="pin-toggle"
              checked={isPinned}
              onCheckedChange={setIsPinned}
              data-ocid="notices.pin_switch"
            />
          </div>

          {/* Emergency warning */}
          {noticeType === NoticeType.emergency && (
            <div className="p-4 rounded-xl bg-destructive/10 border-2 border-destructive flex items-start gap-3">
              <AlertTriangle className="w-5 h-5 text-destructive mt-0.5 flex-shrink-0" />
              <p className="text-sm text-destructive font-medium leading-relaxed">
                Emergency notices are highlighted in red and shown at the top of
                the board. Use only for urgent situations.
              </p>
            </div>
          )}

          {/* Submission error */}
          {error && (
            <div
              data-ocid="notices.error_state"
              className="p-4 rounded-xl bg-destructive/10 border border-destructive text-destructive text-base font-medium"
              role="alert"
            >
              {error}
            </div>
          )}

          {/* Actions */}
          <div className="flex gap-3 pt-1 pb-2">
            <Button
              type="button"
              variant="outline"
              onClick={onClose}
              data-ocid="notices.cancel_button"
              className="flex-1 btn-accessible text-base"
            >
              Cancel
            </Button>
            <Button
              type="submit"
              disabled={!canSubmit}
              data-ocid="notices.submit_button"
              variant={
                noticeType === NoticeType.emergency ? "destructive" : "default"
              }
              className="flex-1 btn-accessible text-base font-semibold"
            >
              {submitting ? "Posting…" : "Post Notice"}
            </Button>
          </div>
        </form>
      </dialog>
    </div>
  );
}
