import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { useQueryClient } from "@tanstack/react-query";
import {
  AlertTriangle,
  CalendarDays,
  ChevronDown,
  ChevronUp,
  FileText,
  Pin,
  Plus,
  Trash2,
} from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { Layout } from "../../components/Layout";
import { EmptyState } from "../../components/ui/EmptyState";
import { PageHeader } from "../../components/ui/PageHeader";
import { useRole } from "../../hooks/use-role";
import { formatDate, useAllNotices } from "../../hooks/useQueries";
import { useActor } from "../../lib/backend-client";
import type { AppRole, Notice } from "../../types";
import { NoticeType } from "../../types";
import { NewNoticeForm } from "./NewNoticeForm";

// ─── Category Badge ───────────────────────────────────────────────────────────

function NoticeTypeBadge({ type }: { type: NoticeType }) {
  if (type === NoticeType.emergency) {
    return (
      <Badge className="bg-destructive text-destructive-foreground text-xs px-2 py-0.5 font-bold gap-1">
        <AlertTriangle className="w-3 h-3" />
        Emergency
      </Badge>
    );
  }
  if (type === NoticeType.event) {
    return (
      <Badge variant="secondary" className="text-xs px-2 py-0.5 gap-1">
        <CalendarDays className="w-3 h-3" />
        Event
      </Badge>
    );
  }
  return (
    <Badge variant="outline" className="text-xs px-2 py-0.5 gap-1">
      <FileText className="w-3 h-3" />
      Notice
    </Badge>
  );
}

// ─── Compact Notice Row ───────────────────────────────────────────────────────

function NoticeRow({
  notice,
  canManage,
  onDelete,
  deleting,
  index,
}: {
  notice: Notice;
  canManage: boolean;
  onDelete: (id: bigint) => void;
  deleting: bigint | null;
  index: number;
}) {
  const [expanded, setExpanded] = useState(false);
  const isEmergency = notice.noticeType === NoticeType.emergency;

  return (
    <div
      className={`border-b border-border last:border-0 ${isEmergency ? "bg-destructive/5" : ""}`}
      data-ocid={`notices.item.${index}`}
    >
      <button
        type="button"
        className="flex items-center gap-3 px-3 py-2.5 w-full text-left hover:bg-muted/20 transition-colors"
        onClick={() => setExpanded((v) => !v)}
        aria-expanded={expanded}
      >
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            <NoticeTypeBadge type={notice.noticeType} />
            {notice.isPinned && (
              <Pin className="w-3 h-3 text-primary flex-shrink-0" />
            )}
            <span
              className={`font-semibold text-base leading-tight truncate ${isEmergency ? "text-destructive" : "text-foreground"}`}
            >
              {notice.title}
            </span>
          </div>
          <span className="text-xs text-muted-foreground mt-0.5 block">
            {formatDate(notice.postedAt)}
          </span>
        </div>
        <div className="flex-shrink-0 text-muted-foreground">
          {expanded ? (
            <ChevronUp className="w-4 h-4" />
          ) : (
            <ChevronDown className="w-4 h-4" />
          )}
        </div>
      </button>

      {expanded && (
        <div className="px-3 pb-3">
          <p className="text-base text-foreground leading-relaxed whitespace-pre-wrap break-words">
            {notice.content}
          </p>
          {canManage && (
            <div className="mt-3 flex justify-end">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => onDelete(notice.noticeId)}
                disabled={deleting === notice.noticeId}
                data-ocid={`notices.delete_button.${index}`}
                className="text-destructive hover:text-destructive hover:bg-destructive/10 gap-1.5 h-9 text-sm"
                aria-label={`Delete notice: ${notice.title}`}
              >
                <Trash2 className="w-4 h-4" />
                {deleting === notice.noticeId ? "Removing…" : "Remove"}
              </Button>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

// ─── Loading Skeleton ─────────────────────────────────────────────────────────

function LoadingSkeleton() {
  return (
    <div className="space-y-1" data-ocid="notices.loading_state">
      {[1, 2, 3, 4].map((i) => (
        <Skeleton key={i} className="h-14 rounded-lg" />
      ))}
    </div>
  );
}

// ─── Main Page ────────────────────────────────────────────────────────────────

export default function NoticesPage() {
  const { getRole } = useRole();
  const role = getRole() as AppRole | null;
  const { data: notices, isLoading, error } = useAllNotices();
  const { actor } = useActor();
  const queryClient = useQueryClient();

  const [showForm, setShowForm] = useState(false);
  const [deleting, setDeleting] = useState<bigint | null>(null);

  const canManage = role === "admin" || role === "committee";

  const handleDelete = async (noticeId: bigint) => {
    if (!actor) return;
    setDeleting(noticeId);
    try {
      await actor.deleteNotice(noticeId);
      await queryClient.invalidateQueries({ queryKey: ["notices"] });
      toast.info("Notice removed", { duration: 4000 });
    } catch {
      toast.error("Failed to remove notice. Please try again.", {
        duration: 4000,
      });
    } finally {
      setDeleting(null);
    }
  };

  const sortedNotices = notices
    ? [...notices].sort((a, b) => {
        if (a.isPinned && !b.isPinned) return -1;
        if (!a.isPinned && b.isPinned) return 1;
        return Number(b.postedAt - a.postedAt);
      })
    : [];

  const emergencyNotices = sortedNotices.filter(
    (n) => n.noticeType === NoticeType.emergency,
  );
  const otherNotices = sortedNotices.filter(
    (n) => n.noticeType !== NoticeType.emergency,
  );

  if (!role) return null;

  return (
    <Layout role={role}>
      <PageHeader
        title="Notice Board"
        subtitle="Society announcements, events & emergency notices"
        icon="📌"
        actions={
          canManage ? (
            <Button
              onClick={() => setShowForm(true)}
              data-ocid="notices.post_notice_button"
              className="btn-accessible gap-2"
            >
              <Plus className="w-5 h-5" />
              Post Notice
            </Button>
          ) : undefined
        }
      />

      <div className="px-4 py-4 max-w-2xl mx-auto space-y-4">
        {/* New Notice Form */}
        {showForm && (
          <NewNoticeForm
            onClose={() => setShowForm(false)}
            onSuccess={() => {
              setShowForm(false);
              void queryClient.invalidateQueries({ queryKey: ["notices"] });
              toast.success("New notice posted!", { duration: 4000 });
            }}
          />
        )}

        {isLoading && <LoadingSkeleton />}

        {error && (
          <div
            data-ocid="notices.error_state"
            className="rounded-xl border border-destructive bg-destructive/5 p-4 text-center"
          >
            <p className="text-destructive font-semibold text-base">
              Failed to load notices. Please refresh.
            </p>
          </div>
        )}

        {!isLoading && !error && sortedNotices.length === 0 && (
          <EmptyState
            icon="📌"
            title="No notices yet"
            description="Society notices will appear here."
            action={
              canManage
                ? {
                    label: "Post First Notice",
                    onClick: () => setShowForm(true),
                  }
                : undefined
            }
          />
        )}

        {/* Emergency notices */}
        {!isLoading && emergencyNotices.length > 0 && (
          <section
            aria-label="Emergency notices"
            data-ocid="notices.emergency_section"
          >
            <h2 className="flex items-center gap-2 text-destructive font-bold font-display text-lg mb-2">
              <AlertTriangle className="w-5 h-5" />
              Emergency Notices
            </h2>
            <div className="border border-destructive/40 rounded-xl overflow-hidden bg-destructive/5">
              {emergencyNotices.map((notice, i) => (
                <NoticeRow
                  key={String(notice.noticeId)}
                  notice={notice}
                  canManage={canManage}
                  onDelete={handleDelete}
                  deleting={deleting}
                  index={i + 1}
                />
              ))}
            </div>
          </section>
        )}

        {/* Regular notices */}
        {!isLoading && otherNotices.length > 0 && (
          <section aria-label="All notices" data-ocid="notices.main_section">
            {emergencyNotices.length > 0 && (
              <h2 className="font-bold font-display text-lg mb-2 text-foreground">
                All Notices
              </h2>
            )}
            <div className="border border-border rounded-xl overflow-hidden bg-card">
              {otherNotices.map((notice, i) => (
                <NoticeRow
                  key={String(notice.noticeId)}
                  notice={notice}
                  canManage={canManage}
                  onDelete={handleDelete}
                  deleting={deleting}
                  index={emergencyNotices.length + i + 1}
                />
              ))}
            </div>
          </section>
        )}
      </div>
    </Layout>
  );
}
