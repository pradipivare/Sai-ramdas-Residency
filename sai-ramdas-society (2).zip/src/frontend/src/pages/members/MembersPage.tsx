import { EmptyState } from "@/components/ui/EmptyState";
import { PageHeader } from "@/components/ui/PageHeader";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { useActor } from "@/lib/backend-client";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useNavigate } from "@tanstack/react-router";
import { Search, Trash2, UserPlus } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { Layout } from "../../components/Layout";
import { useRole } from "../../hooks/use-role";
import type { AppRole, Resident } from "../../types";
import { ResidencyType } from "../../types";

export default function MembersPage() {
  const { getRole } = useRole();
  const role = getRole() as AppRole | null;
  const navigate = useNavigate();
  const { actor, isFetching } = useActor();
  const queryClient = useQueryClient();
  const [search, setSearch] = useState("");

  const { data: residents, isLoading } = useQuery<Resident[]>({
    queryKey: ["residents"],
    queryFn: async () => {
      if (!actor) return [];
      return actor.getAllResidents();
    },
    enabled: !!actor && !isFetching,
  });

  const deleteMutation = useMutation({
    mutationFn: async (residentId: bigint) => {
      if (!actor) throw new Error("No actor");
      await actor.deleteResident(residentId);
    },
    onSuccess: () => {
      void queryClient.invalidateQueries({ queryKey: ["residents"] });
      toast.success("Resident removed");
    },
    onError: () => toast.error("Failed to remove resident"),
  });

  if (!role) return null;

  const filtered = (residents ?? []).filter((r) => {
    const q = search.toLowerCase();
    return (
      r.name.toLowerCase().includes(q) ||
      r.flatNumber.toLowerCase().includes(q) ||
      r.mobile.includes(q)
    );
  });

  const isAdmin = role === "admin";

  return (
    <Layout role={role}>
      <PageHeader
        title="Residents"
        subtitle={`${residents?.length ?? 0} residents registered`}
        icon="👥"
        actions={
          isAdmin ? (
            <Button
              className="btn-accessible gap-2"
              onClick={() => void navigate({ to: "/residents/add" })}
              data-ocid="members.add_button"
            >
              <UserPlus className="w-5 h-5" />
              Add
            </Button>
          ) : undefined
        }
      />

      <div className="px-4 pt-3 pb-1">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="Search by name, flat, mobile…"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-9 h-10 text-base"
            data-ocid="members.search_input"
          />
        </div>
      </div>

      {/* Loading */}
      {isLoading && (
        <div className="px-4 pt-2 space-y-1" data-ocid="members.loading_state">
          {[1, 2, 3, 4, 5].map((i) => (
            <Skeleton key={i} className="h-12 w-full rounded-lg" />
          ))}
        </div>
      )}

      {/* Empty state */}
      {!isLoading && filtered.length === 0 && (
        <div className="px-4 pt-4">
          <EmptyState
            icon="👥"
            title={search ? "No resident found" : "No residents yet"}
            description={
              search
                ? "Try a different name or flat number."
                : isAdmin
                  ? "Click the button above to add the first resident."
                  : "No residents registered yet."
            }
            action={
              isAdmin && !search
                ? {
                    label: "Add First Resident",
                    onClick: () => void navigate({ to: "/residents/add" }),
                  }
                : undefined
            }
          />
        </div>
      )}

      {/* Compact resident list */}
      {!isLoading && filtered.length > 0 && (
        <div className="px-4 pt-2 pb-4" data-ocid="members.list">
          <div className="divide-y divide-border border border-border rounded-xl overflow-hidden bg-card">
            {filtered.map((resident, idx) => (
              <ResidentRow
                key={String(resident.residentId)}
                resident={resident}
                index={idx + 1}
                isAdmin={isAdmin}
                onView={() =>
                  void navigate({ to: `/residents/${resident.flatNumber}` })
                }
                onDelete={() => deleteMutation.mutate(resident.residentId)}
                isDeleting={deleteMutation.isPending}
              />
            ))}
          </div>
        </div>
      )}
    </Layout>
  );
}

interface ResidentRowProps {
  resident: Resident;
  index: number;
  isAdmin: boolean;
  onView: () => void;
  onDelete: () => void;
  isDeleting: boolean;
}

function ResidentRow({
  resident,
  index,
  isAdmin,
  onView,
  onDelete,
  isDeleting,
}: ResidentRowProps) {
  const isOwner = resident.residencyType === ResidencyType.owner;

  return (
    <div
      className="flex items-center gap-3 px-3 py-2.5 hover:bg-muted/30 transition-colors"
      data-ocid={`members.item.${index}`}
    >
      {/* Clickable area: avatar + name + flat */}
      <button
        type="button"
        className="flex items-center gap-3 flex-1 min-w-0 text-left"
        onClick={onView}
      >
        {/* Avatar */}
        <div className="w-9 h-9 rounded-full bg-primary/10 flex items-center justify-center text-base font-bold text-primary border border-primary/20 flex-shrink-0">
          {resident.name.charAt(0).toUpperCase()}
        </div>

        {/* Name + flat */}
        <div className="flex-1 min-w-0">
          <p className="font-semibold text-base text-foreground truncate leading-tight">
            {resident.name}
          </p>
          <p className="text-sm text-muted-foreground">
            Flat {resident.flatNumber}
          </p>
        </div>
      </button>

      {/* Role badge */}
      <Badge
        variant={isOwner ? "default" : "secondary"}
        className="text-xs flex-shrink-0"
      >
        {isOwner ? "Owner" : "Tenant"}
      </Badge>

      {/* Delete button (admin only) */}
      {isAdmin && (
        <AlertDialog>
          <AlertDialogTrigger asChild>
            <Button
              variant="ghost"
              size="sm"
              className="h-8 w-8 p-0 text-destructive hover:bg-destructive/10 flex-shrink-0"
              aria-label={`Remove ${resident.name}`}
              data-ocid={`members.delete_button.${index}`}
              disabled={isDeleting}
              onClick={(e) => e.stopPropagation()}
            >
              <Trash2 className="w-4 h-4" />
            </Button>
          </AlertDialogTrigger>
          <AlertDialogContent
            data-ocid="members.dialog"
            onClick={(e) => e.stopPropagation()}
          >
            <AlertDialogHeader>
              <AlertDialogTitle className="text-xl">
                Remove Resident?
              </AlertDialogTitle>
              <AlertDialogDescription className="text-base">
                <strong>{resident.name}</strong> (Flat {resident.flatNumber})
                will be permanently removed. This action cannot be undone.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel
                className="btn-accessible"
                data-ocid="members.cancel_button"
              >
                Cancel
              </AlertDialogCancel>
              <AlertDialogAction
                onClick={onDelete}
                className="btn-accessible bg-destructive text-destructive-foreground hover:bg-destructive/90"
                data-ocid="members.confirm_button"
              >
                Yes, Remove
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      )}
    </div>
  );
}
