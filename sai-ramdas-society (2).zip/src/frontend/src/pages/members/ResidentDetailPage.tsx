import { EmptyState } from "@/components/ui/EmptyState";
import { PageHeader } from "@/components/ui/PageHeader";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { Skeleton } from "@/components/ui/skeleton";
import { useActor } from "@/lib/backend-client";
import { useQuery } from "@tanstack/react-query";
import { useNavigate, useParams } from "@tanstack/react-router";
import {
  ArrowLeft,
  Building2,
  Download,
  Mail,
  Pencil,
  Phone,
  Users,
} from "lucide-react";
import { Layout } from "../../components/Layout";
import { useRole } from "../../hooks/use-role";
import type { AppRole, Flat, Resident } from "../../types";
import { ResidencyType } from "../../types";

export default function ResidentDetailPage() {
  const { getRole } = useRole();
  const role = getRole() as AppRole | null;
  const navigate = useNavigate();
  // TanStack Router provides params via useParams with a from path
  const params = useParams({ strict: false }) as { flatNumber?: string };
  const flatNumber = params.flatNumber ?? "";
  const { actor, isFetching } = useActor();

  const { data: resident, isLoading: residentLoading } =
    useQuery<Resident | null>({
      queryKey: ["resident", flatNumber],
      queryFn: async () => {
        if (!actor || !flatNumber) return null;
        return actor.getResidentByFlat(flatNumber);
      },
      enabled: !!actor && !isFetching && !!flatNumber,
    });

  const { data: flatDetails, isLoading: flatLoading } = useQuery<Flat | null>({
    queryKey: ["flat", flatNumber],
    queryFn: async () => {
      if (!actor || !flatNumber) return null;
      return actor.getFlatDetails(flatNumber);
    },
    enabled: !!actor && !isFetching && !!flatNumber,
  });

  if (!role) return null;

  const isAdmin = role === "admin";
  const isLoading = residentLoading || flatLoading;

  return (
    <Layout role={role}>
      <PageHeader
        title={resident ? resident.name : "Resident Details"}
        subtitle={flatNumber ? `Flat ${flatNumber}` : "Loading..."}
        icon="👤"
        actions={
          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              onClick={() => void navigate({ to: "/residents" })}
              className="btn-accessible gap-2"
              data-ocid="resident_detail.back_button"
            >
              <ArrowLeft className="w-4 h-4" />
              Back
            </Button>
            {isAdmin && resident && (
              <Button
                onClick={() =>
                  void navigate({ to: `/residents/edit/${flatNumber}` })
                }
                className="btn-accessible gap-2"
                data-ocid="resident_detail.edit_button"
              >
                <Pencil className="w-4 h-4" />
                Edit
              </Button>
            )}
          </div>
        }
      />

      <div className="p-4 max-w-2xl mx-auto space-y-4">
        {/* Loading skeleton */}
        {isLoading && (
          <div className="space-y-3" data-ocid="resident_detail.loading_state">
            <Skeleton className="h-40 w-full rounded-xl" />
            <Skeleton className="h-32 w-full rounded-xl" />
            <Skeleton className="h-24 w-full rounded-xl" />
          </div>
        )}

        {/* Not found */}
        {!isLoading && !resident && (
          <EmptyState
            icon="🔍"
            title="Resident Not Found"
            description={`No resident is registered for flat ${flatNumber}.`}
            action={{
              label: "Back to Residents",
              onClick: () => void navigate({ to: "/residents" }),
            }}
          />
        )}

        {/* Resident info */}
        {!isLoading && resident && (
          <>
            {/* Profile card */}
            <Card className="shadow-card" data-ocid="resident_detail.card">
              <CardContent className="p-6">
                <div className="flex items-start gap-4">
                  {/* Avatar */}
                  <div className="w-16 h-16 rounded-full bg-primary/10 border-2 border-primary/20 flex items-center justify-center text-3xl font-bold text-primary flex-shrink-0">
                    {resident.name.charAt(0).toUpperCase()}
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="flex items-start justify-between gap-2 flex-wrap">
                      <div>
                        <h2 className="text-2xl font-bold font-display text-foreground leading-tight">
                          {resident.name}
                        </h2>
                        <div className="flex items-center gap-2 mt-1 flex-wrap">
                          <Badge
                            variant={
                              resident.residencyType === ResidencyType.owner
                                ? "default"
                                : "secondary"
                            }
                            className="text-sm px-3 py-1"
                          >
                            {resident.residencyType === ResidencyType.owner
                              ? "🏠 Owner"
                              : "🔑 Tenant"}
                          </Badge>
                          <Badge
                            variant="outline"
                            className="text-sm px-3 py-1"
                          >
                            Flat {resident.flatNumber}
                          </Badge>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <Separator className="my-5" />

                {/* Contact details */}
                <div className="space-y-4">
                  <h3 className="font-semibold text-base text-muted-foreground uppercase tracking-wide text-sm">
                    Contact Information
                  </h3>
                  <InfoRow
                    icon={<Phone className="w-5 h-5 text-primary" />}
                    label="Mobile"
                    value={resident.mobile}
                    href={`tel:${resident.mobile}`}
                  />
                  {resident.email && (
                    <InfoRow
                      icon={<Mail className="w-5 h-5 text-primary" />}
                      label="Email"
                      value={resident.email}
                      href={`mailto:${resident.email}`}
                    />
                  )}
                  <InfoRow
                    icon={<Building2 className="w-5 h-5 text-primary" />}
                    label="Flat Number"
                    value={resident.flatNumber}
                  />
                  <InfoRow
                    icon={<Users className="w-5 h-5 text-primary" />}
                    label="Family Members"
                    value={`${String(resident.familyMembersCount)} member${resident.familyMembersCount !== 1n ? "s" : ""}`}
                  />
                </div>
              </CardContent>
            </Card>

            {/* Flat details card */}
            {flatDetails && (
              <Card className="shadow-card">
                <CardContent className="p-6">
                  <h3 className="font-semibold font-display text-lg text-foreground mb-4">
                    🏢 Flat Details
                  </h3>
                  <div className="grid grid-cols-2 gap-4">
                    <DetailBlock label="Wing" value={flatDetails.wing} />
                    <DetailBlock
                      label="Floor"
                      value={String(flatDetails.floor)}
                    />
                    <DetailBlock
                      label="Flat Number"
                      value={flatDetails.flatNumber}
                    />
                    <DetailBlock
                      label="Owner Name"
                      value={flatDetails.ownerName}
                    />
                  </div>
                </CardContent>
              </Card>
            )}

            {/* KYC document */}
            <Card className="shadow-card">
              <CardContent className="p-6">
                <h3 className="font-semibold font-display text-lg text-foreground mb-4">
                  📄 KYC Document
                </h3>
                {resident.kycDocumentId ? (
                  <div className="flex items-center justify-between gap-3 p-4 bg-muted/40 rounded-xl border border-border">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center text-xl">
                        📎
                      </div>
                      <div>
                        <p className="font-medium text-foreground">
                          ID Proof Document
                        </p>
                        <p className="text-sm text-muted-foreground">
                          Uploaded successfully
                        </p>
                      </div>
                    </div>
                    <Button
                      variant="outline"
                      onClick={() => {
                        if (resident.kycDocumentId) {
                          const url = resident.kycDocumentId.getDirectURL();
                          window.open(url, "_blank", "noopener,noreferrer");
                        }
                      }}
                      className="btn-accessible gap-2"
                      data-ocid="resident_detail.kyc_download_button"
                    >
                      <Download className="w-4 h-4" />
                      View / Download
                    </Button>
                  </div>
                ) : (
                  <div className="flex items-center gap-3 p-4 bg-muted/30 rounded-xl border border-dashed border-border text-muted-foreground">
                    <span className="text-2xl">📭</span>
                    <div>
                      <p className="font-medium">No KYC document uploaded</p>
                      {isAdmin && (
                        <p className="text-sm">
                          Edit this resident to upload an ID proof.
                        </p>
                      )}
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Admin actions */}
            {isAdmin && (
              <div className="flex gap-3 pb-4">
                <Button
                  variant="outline"
                  onClick={() =>
                    void navigate({ to: `/residents/edit/${flatNumber}` })
                  }
                  className="btn-accessible flex-1 gap-2"
                  data-ocid="resident_detail.edit_primary_button"
                >
                  <Pencil className="w-5 h-5" />
                  Edit Resident
                </Button>
              </div>
            )}
          </>
        )}
      </div>
    </Layout>
  );
}

function InfoRow({
  icon,
  label,
  value,
  href,
}: {
  icon: React.ReactNode;
  label: string;
  value: string;
  href?: string;
}) {
  return (
    <div className="flex items-center gap-3 min-h-[44px]">
      <div className="w-9 h-9 rounded-lg bg-muted/60 flex items-center justify-center flex-shrink-0">
        {icon}
      </div>
      <div className="min-w-0">
        <p className="text-xs text-muted-foreground uppercase tracking-wide">
          {label}
        </p>
        {href ? (
          <a
            href={href}
            className="font-medium text-base text-primary hover:underline break-all"
          >
            {value}
          </a>
        ) : (
          <p className="font-medium text-base text-foreground break-all">
            {value}
          </p>
        )}
      </div>
    </div>
  );
}

function DetailBlock({ label, value }: { label: string; value: string }) {
  return (
    <div className="space-y-1">
      <p className="text-xs text-muted-foreground uppercase tracking-wide">
        {label}
      </p>
      <p className="font-semibold text-base text-foreground">{value}</p>
    </div>
  );
}
