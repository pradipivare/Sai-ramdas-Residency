import { PageHeader } from "@/components/ui/PageHeader";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useActor } from "@/lib/backend-client";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useNavigate, useParams } from "@tanstack/react-router";
import { ArrowLeft, Camera, Save, Upload, X } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { toast } from "sonner";
import type { ExternalBlob } from "../../backend";
import { Layout } from "../../components/Layout";
import { useRole } from "../../hooks/use-role";
import type { AppRole, Flat, Resident } from "../../types";
import { ResidencyType } from "../../types";

interface FormData {
  name: string;
  mobile: string;
  email: string;
  wing: string;
  floor: string;
  flatNumber: string;
  residencyType: ResidencyType;
  familyMembersCount: string;
}

const EMPTY_FORM: FormData = {
  name: "",
  mobile: "",
  email: "",
  wing: "",
  floor: "",
  flatNumber: "",
  residencyType: ResidencyType.owner,
  familyMembersCount: "1",
};

interface ResidentFormProps {
  editResident?: Resident;
}

export default function ResidentForm({
  editResident: editResidentProp,
}: ResidentFormProps) {
  const { getRole } = useRole();
  const role = getRole() as AppRole | null;
  const navigate = useNavigate();
  const { actor, isFetching } = useActor();
  const queryClient = useQueryClient();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const photoInputRef = useRef<HTMLInputElement>(null);
  const cameraInputRef = useRef<HTMLInputElement>(null);

  const params = useParams({ strict: false }) as { flatNumber?: string };
  const editFlatNumber = params.flatNumber;

  const { data: fetchedResident } = useQuery<Resident | null>({
    queryKey: ["resident", editFlatNumber],
    queryFn: async () => {
      if (!actor || !editFlatNumber) return null;
      return actor.getResidentByFlat(editFlatNumber);
    },
    enabled: !!actor && !isFetching && !!editFlatNumber && !editResidentProp,
  });

  const editResident = editResidentProp ?? fetchedResident ?? undefined;
  const isEditing = !!editResident;

  const [form, setForm] = useState<FormData>(EMPTY_FORM);
  const [errors, setErrors] = useState<Partial<FormData>>({});
  const [kycFile, setKycFile] = useState<File | null>(null);
  const [photoFile, setPhotoFile] = useState<File | null>(null);
  const [photoPreview, setPhotoPreview] = useState<string | null>(null);
  const [formInitialized, setFormInitialized] = useState(false);

  // Pre-fill form when editing — populates all fields from existing resident data
  useEffect(() => {
    if (editResident && !formInitialized) {
      const flatParts = editResident.flatNumber.split("-");
      setForm({
        name: editResident.name,
        mobile: editResident.mobile,
        email: editResident.email ?? "",
        wing: flatParts[0] ?? "",
        floor: flatParts[1] ?? "",
        flatNumber: editResident.flatNumber,
        residencyType: editResident.residencyType,
        familyMembersCount: String(editResident.familyMembersCount),
      });
      if (editResident.photoId) {
        setPhotoPreview(editResident.photoId);
      }
      setFormInitialized(true);
    }
  }, [editResident, formInitialized]);

  const { data: flats } = useQuery<Flat[]>({
    queryKey: ["flats"],
    queryFn: async () => {
      if (!actor) return [];
      return actor.getAllFlats();
    },
    enabled: !!actor && !isFetching,
  });

  useEffect(() => {
    if (!isEditing && form.wing && form.floor) {
      setForm((prev) => ({
        ...prev,
        flatNumber: `${prev.wing}-${prev.floor}`,
      }));
    }
  }, [form.wing, form.floor, isEditing]);

  function handlePhotoChange(file: File) {
    setPhotoFile(file);
    const reader = new FileReader();
    reader.onload = (e) => setPhotoPreview(e.target?.result as string);
    reader.readAsDataURL(file);
  }

  function validate(): boolean {
    const newErrors: Partial<FormData> = {};
    if (!form.name.trim()) newErrors.name = "Name is required";
    if (!form.mobile.trim()) newErrors.mobile = "Mobile number is required";
    else if (!/^\d{10}$/.test(form.mobile.trim()))
      newErrors.mobile = "Enter a valid 10-digit mobile number";
    if (form.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email))
      newErrors.email = "Enter a valid email address";
    if (!form.flatNumber.trim())
      newErrors.flatNumber = "Flat number is required";
    const count = Number.parseInt(form.familyMembersCount, 10);
    if (Number.isNaN(count) || count < 1)
      newErrors.familyMembersCount = "Minimum 1 family member required";
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  }

  async function uploadPhoto(): Promise<string | null> {
    if (!photoFile) return null;
    const reader = new FileReader();
    return new Promise((resolve) => {
      reader.onload = (e) => resolve(e.target?.result as string);
      reader.readAsDataURL(photoFile);
    });
  }

  const addMutation = useMutation({
    mutationFn: async () => {
      if (!actor) throw new Error("No actor");
      let kycBlob: ExternalBlob | null = null;
      if (kycFile) {
        const { ExternalBlob: EB } = await import("../../backend");
        const bytes = new Uint8Array(await kycFile.arrayBuffer());
        kycBlob = EB.fromBytes(bytes);
      }
      const photoId = await uploadPhoto();
      return actor.addResident(
        form.flatNumber.trim(),
        form.name.trim(),
        form.mobile.trim(),
        form.email.trim(),
        form.residencyType,
        BigInt(Number.parseInt(form.familyMembersCount, 10)),
        kycBlob,
        photoId,
      );
    },
    onSuccess: () => {
      void queryClient.invalidateQueries({ queryKey: ["residents"] });
      toast.success("Resident added successfully!");
      void navigate({ to: "/residents" });
    },
    onError: () => toast.error("Failed to add resident. Please try again."),
  });

  const updateMutation = useMutation({
    mutationFn: async () => {
      if (!actor || !editResident) throw new Error("No actor");
      let kycBlob = editResident.kycDocumentId;
      if (kycFile) {
        const { ExternalBlob: EB } = await import("../../backend");
        const bytes = new Uint8Array(await kycFile.arrayBuffer());
        kycBlob = EB.fromBytes(bytes);
      }
      const newPhotoId = await uploadPhoto();
      const photoId = newPhotoId ?? editResident.photoId ?? null;
      await actor.updateResident({
        ...editResident,
        name: form.name.trim(),
        mobile: form.mobile.trim(),
        email: form.email.trim(),
        flatNumber: form.flatNumber.trim(),
        residencyType: form.residencyType,
        familyMembersCount: BigInt(
          Number.parseInt(form.familyMembersCount, 10),
        ),
        kycDocumentId: kycBlob,
        photoId: photoId ?? undefined,
      });
    },
    onSuccess: () => {
      void queryClient.invalidateQueries({ queryKey: ["residents"] });
      void queryClient.invalidateQueries({
        queryKey: ["resident", editFlatNumber],
      });
      toast.success("Resident information updated!");
      void navigate({ to: `/residents/${form.flatNumber}` });
    },
    onError: () => toast.error("Update failed. Please try again."),
  });

  if (
    !role ||
    role === "committee" ||
    role === "resident" ||
    role === "security"
  ) {
    void navigate({ to: "/residents" });
    return null;
  }

  const isPending = addMutation.isPending || updateMutation.isPending;

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!validate()) return;
    if (isEditing) updateMutation.mutate();
    else addMutation.mutate();
  }

  return (
    <Layout role={role}>
      <PageHeader
        title={isEditing ? "Edit Resident" : "Add New Resident"}
        subtitle={
          isEditing
            ? `Update information for ${editResident?.name ?? ""}`
            : "Register a new resident"
        }
        icon={isEditing ? "✏️" : "➕"}
        actions={
          <Button
            variant="outline"
            onClick={() => void navigate({ to: "/residents" })}
            className="btn-accessible gap-2"
            data-ocid="resident_form.cancel_button"
          >
            <ArrowLeft className="w-4 h-4" />
            Back
          </Button>
        }
      />

      <div className="p-4 max-w-2xl mx-auto">
        <form onSubmit={handleSubmit} noValidate>
          <Card className="shadow-card">
            <CardContent className="p-6 space-y-6">
              {/* Photo Section */}
              <section>
                <h2 className="text-lg font-semibold font-display text-foreground mb-4 pb-2 border-b border-border">
                  Resident Photo
                </h2>
                <div className="flex flex-col items-center gap-4">
                  {/* Photo preview */}
                  <div className="w-28 h-28 rounded-2xl border-2 border-border bg-muted/30 overflow-hidden flex items-center justify-center flex-shrink-0">
                    {photoPreview ? (
                      <img
                        src={photoPreview}
                        alt="Resident"
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <span className="text-4xl">👤</span>
                    )}
                  </div>
                  {/* Action buttons */}
                  <div className="flex gap-3 flex-wrap justify-center">
                    <Button
                      type="button"
                      variant="outline"
                      className="btn-accessible gap-2"
                      onClick={() => cameraInputRef.current?.click()}
                      data-ocid="resident_form.camera_button"
                    >
                      <Camera className="w-5 h-5" />
                      Camera
                    </Button>
                    <Button
                      type="button"
                      variant="outline"
                      className="btn-accessible gap-2"
                      onClick={() => photoInputRef.current?.click()}
                      data-ocid="resident_form.photo_upload_button"
                    >
                      <Upload className="w-5 h-5" />
                      Choose File
                    </Button>
                    {photoPreview && (
                      <Button
                        type="button"
                        variant="ghost"
                        className="btn-accessible gap-2 text-destructive hover:bg-destructive/10"
                        onClick={() => {
                          setPhotoFile(null);
                          setPhotoPreview(null);
                        }}
                        data-ocid="resident_form.remove_photo_button"
                      >
                        <X className="w-5 h-5" />
                        Remove
                      </Button>
                    )}
                  </div>
                  <p className="text-sm text-muted-foreground text-center">
                    Photo is optional — use camera or choose from gallery
                  </p>
                </div>
                {/* Hidden file inputs */}
                <input
                  ref={cameraInputRef}
                  type="file"
                  accept="image/*"
                  capture="user"
                  className="hidden"
                  onChange={(e) => {
                    const f = e.target.files?.[0];
                    if (f) handlePhotoChange(f);
                    e.target.value = "";
                  }}
                  aria-label="Take photo with camera"
                />
                <input
                  ref={photoInputRef}
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={(e) => {
                    const f = e.target.files?.[0];
                    if (f) handlePhotoChange(f);
                    e.target.value = "";
                  }}
                  aria-label="Choose photo file"
                />
              </section>

              {/* Personal Info */}
              <section>
                <h2 className="text-lg font-semibold font-display text-foreground mb-4 pb-2 border-b border-border">
                  Personal Information
                </h2>
                <div className="space-y-4">
                  <FormField
                    label="Full Name *"
                    error={errors.name}
                    htmlFor="name"
                  >
                    <Input
                      id="name"
                      value={form.name}
                      onChange={(e) =>
                        setForm((p) => ({ ...p, name: e.target.value }))
                      }
                      placeholder="e.g. Rajesh Kumar Sharma"
                      className="h-12 text-base"
                      aria-required="true"
                      data-ocid="resident_form.name_input"
                    />
                  </FormField>

                  <FormField
                    label="Mobile Number *"
                    error={errors.mobile}
                    htmlFor="mobile"
                  >
                    <Input
                      id="mobile"
                      type="tel"
                      value={form.mobile}
                      onChange={(e) =>
                        setForm((p) => ({ ...p, mobile: e.target.value }))
                      }
                      placeholder="10-digit mobile number"
                      className="h-12 text-base"
                      maxLength={10}
                      aria-required="true"
                      data-ocid="resident_form.mobile_input"
                    />
                  </FormField>

                  <FormField
                    label="Email Address"
                    error={errors.email}
                    htmlFor="email"
                  >
                    <Input
                      id="email"
                      type="email"
                      value={form.email}
                      onChange={(e) =>
                        setForm((p) => ({ ...p, email: e.target.value }))
                      }
                      placeholder="resident@email.com"
                      className="h-12 text-base"
                      data-ocid="resident_form.email_input"
                    />
                  </FormField>
                </div>
              </section>

              {/* Flat Details */}
              <section>
                <h2 className="text-lg font-semibold font-display text-foreground mb-4 pb-2 border-b border-border">
                  Flat Details
                </h2>
                <div className="space-y-4">
                  {!isEditing && flats && flats.length > 0 && (
                    <FormField label="Select Flat" htmlFor="flat-picker">
                      <Select
                        onValueChange={(val) =>
                          setForm((p) => ({
                            ...p,
                            flatNumber: val,
                            wing: val.split("-")[0] ?? p.wing,
                            floor: val.split("-")[1] ?? p.floor,
                          }))
                        }
                        value={form.flatNumber}
                      >
                        <SelectTrigger
                          id="flat-picker"
                          className="h-12 text-base"
                          data-ocid="resident_form.flat_select"
                        >
                          <SelectValue placeholder="Select flat..." />
                        </SelectTrigger>
                        <SelectContent>
                          {flats.map((f) => (
                            <SelectItem
                              key={f.flatNumber}
                              value={f.flatNumber}
                              className="text-base py-3"
                            >
                              Flat {f.flatNumber} — {f.wing} Wing, Floor{" "}
                              {String(f.floor)}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </FormField>
                  )}

                  <div className="grid grid-cols-2 gap-4">
                    <FormField label="Wing" htmlFor="wing">
                      <Input
                        id="wing"
                        value={form.wing}
                        onChange={(e) =>
                          setForm((p) => ({ ...p, wing: e.target.value }))
                        }
                        placeholder="A, B, C..."
                        className="h-12 text-base"
                        data-ocid="resident_form.wing_input"
                      />
                    </FormField>
                    <FormField label="Floor" htmlFor="floor">
                      <Input
                        id="floor"
                        type="number"
                        value={form.floor}
                        onChange={(e) =>
                          setForm((p) => ({ ...p, floor: e.target.value }))
                        }
                        placeholder="1, 2, 3..."
                        className="h-12 text-base"
                        data-ocid="resident_form.floor_input"
                      />
                    </FormField>
                  </div>

                  <FormField
                    label="Flat Number *"
                    error={errors.flatNumber}
                    htmlFor="flat-number"
                  >
                    <Input
                      id="flat-number"
                      value={form.flatNumber}
                      onChange={(e) =>
                        setForm((p) => ({ ...p, flatNumber: e.target.value }))
                      }
                      placeholder="e.g. A-101"
                      className="h-12 text-base"
                      aria-required="true"
                      data-ocid="resident_form.flat_number_input"
                    />
                  </FormField>

                  <FormField label="Residency Type *" htmlFor="residency-type">
                    <Select
                      value={form.residencyType}
                      onValueChange={(val) =>
                        setForm((p) => ({
                          ...p,
                          residencyType: val as ResidencyType,
                        }))
                      }
                    >
                      <SelectTrigger
                        id="residency-type"
                        className="h-12 text-base"
                        data-ocid="resident_form.residency_select"
                      >
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem
                          value={ResidencyType.owner}
                          className="text-base py-3"
                        >
                          🏠 Owner
                        </SelectItem>
                        <SelectItem
                          value={ResidencyType.tenant}
                          className="text-base py-3"
                        >
                          🔑 Tenant
                        </SelectItem>
                      </SelectContent>
                    </Select>
                  </FormField>

                  <FormField
                    label="Family Members *"
                    error={errors.familyMembersCount}
                    htmlFor="family-count"
                  >
                    <Input
                      id="family-count"
                      type="number"
                      min={1}
                      value={form.familyMembersCount}
                      onChange={(e) =>
                        setForm((p) => ({
                          ...p,
                          familyMembersCount: e.target.value,
                        }))
                      }
                      className="h-12 text-base"
                      aria-required="true"
                      data-ocid="resident_form.family_count_input"
                    />
                  </FormField>
                </div>
              </section>

              {/* KYC Document */}
              <section>
                <h2 className="text-lg font-semibold font-display text-foreground mb-4 pb-2 border-b border-border">
                  ID Document (KYC)
                </h2>
                <button
                  type="button"
                  className="w-full border-2 border-dashed border-input rounded-xl p-6 text-center cursor-pointer hover:border-primary/60 hover:bg-primary/5 transition-smooth"
                  onClick={() => fileInputRef.current?.click()}
                  data-ocid="resident_form.dropzone"
                >
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept=".pdf,.jpg,.jpeg,.png"
                    className="hidden"
                    onChange={(e) => setKycFile(e.target.files?.[0] ?? null)}
                    aria-label="Upload ID document"
                    data-ocid="resident_form.upload_button"
                  />
                  {kycFile ? (
                    <div className="flex items-center justify-center gap-3">
                      <span className="text-2xl">📄</span>
                      <div className="text-left">
                        <p className="font-medium text-foreground">
                          {kycFile.name}
                        </p>
                        <p className="text-sm text-muted-foreground">
                          {(kycFile.size / 1024).toFixed(1)} KB
                        </p>
                      </div>
                      <Button
                        type="button"
                        variant="ghost"
                        size="sm"
                        onClick={(e) => {
                          e.stopPropagation();
                          setKycFile(null);
                        }}
                        className="ml-auto h-10 w-10 p-0"
                        aria-label="Remove file"
                      >
                        <X className="w-4 h-4" />
                      </Button>
                    </div>
                  ) : (
                    <div className="space-y-2">
                      <Upload className="w-8 h-8 text-muted-foreground mx-auto" />
                      <p className="text-base font-medium text-foreground">
                        Upload ID Document
                      </p>
                      <p className="text-sm text-muted-foreground">
                        Aadhaar, PAN, Passport — PDF, JPG, PNG
                      </p>
                    </div>
                  )}
                </button>
                {isEditing && editResident?.kycDocumentId && !kycFile && (
                  <p className="mt-2 text-sm text-muted-foreground text-center">
                    ✅ ID document already uploaded. Upload a new file to
                    replace it.
                  </p>
                )}
              </section>

              {/* Submit */}
              <div className="flex gap-3 pt-2">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => void navigate({ to: "/residents" })}
                  className="btn-accessible flex-1"
                  data-ocid="resident_form.cancel_button"
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  disabled={isPending}
                  className="btn-accessible flex-1 gap-2"
                  data-ocid="resident_form.submit_button"
                >
                  <Save className="w-5 h-5" />
                  {isPending
                    ? isEditing
                      ? "Saving..."
                      : "Adding..."
                    : isEditing
                      ? "Save Changes"
                      : "Add Resident"}
                </Button>
              </div>
            </CardContent>
          </Card>
        </form>
      </div>
    </Layout>
  );
}

function FormField({
  label,
  error,
  htmlFor,
  children,
}: {
  label: string;
  error?: string;
  htmlFor: string;
  children: React.ReactNode;
}) {
  return (
    <div className="space-y-1.5">
      <Label
        htmlFor={htmlFor}
        className="text-base font-medium text-foreground"
      >
        {label}
      </Label>
      {children}
      {error && (
        <p
          className="text-sm text-destructive font-medium"
          data-ocid="resident_form.field_error"
          role="alert"
        >
          {error}
        </p>
      )}
    </div>
  );
}
