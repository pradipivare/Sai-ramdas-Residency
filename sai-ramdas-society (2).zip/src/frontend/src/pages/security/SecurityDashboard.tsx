import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { cn } from "@/lib/utils";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useNavigate } from "@tanstack/react-router";
import {
  CheckCircle2,
  Clock,
  DoorOpen,
  LogIn,
  Phone,
  ShieldAlert,
  UserCheck,
  Users,
  XCircle,
} from "lucide-react";
import { toast } from "sonner";
import { Layout } from "../../components/Layout";
import { useRole } from "../../hooks/use-role";
import { formatDate, useTodayVisitors } from "../../hooks/useQueries";
import { useActor } from "../../lib/backend-client";
import type { AppRole, Visitor } from "../../types";
import { ApprovalStatus } from "../../types";

// ─── Stat card (small) ────────────────────────────────────────────────────────

function MiniStat({
  icon,
  label,
  value,
  color,
  ocid,
  loading,
}: {
  icon: React.ReactNode;
  label: string;
  value: number;
  color: string;
  ocid: string;
  loading?: boolean;
}) {
  return (
    <div
      className={cn(
        "flex flex-col items-center justify-center gap-1 p-4 rounded-2xl min-h-[88px]",
        color,
      )}
      data-ocid={ocid}
    >
      {icon}
      {loading ? (
        <Skeleton className="h-8 w-10" />
      ) : (
        <p className="text-3xl font-bold font-display text-foreground">
          {value}
        </p>
      )}
      <p className="text-xs font-medium text-muted-foreground text-center leading-tight">
        {label}
      </p>
    </div>
  );
}

// ─── Approval badge ───────────────────────────────────────────────────────────

function ApprovalBadge({ status }: { status: ApprovalStatus }) {
  if (status === ApprovalStatus.approved) {
    return (
      <Badge className="bg-primary/10 text-primary border-0 gap-1 flex-shrink-0">
        <CheckCircle2 className="w-3.5 h-3.5" /> Approved
      </Badge>
    );
  }
  if (status === ApprovalStatus.rejected) {
    return (
      <Badge variant="destructive" className="gap-1 flex-shrink-0">
        <XCircle className="w-3.5 h-3.5" /> Rejected
      </Badge>
    );
  }
  return (
    <Badge className="bg-accent/30 text-accent-foreground border-0 gap-1 flex-shrink-0">
      <Clock className="w-3.5 h-3.5" /> Waiting
    </Badge>
  );
}

// ─── Log Exit Row (for security guard quick-exit) ─────────────────────────────

function VisitorExitRow({
  visitor,
  index,
  onLogExit,
  isExiting,
}: {
  visitor: Visitor;
  index: number;
  onLogExit: (id: bigint) => void;
  isExiting: boolean;
}) {
  const hasLeft = !!visitor.exitTime;
  return (
    <div
      className="flex items-start gap-3 py-3 border-b border-border last:border-0"
      data-ocid={`dashboard.visitor.item.${index + 1}`}
    >
      <div
        className={cn(
          "w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5",
          hasLeft ? "bg-muted" : "bg-primary/10",
        )}
      >
        <Users
          className={cn(
            "w-5 h-5",
            hasLeft ? "text-muted-foreground" : "text-primary",
          )}
        />
      </div>
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2 flex-wrap">
          <p className="text-base font-semibold text-foreground">
            {visitor.name}
          </p>
          <ApprovalBadge status={visitor.approvalStatus} />
        </div>
        <p className="text-sm text-muted-foreground mt-0.5">
          Flat {visitor.flatVisiting} · {visitor.purpose}
        </p>
        <p className="text-xs text-muted-foreground mt-0.5">
          Entered: {formatDate(visitor.entryTime)}
          {hasLeft && visitor.exitTime
            ? ` · Left: ${formatDate(visitor.exitTime)}`
            : " · Still inside"}
        </p>
      </div>
      {!hasLeft && visitor.approvalStatus === ApprovalStatus.approved && (
        <Button
          size="sm"
          variant="outline"
          className="h-8 text-xs gap-1 px-2 flex-shrink-0"
          onClick={() => onLogExit(visitor.visitorId)}
          disabled={isExiting}
          data-ocid={`dashboard.visitor.exit_button.${index + 1}`}
        >
          Exit
        </Button>
      )}
    </div>
  );
}

// ─── Main component ───────────────────────────────────────────────────────────

export default function SecurityDashboard() {
  const navigate = useNavigate();
  const { getRole } = useRole();
  const role = getRole() as AppRole;
  const { actor } = useActor();
  const queryClient = useQueryClient();

  const { data: todayVisitors = [], isLoading } = useTodayVisitors();

  const exitMutation = useMutation({
    mutationFn: async (visitorId: bigint) => {
      if (!actor) throw new Error("No actor");
      await actor.logVisitorExit(visitorId);
    },
    onSuccess: () => {
      void queryClient.invalidateQueries({ queryKey: ["visitors"] });
      toast.success("Visitor exit recorded", { duration: 4000 });
    },
    onError: () =>
      toast.error("Failed to record exit. Please try again.", {
        duration: 4000,
      }),
  });

  const pendingVisitors = todayVisitors.filter(
    (v) => v.approvalStatus === ApprovalStatus.pending,
  );
  const insideNow = todayVisitors.filter(
    (v) => v.approvalStatus === ApprovalStatus.approved && !v.exitTime,
  );

  const sortedVisitors = [...todayVisitors].sort((a, b) => {
    if (
      a.approvalStatus === ApprovalStatus.pending &&
      b.approvalStatus !== ApprovalStatus.pending
    )
      return -1;
    if (
      b.approvalStatus === ApprovalStatus.pending &&
      a.approvalStatus !== ApprovalStatus.pending
    )
      return 1;
    return Number(b.entryTime) - Number(a.entryTime);
  });

  return (
    <Layout role={role}>
      {/* Header */}
      <div className="bg-primary text-primary-foreground px-4 py-6">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-primary-foreground/20 flex items-center justify-center">
            <ShieldAlert className="w-6 h-6" />
          </div>
          <div>
            <h1
              className="text-2xl font-bold font-display"
              data-ocid="dashboard.title"
            >
              Security Dashboard
            </h1>
            <p className="text-base opacity-80">
              {new Date().toLocaleDateString("en-IN", {
                weekday: "long",
                day: "numeric",
                month: "long",
              })}
            </p>
          </div>
        </div>
      </div>

      <div className="p-4 space-y-5 max-w-2xl mx-auto">
        {/* Stats */}
        <section aria-label="Today's visitor stats">
          <h2 className="text-lg font-semibold text-foreground mb-3">
            Today's Overview
          </h2>
          <div
            className="grid grid-cols-3 gap-3"
            data-ocid="dashboard.stats_section"
          >
            <MiniStat
              icon={<Users className="w-6 h-6 text-primary" />}
              label="Total Visitors"
              value={todayVisitors.length}
              color="bg-primary/10"
              ocid="dashboard.stat.total_visitors"
              loading={isLoading}
            />
            <MiniStat
              icon={<Clock className="w-6 h-6 text-accent-foreground" />}
              label="Awaiting Entry"
              value={pendingVisitors.length}
              color="bg-accent/20"
              ocid="dashboard.stat.pending_visitors"
              loading={isLoading}
            />
            <MiniStat
              icon={<UserCheck className="w-6 h-6 text-primary" />}
              label="Inside Now"
              value={insideNow.length}
              color="bg-primary/10"
              ocid="dashboard.stat.inside_now"
              loading={isLoading}
            />
          </div>
        </section>

        {/* Primary CTA */}
        <section aria-label="Gate actions">
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            <Button
              size="lg"
              className="btn-accessible h-16 text-lg gap-3 rounded-2xl shadow-card"
              onClick={() => void navigate({ to: "/visitors" })}
              data-ocid="dashboard.log_visitor_button"
            >
              <LogIn className="w-6 h-6" />
              Log Visitor Entry
            </Button>
            {pendingVisitors.length > 0 && (
              <Button
                size="lg"
                variant="outline"
                className="btn-accessible h-16 text-lg gap-3 rounded-2xl shadow-card border-accent/50 bg-accent/10 hover:bg-accent/20 text-foreground"
                onClick={() => void navigate({ to: "/visitors" })}
                data-ocid="dashboard.pending_approvals_button"
              >
                <Clock className="w-6 h-6 text-accent-foreground" />
                {pendingVisitors.length} Pending Approval
                {pendingVisitors.length > 1 ? "s" : ""}
              </Button>
            )}
          </div>
        </section>

        {/* Today's visitor log */}
        <section aria-label="Today's visitors">
          <div className="flex items-center justify-between mb-3">
            <h2 className="text-lg font-semibold text-foreground">
              Today's Visitors
            </h2>
            <Button
              variant="ghost"
              size="sm"
              className="text-primary text-base"
              onClick={() => void navigate({ to: "/visitors" })}
              data-ocid="dashboard.all_visitors_link"
            >
              View All
            </Button>
          </div>
          <Card className="shadow-card" data-ocid="dashboard.visitors_section">
            <CardContent className="p-4">
              {isLoading ? (
                <div className="space-y-4">
                  {[1, 2, 3].map((i) => (
                    <Skeleton key={i} className="h-16 w-full" />
                  ))}
                </div>
              ) : sortedVisitors.length === 0 ? (
                <div
                  className="flex flex-col items-center py-8 gap-3"
                  data-ocid="dashboard.visitors.empty_state"
                >
                  <DoorOpen className="w-12 h-12 text-muted-foreground/40" />
                  <p className="text-base text-muted-foreground text-center">
                    No visitors logged today.
                  </p>
                  <Button
                    onClick={() => void navigate({ to: "/visitors" })}
                    data-ocid="dashboard.log_first_visitor_button"
                    className="btn-accessible"
                  >
                    <LogIn className="w-5 h-5 mr-2" />
                    Log First Visitor
                  </Button>
                </div>
              ) : (
                sortedVisitors
                  .slice(0, 8)
                  .map((v, i) => (
                    <VisitorExitRow
                      key={String(v.visitorId)}
                      visitor={v}
                      index={i}
                      onLogExit={(id) => exitMutation.mutate(id)}
                      isExiting={exitMutation.isPending}
                    />
                  ))
              )}
            </CardContent>
          </Card>
        </section>

        {/* Emergency contacts */}
        <section aria-label="Emergency contacts">
          <Card className="shadow-card border-destructive/30 bg-destructive/5">
            <CardHeader className="pb-2">
              <CardTitle className="text-base text-destructive flex items-center gap-2">
                <ShieldAlert className="w-5 h-5" /> Emergency Contacts
              </CardTitle>
            </CardHeader>
            <CardContent className="p-4 pt-0 grid grid-cols-1 gap-2 sm:grid-cols-2">
              {[
                { label: "Society Admin", number: "+91 98765 43210" },
                { label: "Police (100)", number: "100" },
                { label: "Fire Brigade (101)", number: "101" },
                { label: "Ambulance (108)", number: "108" },
              ].map(({ label, number }) => (
                <a
                  key={label}
                  href={`tel:${number.replace(/\s+/g, "")}`}
                  className="flex items-center gap-3 p-3 bg-card rounded-xl border border-border hover:bg-muted/50 transition-smooth min-h-[52px]"
                  data-ocid={`dashboard.emergency.${label.toLowerCase().replace(/[\s()]+/g, "_")}_link`}
                >
                  <Phone className="w-5 h-5 text-destructive flex-shrink-0" />
                  <div>
                    <p className="text-sm font-semibold text-foreground">
                      {label}
                    </p>
                    <p className="text-xs text-muted-foreground">{number}</p>
                  </div>
                </a>
              ))}
            </CardContent>
          </Card>
        </section>
      </div>
    </Layout>
  );
}
