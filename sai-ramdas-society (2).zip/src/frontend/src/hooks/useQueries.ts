import { useQuery } from "@tanstack/react-query";
import { useActor } from "../lib/backend-client";
import type {
  Bill,
  Complaint,
  Flat,
  Notice,
  OverdueMemberReport,
  Resident,
  SocietyMember,
  SocietyRule,
  Visitor,
} from "../types";
import { ApprovalStatus, BillStatus, ComplaintStatus } from "../types";

// ─── Flats ───────────────────────────────────────────────────────────────────

export function useAllFlats() {
  const { actor, isFetching } = useActor();
  return useQuery<Flat[]>({
    queryKey: ["flats"],
    queryFn: async () => {
      if (!actor) return [];
      return actor.getAllFlats();
    },
    enabled: !!actor && !isFetching,
  });
}

// ─── Total Flats Override ─────────────────────────────────────────────────────

export function useTotalFlatsOverride() {
  const { actor, isFetching } = useActor();
  return useQuery<bigint | null>({
    queryKey: ["totalFlatsOverride"],
    queryFn: async () => {
      if (!actor) return null;
      return actor.getTotalFlatsOverride();
    },
    enabled: !!actor && !isFetching,
    staleTime: 30_000,
    refetchOnWindowFocus: true,
  });
}

// ─── Total Shops Override ─────────────────────────────────────────────────────

export function useTotalShopsOverride() {
  const { actor, isFetching } = useActor();
  return useQuery<bigint>({
    queryKey: ["totalShopsOverride"],
    queryFn: async () => {
      if (!actor) return BigInt(0);
      try {
        return await actor.getTotalShopsOverride();
      } catch {
        return BigInt(0);
      }
    },
    enabled: !!actor && !isFetching,
    staleTime: 30_000,
    refetchOnWindowFocus: true,
  });
}

// ─── Residents ───────────────────────────────────────────────────────────────

export function useAllResidents() {
  const { actor, isFetching } = useActor();
  return useQuery<Resident[]>({
    queryKey: ["residents"],
    queryFn: async () => {
      if (!actor) return [];
      return actor.getAllResidents();
    },
    enabled: !!actor && !isFetching,
    staleTime: 30_000,
    refetchOnWindowFocus: true,
  });
}

// ─── Bills ───────────────────────────────────────────────────────────────────

export function useAllUnpaidBills() {
  const { actor, isFetching } = useActor();
  return useQuery<Bill[]>({
    queryKey: ["bills", "unpaid"],
    queryFn: async () => {
      if (!actor) return [];
      return actor.getAllUnpaidBills();
    },
    enabled: !!actor && !isFetching,
    staleTime: 30_000,
    refetchOnWindowFocus: true,
  });
}

export function useBillsByFlat(flatNumber: string) {
  const { actor, isFetching } = useActor();
  return useQuery<Bill[]>({
    queryKey: ["bills", "flat", flatNumber],
    queryFn: async () => {
      if (!actor) return [];
      return actor.getBillsByFlat(flatNumber);
    },
    enabled: !!actor && !isFetching && !!flatNumber,
  });
}

// ─── Complaints ───────────────────────────────────────────────────────────────

export function useAllComplaints() {
  const { actor, isFetching } = useActor();
  return useQuery<Complaint[]>({
    queryKey: ["complaints"],
    queryFn: async () => {
      if (!actor) return [];
      return actor.getAllComplaints();
    },
    enabled: !!actor && !isFetching,
    staleTime: 30_000,
    refetchOnWindowFocus: true,
  });
}

export function useMyComplaints() {
  const { actor, isFetching } = useActor();
  return useQuery<Complaint[]>({
    queryKey: ["complaints", "mine"],
    queryFn: async () => {
      if (!actor) return [];
      return actor.getMyComplaints();
    },
    enabled: !!actor && !isFetching,
  });
}

export function useComplaintsByFlat(flatNumber: string) {
  const { actor, isFetching } = useActor();
  return useQuery<Complaint[]>({
    queryKey: ["complaints", "flat", flatNumber],
    queryFn: async () => {
      if (!actor) return [];
      return actor.getComplaintsByFlat(flatNumber);
    },
    enabled: !!actor && !isFetching && !!flatNumber,
  });
}

// ─── Notices ─────────────────────────────────────────────────────────────────

export function useAllNotices() {
  const { actor, isFetching } = useActor();
  return useQuery<Notice[]>({
    queryKey: ["notices"],
    queryFn: async () => {
      if (!actor) return [];
      return actor.getAllNotices();
    },
    enabled: !!actor && !isFetching,
    staleTime: 30_000,
    refetchOnWindowFocus: true,
  });
}

export function usePinnedNotices() {
  const { actor, isFetching } = useActor();
  return useQuery<Notice[]>({
    queryKey: ["notices", "pinned"],
    queryFn: async () => {
      if (!actor) return [];
      return actor.getPinnedNotices();
    },
    enabled: !!actor && !isFetching,
  });
}

// ─── Visitors ────────────────────────────────────────────────────────────────

export function useTodayVisitors() {
  const { actor, isFetching } = useActor();
  return useQuery<Visitor[]>({
    queryKey: ["visitors", "today"],
    queryFn: async () => {
      if (!actor) return [];
      return actor.getTodayVisitors();
    },
    enabled: !!actor && !isFetching,
    staleTime: 30_000,
    refetchOnWindowFocus: true,
  });
}

export function useVisitorsByFlat(flatNumber: string) {
  const { actor, isFetching } = useActor();
  return useQuery<Visitor[]>({
    queryKey: ["visitors", "flat", flatNumber],
    queryFn: async () => {
      if (!actor) return [];
      return actor.getVisitorsByFlat(flatNumber);
    },
    enabled: !!actor && !isFetching && !!flatNumber,
  });
}

// ─── Society Committee Members ────────────────────────────────────────────────

export function useActiveSocietyMembers() {
  const { actor, isFetching } = useActor();
  return useQuery<SocietyMember[]>({
    queryKey: ["society-members", "active"],
    queryFn: async (): Promise<SocietyMember[]> => {
      if (!actor) return [];
      try {
        const raw = await actor.getActiveSocietyMembers();
        return raw.map((m) => ({
          ...m,
          role: m.role as SocietyMember["role"],
          photoId: m.photoId ?? null,
          contactPhone: m.contactPhone ?? null,
          contactEmail: m.contactEmail ?? null,
        }));
      } catch {
        return [];
      }
    },
    enabled: !!actor && !isFetching,
  });
}

// ─── Society Rules (Rules & Regulations) ────────────────────────────────────

const FALLBACK_SOCIETY_RULES: SocietyRule[] = [
  {
    id: 1n,
    titleMarathi: "देखभाल शुल्क भरणे",
    titleEnglish: "Payment of Maintenance Charges",
    descriptionMarathi:
      "प्रत्येक सदस्याने महिन्याच्या १ ते १० तारखेपर्यंत देखभाल शुल्क भरणे बंधनकारक आहे.",
    descriptionEnglish:
      "Every member must pay maintenance charges between 1st and 10th of each month. A penalty of 10% per month will be charged for late payment.",
    category: "financial",
    tags: ["maintenance", "penalty"],
    orderNumber: 1n,
    isActive: true,
    createdAt: 0n,
    updatedAt: 0n,
  },
  {
    id: 2n,
    titleMarathi: "गेट बंद होण्याची वेळ",
    titleEnglish: "Gate Closing Time",
    descriptionMarathi: "सोसायटीचे मुख्य प्रवेशद्वार रात्री ११:०० वाजता बंद होईल.",
    descriptionEnglish:
      "The main gate of the society will be closed at 11:00 PM. Residents arriving late must inform the security guards in advance.",
    category: "security",
    tags: ["gate", "timing"],
    orderNumber: 2n,
    isActive: true,
    createdAt: 0n,
    updatedAt: 0n,
  },
  {
    id: 3n,
    titleMarathi: "परिसर स्वच्छता",
    titleEnglish: "Premises Cleanliness",
    descriptionMarathi: "कोणत्याही सार्वजनिक ठिकाणी कचरा टाकणे पूर्णपणे बंदी आहे.",
    descriptionEnglish:
      "Littering in any common area is strictly prohibited. Waste must be disposed of only in designated bins. A fine of ₹500 will be levied for violation.",
    category: "maintenance",
    tags: ["cleanliness", "fine"],
    orderNumber: 3n,
    isActive: true,
    createdAt: 0n,
    updatedAt: 0n,
  },
  {
    id: 4n,
    titleMarathi: "आवाज मर्यादा",
    titleEnglish: "Noise Restrictions",
    descriptionMarathi:
      "रात्री १०:०० ते सकाळी ६:०० वाजेपर्यंत मोठ्या आवाजात संगीत वाजवणे प्रतिबंधित आहे.",
    descriptionEnglish:
      "Playing loud music or creating any disturbance between 10:00 PM and 6:00 AM is strictly prohibited.",
    category: "conduct",
    tags: ["noise", "night"],
    orderNumber: 4n,
    isActive: true,
    createdAt: 0n,
    updatedAt: 0n,
  },
  {
    id: 5n,
    titleMarathi: "वाहन पार्किंग",
    titleEnglish: "Vehicle Parking",
    descriptionMarathi: "प्रत्येक सदस्याने आपले वाहन निर्धारित जागेतच उभे करावे.",
    descriptionEnglish:
      "Each member must park their vehicle only in the designated parking space. Vehicles parked in others' spaces will be asked to be moved immediately.",
    category: "conduct",
    tags: ["parking", "vehicle"],
    orderNumber: 5n,
    isActive: true,
    createdAt: 0n,
    updatedAt: 0n,
  },
  {
    id: 6n,
    titleMarathi: "भाडेकरू नोंदणी",
    titleEnglish: "Tenant Registration",
    descriptionMarathi:
      "कोणत्याही भाडेकरूस सदनिका देण्यापूर्वी समिती कार्यालयात नोंदणी करणे अनिवार्य आहे.",
    descriptionEnglish:
      "Before letting any tenant occupy a flat, registration at the committee office is mandatory. Tenant identity documents and rental agreement must be registered.",
    category: "conduct",
    tags: ["tenant", "registration", "kyc"],
    orderNumber: 6n,
    isActive: true,
    createdAt: 0n,
    updatedAt: 0n,
  },
];

export function useSocietyRules() {
  const { actor, isFetching } = useActor();
  return useQuery<SocietyRule[]>({
    queryKey: ["society-rules"],
    queryFn: async () => {
      if (!actor) return FALLBACK_SOCIETY_RULES;
      try {
        return await actor.getSocietyRules();
      } catch {
        return FALLBACK_SOCIETY_RULES;
      }
    },
    enabled: !isFetching,
  });
}

// ─── Helpers ─────────────────────────────────────────────────────────────────

export function getOpenComplaintsCount(complaints: Complaint[]): number {
  return complaints.filter(
    (c) =>
      c.status === ComplaintStatus.pending ||
      c.status === ComplaintStatus.inProgress,
  ).length;
}

export function getUnpaidBillsCount(bills: Bill[]): number {
  return bills.filter(
    (b) => b.status === BillStatus.unpaid || b.status === BillStatus.overdue,
  ).length;
}

export function getPendingVisitorsCount(visitors: Visitor[]): number {
  return visitors.filter((v) => v.approvalStatus === ApprovalStatus.pending)
    .length;
}

export function formatCurrency(amount: bigint): string {
  return `₹${Number(amount).toLocaleString("en-IN")}`;
}

export function formatDate(ts: bigint): string {
  return new Date(Number(ts) / 1_000_000).toLocaleDateString("en-IN", {
    day: "numeric",
    month: "short",
    year: "numeric",
  });
}

// ─── Overdue Bills With Residents ─────────────────────────────────────────────

export function useOverdueBillsWithResidents() {
  const { actor, isFetching } = useActor();
  return useQuery<OverdueMemberReport[]>({
    queryKey: ["bills", "overdue-with-residents"],
    queryFn: async () => {
      if (!actor) return [];
      try {
        return await (
          actor as unknown as {
            getOverdueBillsWithResidents(): Promise<OverdueMemberReport[]>;
          }
        ).getOverdueBillsWithResidents();
      } catch {
        return [];
      }
    },
    enabled: !!actor && !isFetching,
    staleTime: 30_000,
    refetchOnWindowFocus: true,
  });
}
