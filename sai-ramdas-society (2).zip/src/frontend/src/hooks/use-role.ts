import { useCallback } from "react";
import type { AppRole } from "../types";

const ROLE_STORAGE_KEY = "srs_app_role";

/**
 * Persists and retrieves the user's chosen app role from localStorage.
 * This is separate from the backend UserRole — it drives UI navigation
 * and is set after login on the RoleSelectPage.
 */
export function useRole() {
  const getRole = useCallback((): AppRole | null => {
    const stored = localStorage.getItem(ROLE_STORAGE_KEY);
    if (
      stored === "admin" ||
      stored === "committee" ||
      stored === "resident" ||
      stored === "security"
    ) {
      return stored;
    }
    return null;
  }, []);

  const setRole = useCallback((role: AppRole) => {
    localStorage.setItem(ROLE_STORAGE_KEY, role);
  }, []);

  const clearRole = useCallback(() => {
    localStorage.removeItem(ROLE_STORAGE_KEY);
  }, []);

  return {
    getRole,
    setRole,
    clearRole,
  };
}
