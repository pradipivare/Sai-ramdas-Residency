import { useInternetIdentity } from "@caffeineai/core-infrastructure";

/**
 * Thin wrapper around useInternetIdentity that exposes
 * the fields used throughout the app.
 */
export function useAuth() {
  const {
    identity,
    login,
    clear,
    isAuthenticated,
    isInitializing,
    isLoggingIn,
  } = useInternetIdentity();

  return {
    identity,
    isAuthenticated,
    isInitializing,
    isLoggingIn,
    login,
    logout: clear,
  };
}
