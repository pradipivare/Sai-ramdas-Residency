import {
  Outlet,
  RouterProvider,
  createRootRoute,
  createRoute,
  createRouter,
} from "@tanstack/react-router";
import { Suspense, lazy } from "react";
import { LoadingSpinner } from "./components/ui/LoadingSpinner";
import { useRole } from "./hooks/use-role";
import type { AppRole } from "./types";

// Lazy-loaded pages
const HomePage = lazy(() => import("./pages/HomePage"));
const LoginPage = lazy(() => import("./pages/LoginPage"));
const RoleSelectPage = lazy(() => import("./pages/RoleSelectPage"));
const BillingPage = lazy(() => import("./pages/billing/BillingPage"));
const ResidentBillingPage = lazy(
  () => import("./pages/billing/ResidentBillingPage"),
);
const NoticesPage = lazy(() => import("./pages/notices/NoticesPage"));
const MembersPage = lazy(() => import("./pages/members/MembersPage"));
const ResidentForm = lazy(() => import("./pages/members/ResidentForm"));
const ResidentDetailPage = lazy(
  () => import("./pages/members/ResidentDetailPage"),
);
const AdminDashboard = lazy(() => import("./pages/admin/AdminDashboard"));
const ResidentDashboard = lazy(
  () => import("./pages/resident/ResidentDashboard"),
);
const SecurityDashboard = lazy(
  () => import("./pages/security/SecurityDashboard"),
);
const ComplaintsPage = lazy(() => import("./pages/complaints/ComplaintsPage"));
const NewComplaintForm = lazy(
  () => import("./pages/complaints/NewComplaintForm"),
);
const ComplaintDetailPage = lazy(
  () => import("./pages/complaints/ComplaintDetailPage"),
);
const VisitorsPage = lazy(() => import("./pages/visitors/VisitorsPage"));
const LogVisitorForm = lazy(() => import("./pages/visitors/LogVisitorForm"));
const VisitorApprovalPage = lazy(
  () => import("./pages/visitors/VisitorApprovalPage"),
);
const PreApprovedGuestsPage = lazy(
  () => import("./pages/visitors/PreApprovedGuestsPage"),
);
const SocietyBodyManagePage = lazy(
  () => import("./pages/admin/SocietyBodyManagePage"),
);
const SocietyRulesPage = lazy(() => import("./pages/rules/SocietyRulesPage"));
const AdminSettingsPage = lazy(() => import("./pages/admin/AdminSettingsPage"));

// Role-aware dashboard router
function DashboardRouter() {
  const { getRole } = useRole();
  const role = getRole() as AppRole | null;
  if (!role) {
    void router.navigate({ to: "/role-select" });
    return null;
  }
  if (role === "resident") return <ResidentDashboard />;
  if (role === "security") return <SecurityDashboard />;
  return <AdminDashboard />;
}

// Home page: show homepage directly
function HomeRouter() {
  return <HomePage />;
}

// Root route with auth guard
function RootComponent() {
  return (
    <Suspense
      fallback={
        <div className="min-h-screen flex items-center justify-center">
          <LoadingSpinner size="lg" />
        </div>
      }
    >
      <Outlet />
    </Suspense>
  );
}

const rootRoute = createRootRoute({ component: RootComponent });

const loginRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: "/login",
  component: () => <LoginPage />,
});

const roleSelectRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: "/role-select",
  component: () => <RoleSelectPage />,
});

const dashboardRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: "/dashboard",
  component: DashboardRouter,
});

const billsRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: "/bills",
  component: () => {
    const { getRole } = useRole();
    const role = getRole() as AppRole | null;
    if (!role) return null;
    if (role === "resident") return <ResidentBillingPage />;
    return <BillingPage />;
  },
});

const noticesRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: "/notices",
  component: () => <NoticesPage />,
});

const residentsRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: "/residents",
  component: () => <MembersPage />,
});

const addResidentRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: "/residents/add",
  component: () => <ResidentForm />,
});

const editResidentRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: "/residents/edit/$flatNumber",
  component: () => <ResidentForm />,
});

const residentDetailRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: "/residents/$flatNumber",
  component: () => <ResidentDetailPage />,
});

const complaintsRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: "/complaints",
  component: () => <ComplaintsPage />,
});

const newComplaintRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: "/complaints/new",
  component: () => <NewComplaintForm />,
});

const complaintDetailRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: "/complaints/$complaintId",
  component: () => <ComplaintDetailPage />,
});

// Visitor routes
const visitorsRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: "/visitors",
  component: () => <VisitorsPage />,
});

const logVisitorRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: "/visitors/log",
  component: () => <LogVisitorForm />,
});

const visitorApprovalRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: "/visitors/approval",
  component: () => <VisitorApprovalPage />,
});

const preApprovedGuestsRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: "/visitors/pre-approved",
  component: () => <PreApprovedGuestsPage />,
});

const societyRulesRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: "/rules",
  component: () => <SocietyRulesPage />,
});

// /admin/society-body — Admin-only society body management
const adminSocietyBodyRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: "/admin/society-body",
  component: () => <SocietyBodyManagePage />,
});

const adminSettingsRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: "/admin/settings",
  component: () => <AdminSettingsPage />,
});

// Index: show homepage
const indexRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: "/",
  component: () => <HomeRouter />,
});

const routeTree = rootRoute.addChildren([
  indexRoute,
  loginRoute,
  roleSelectRoute,
  dashboardRoute,
  billsRoute,
  noticesRoute,
  residentsRoute,
  addResidentRoute,
  editResidentRoute,
  residentDetailRoute,
  complaintsRoute,
  newComplaintRoute,
  complaintDetailRoute,
  visitorsRoute,
  logVisitorRoute,
  visitorApprovalRoute,
  preApprovedGuestsRoute,
  societyRulesRoute,
  adminSettingsRoute,
  adminSocietyBodyRoute,
]);

const router = createRouter({ routeTree });

declare module "@tanstack/react-router" {
  interface Register {
    router: typeof router;
  }
}

export default function App() {
  return <RouterProvider router={router} />;
}
