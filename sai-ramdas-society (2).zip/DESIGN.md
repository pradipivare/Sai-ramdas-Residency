# Design Brief: Sai Ramdas Society

## Purpose & Tone
Housing society management platform for older residents and committee members. Reliable, accessible, institutional. Every interaction prioritizes clarity and dignity—no trendy effects, no confusion.

## Visual Direction
Accessible, warm, high-contrast UI designed for aging eyes. Large touch targets (48px+), generous spacing, institutional teal header, warm beige surfaces, vibrant amber for critical actions. Mobile-first responsive.

## Color Palette
| Token | OKLCH (Light) | OKLCH (Dark) | Purpose |
|-------|---|---|---|
| Primary | 0.5 0.15 204 | 0.65 0.12 204 | Trust, institutional authority, navigation |
| Accent | 0.72 0.19 80 | 0.78 0.18 80 | Alerts, CTAs, high-visibility actions |
| Secondary | 0.88 0.05 70 | 0.28 0.02 0 | Warm surfaces, backgrounds |
| Destructive | 0.58 0.16 22 | 0.65 0.15 22 | Errors, warnings (muted, not aggressive) |
| Background | 0.98 0.01 70 | 0.16 0.01 0 | Page background (warm white / dark) |
| Foreground | 0.25 0.01 0 | 0.92 0.01 70 | Body text (deep charcoal / off-white) |
| Muted | 0.92 0.02 0 | 0.28 0.02 0 | Secondary text, disabled states |

## Typography
- **Display**: General Sans (geometric, friendly, highly readable at scale)
- **Body**: DM Sans (proven accessibility, excellent hinting for older eyes)
- **Mono**: Geist Mono (data, forms, code)
- **Sizes**: 16px base, 20px headings, 18px large text, generous line-height (1.5+)

## Structural Zones
| Zone | Treatment | Purpose |
|------|-----------|---------|
| Header | Teal primary bg, white text, shadow-header | Navigation, role badge, clear identity |
| Main Content | Warm white bg, card-based | Readable, scannable, ample padding |
| Cards | Subtle shadow-card, border, 1rem radius | Visual grouping, tactile affordance |
| Buttons | 48px+ height, 1rem radius, 0.75rem padding | Touch-safe, elderly-friendly |
| Inputs | Large, clear borders, 44px+ height | Clear focus states, high contrast |
| Sidebar (Admin) | Teal bg, amber highlights, white text | Role-specific navigation, high contrast |

## Spacing & Rhythm
- Base unit: 4px
- Padding: 1.5rem (cards), 1rem (forms), 0.75rem (buttons)
- Gaps: 1.5rem (sections), 1rem (form fields), 0.5rem (inline)
- Breathing room prioritized—never cramped

## Component Patterns
- **Role Selection**: Large buttons, icon + label, high contrast on entry
- **Forms**: Full-width inputs, large labels (18px+), helper text, clear validation
- **Navigation**: Simplified sidebar (admin), bottom nav (mobile), role-based access
- **Modals**: Full-screen on mobile, centered on desktop, large close button (32px+)
- **Cards**: Consistent shadow, padding 1.5rem, clear borders, ample whitespace

## Motion
- Default: 0.3s cubic-bezier(0.4, 0, 0.2, 1) for all interactive elements
- Focus states: Amber ring (4px), instant feedback
- Page transitions: Fade (no slide-in confusion for older users)
- Accessibility: `prefers-reduced-motion` respected

## Differentiation
**Clarity-first accessibility design:** High WCAG AAA contrast, large touch targets, generous spacing, no micro-interactions or animations that require cognitive overhead. Role-based navigation simplifies surface area. Every UI element signals its purpose through size, color, and placement—no hidden interactions.

## Constraints
- No gradients or decorative overlays
- No hover-only UI (mobile-first, touch-first)
- No color alone for meaning (always pair with text/icon)
- Minimum font size: 16px (never smaller)
- Maximum touch target spacing: 4px
- All buttons: minimum 48px height

## Accessibility Checklist
- AA+ contrast ratios (tested via Lighthouse)
- Focus visible outlines (amber ring, 4px)
- Semantic HTML (nav, main, form labels)
- Alt text for all images
- Role attributes for components
- Error messages inline and linked to fields
- No keyboard traps, Tab order logical
